# GeoTwin: Coupled Geothermal Digital Twin & Field Operations Station

An engineering-grade geothermal digital twin, 3D reservoir simulator, well designer, binary ORC power plant simulator, district heating cogeneration, and operations control workstation.

## Defining Principle
**The geothermal field is one coupled physical system.**
A perturbation underground propagates causally across the wells, surface gathering, heat exchangers, ORC turbine, electrical generator, cooling system, grid connection, brine chemistry, induced seismicity, maintenance scheduling, and project economics.

```
EARTH → GEOLOGY → RESERVOIR → FRACTURE NETWORK → WELLS → GATHERING → FLASH / ORC → TURBINE → GENERATOR → GRID → REINJECTION → RESERVOIR
```

## System Capabilities
1. **Four Geothermal Architectures**:
   - Natural Hydrothermal Reservoir
   - Enhanced Geothermal System (EGS)
   - Deep Geothermal Direct Heat
   - Hybrid CHP + ATES Thermal Storage
2. **3D Subsurface & Discrete Fracture Network (DFN)**:
   - 3D Finite-Difference Reservoir Grid (3200m to 5200m TVD)
   - Orthogonal Slicing (XY, XZ, YZ planes)
   - Inter-well thermal breakthrough sweep simulation
3. **Well Designer & Hydraulics**:
   - Directional / Deviated trajectories
   - Hydrostatic, frictional, and acceleration pressure losses
   - Downhole ESP pump models & distributed temperature sensing (DTS)
4. **Surface Plant & Binary ORC**:
   - Organic working fluids (R245fa, R134a, Isobutane, n-Pentane, Cyclopentane)
   - Counter-current heat exchangers with LMTD calculations
   - Radial inflow turbines & synchronous generators
   - Air-Cooled Condensers (ACC) & wet cooling towers
5. **Geochemistry & Dynamic Feedback**:
   - Amorphous silica saturation index (SSI) & Calcite LSI/RSI
   - Live scaling deposition reducing heat exchanger UA
   - Direct Lithium Extraction (DLE) coproduct yield
6. **Induced Seismicity (EGS)**:
   - Shapiro pore pressure diffusion front $r(t) = \sqrt{4\pi D t}$
   - Gutenberg-Richter $b$-value magnitude distributions
   - Traffic Light System (TLS) Green/Amber/Red protocols
7. **Data Assimilation & Optimization**:
   - Ensemble Kalman Filter (EnKF) / ESMDA parameter calibration
   - Multi-objective Pareto frontier (Net Power vs Longevity vs Seismicity)
   - 10,000-run Monte Carlo uncertainty quantification (P10 / P50 / P90)
8. **Economics & Carbon Accounting**:
   - CAPEX, OPEX, LCOE ($/MWh), NPV, IRR, and Scope 1-3 GHG emissions
