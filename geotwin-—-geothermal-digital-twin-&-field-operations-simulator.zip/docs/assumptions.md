# Digital Twin Engineering Documentation Suite

### 1. Reservoir Numerical Formulation (`docs/reservoir.md`)
- Darcy multi-cell flow in fractured porous media.
- Dual-porosity / dual-permeability matrix-fracture exchange.
- 3D temperature diffusion $\nabla \cdot (K \nabla T) - \rho c_p \mathbf{u} \cdot \nabla T = \rho c_p \frac{\partial T}{\partial t}$.

### 2. Wellbore Hydraulics (`docs/wells.md`)
- Pressure gradient: $\frac{dp}{dz} = \rho g \cos\theta + \frac{f \rho v^2}{2 D} + \rho v \frac{dv}{dz}$.
- Colebrook-White friction factor via Haaland approximation.
- Distributed Temperature Sensing (DTS) Raman scattering modeling.

### 3. Surface Plant & Substation (`docs/plant.md`)
- Binary ORC preheater, kettle evaporator, and superheater design.
- Air-Cooled Condensers (ACC) with variable ambient dry-bulb temperature.
- Grid dispatch modes: Baseload, Load following, Curtailment, Islanding.

### 4. Induced Seismicity (`docs/seismicity.md`)
- Mohr-Coulomb failure criterion on oriented discrete fractures.
- Pore pressure perturbation diffusion envelope.
- Traffic Light System (TLS) protocol response levels (Green < 0.5 Mw, Amber 0.5-1.5 Mw, Red ≥ 1.5 Mw).

### 5. Data Assimilation (`docs/data-assimilation.md`)
- 50-member Ensemble Kalman Filter (EnKF) and ESMDA.
- Real-time observation ingestion from fiber-optic DTS and bottomhole gauges.
- Bayesian update step: $\mathbf{x}^a = \mathbf{x}^f + \mathbf{K} (\mathbf{y} - \mathbf{H}\mathbf{x}^f)$.

### 6. Explicit Assumptions (`docs/assumptions.md`)
- Closed binary ORC systems have negligible atmospheric fugitive emissions.
- All numbers and datasets are synthetic demonstration benchmarks for Cornwall EGS hybrid geology.
