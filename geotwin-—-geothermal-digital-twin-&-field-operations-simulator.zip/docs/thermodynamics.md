# Thermodynamics & Numerical Formulations

## 1. Water & Steam Formulations
Equations approximate IAPWS-IF97 industrial standards for liquid water and steam:
- Saturated liquid enthalpy: $h_f(T) = 4.184 T + 0.00045 T^2 \text{ [kJ/kg]}$
- Saturation vapor enthalpy: $h_g(T) = h_f(T) + (2501 - 2.38 T) \text{ [kJ/kg]}$
- Saturation vapor pressure: $P_{\text{sat}}(T)$ Wagner formulation

## 2. Organic Rankine Cycle (ORC)
- Working Fluids: R245fa, R134a, Isobutane (i-C4H10), n-Pentane, Cyclopentane
- Log Mean Temperature Difference (LMTD):
  $$\Delta T_{\text{lm}} = \frac{(T_{h,i} - T_{c,o}) - (T_{h,o} - T_{c,i})}{\ln\left(\frac{T_{h,i} - T_{c,o}}{T_{h,o} - T_{c,i}}\right)}$$
- Thermal Duty: $\dot{Q} = UA \cdot \Delta T_{\text{lm}}$
- Turbine Power: $\dot{W}_{\text{turb}} = \dot{m}_{\text{orc}} (h_{\text{in}} - h_{\text{out}}) \eta_{\text{isen}} \eta_{\text{mech}}$

## 3. Geochemistry & Scaling
- Fournier & Marshall (1982) amorphous silica solubility:
  $$\log_{10}[\text{SiO}_2] = 4.52 - \frac{731}{T_{\text{Kelvin}}}$$
- Saturation Index: $\text{SSI} = \frac{[\text{SiO}_2]_{\text{observed}}}{[\text{SiO}_2]_{\text{eq}}}$
- Dynamic Fouling Factor: $UA(t) = UA_0 (1 - \text{FoulingFactor}(t))$

## 4. Induced Seismicity
- Shapiro (2000) Pore Pressure Diffusion:
  $$r(t) = \sqrt{4 \pi D t}$$
- Gutenberg-Richter recurrence: $\log_{10} N = a - b M_w$
