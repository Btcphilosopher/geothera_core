# GeoTwin System Architecture & Coupling Specification

## 1. Digital Twin Coupling Engine
GeoTwin implements a closed-loop coupled solver executing at every simulation timestep:

```
[Reservoir Grid P(x,y,z), T(x,y,z)]
           │
           ▼
[Well Productivity Drawdown & Wellbore Hydraulics (Haaland / Colebrook)]
           │
           ▼
[Surface Gathering Header & Steam/Brine Separator]
           │
           ▼
[Heat Exchanger Array (Preheater / Vaporizer / District HEX)] ◄───┐ (Scaling Feedback)
           │                                                      │
           ▼                                                      │
[Binary ORC Turbine & Synchronous Generator (MWe)]                │
           │                                                      │
           ▼                                                      │
[Cooling Condenser & Reinjection Header]                          │
           │                                                      │
           ▼                                                      │
[Geochemical Kinetics (Silica SSI, Calcite LSI)] ─────────────────┘
           │
           ▼
[Induced Seismicity Shapiro Diffusion & TLS Protocol]
           │
           ▼
[EnKF Parameter Data Assimilation & Production Forecasting]
```

## 2. Mass & Energy Conservation
The engine enforces continuous mass, water, and thermal energy balances:
$$\dot{Q}_{\text{in}} = \dot{W}_{\text{gross}} + \dot{Q}_{\text{district}} + \dot{Q}_{\text{condenser}} + \dot{Q}_{\text{losses}}$$
$$\dot{m}_{\text{production}} = \dot{m}_{\text{reinjection}} + \dot{m}_{\text{losses}}$$
Discrepancies are monitored and bounded within ±0.5% numerical tolerance.
