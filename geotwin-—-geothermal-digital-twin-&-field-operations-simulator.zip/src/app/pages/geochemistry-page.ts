import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PhysicsEngineService } from '../services/physics-engine.service';

@Component({
  selector: 'app-geochemistry-page',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Top Title Card -->
      <div class="bg-slate-900/90 rounded-2xl border border-slate-800 p-4">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <div class="flex items-center gap-2">
              <mat-icon class="text-emerald-400">biotech</mat-icon>
              <h2 class="text-base font-bold text-slate-100 uppercase tracking-wide">Geochemistry Digital Twin & Scaling Kinetics</h2>
            </div>
            <p class="text-xs text-slate-400 mt-0.5">
              Silica (SiO₂) & Calcite (CaCO₃) Deposition Indices, Direct Lithium Extraction (DLE) & Dynamic Heat Exchanger Fouling Feedback
            </p>
          </div>

          <!-- Quick Descale Action -->
          <button 
            (click)="cleanHex()"
            class="px-3.5 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-mono font-bold flex items-center gap-1.5 transition-colors">
            <mat-icon class="!text-sm !w-4 !h-4">cleaning_services</mat-icon>
            Apply Chemical Descaling Flush
          </button>
        </div>
      </div>

      <!-- Geochemical Feedback Flow Banner -->
      <div class="bg-slate-900/90 rounded-2xl border border-slate-800 p-4">
        <div class="flex items-center gap-2 text-xs font-bold text-slate-200 mb-2 uppercase tracking-wide">
          <mat-icon class="text-amber-400 !text-base !w-4 !h-4">sync</mat-icon>
          Coupled Geochemical-Thermodynamic Feedback Loop
        </div>
        <div class="grid grid-cols-1 md:grid-cols-5 gap-2 text-xs font-mono">
          <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
            <span class="text-slate-500 text-[10px] block">1. Brine Cooling</span>
            <div class="text-slate-200 font-bold mt-1">T drops to {{ twin().gatheringSystem.reinjectionHeaderTempC }}°C</div>
            <div class="text-[10px] text-slate-500">Fournier equilibrium falls</div>
          </div>
          <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
            <span class="text-slate-500 text-[10px] block">2. Supersaturation</span>
            <div class="font-bold mt-1" [class]="twin().chemistry.silicaSaturationIndex > 1 ? 'text-rose-400' : 'text-emerald-400'">
              SSI = {{ twin().chemistry.silicaSaturationIndex }}
            </div>
            <div class="text-[10px] text-slate-500">Amorphous SiO2 threshold > 1.0</div>
          </div>
          <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
            <span class="text-slate-500 text-[10px] block">3. Surface Deposition</span>
            <div class="text-amber-400 font-bold mt-1">{{ twin().chemistry.scalingDepositionRateMmYr }} mm/yr</div>
            <div class="text-[10px] text-slate-500">Forms colloidal scale in HEX</div>
          </div>
          <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
            <span class="text-slate-500 text-[10px] block">4. Heat Transfer Loss</span>
            <div class="text-rose-400 font-bold mt-1">UA = {{ twin().heatExchangers[1].ua }} kW/K</div>
            <div class="text-[10px] text-slate-500">Fouling: {{ (twin().heatExchangers[1].foulingFactor * 100).toFixed(0) }}%</div>
          </div>
          <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
            <span class="text-slate-500 text-[10px] block">5. Electrical Derating</span>
            <div class="text-emerald-300 font-bold mt-1">{{ twin().balances.netElectricalPowerMW }} MWe Export</div>
            <div class="text-[10px] text-slate-500">Live MW loss computed</div>
          </div>
        </div>
      </div>

      <!-- Geochemical Assay & Saturation Indices -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Brine Assay Table -->
        <div class="lg:col-span-7 bg-slate-900/90 rounded-2xl border border-slate-800 p-4">
          <div class="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-emerald-400">opacity</mat-icon>
              <h3 class="text-sm font-bold text-slate-100 uppercase tracking-wide">Deep Geothermal Brine Chemical Assay</h3>
            </div>
            <span class="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
              TDS: {{ twin().chemistry.tds }} mg/L | pH: {{ twin().chemistry.ph }}
            </span>
          </div>

          <div class="grid grid-cols-3 gap-2.5 text-xs font-mono">
            <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
              <span class="text-slate-500 text-[10px] block">Lithium (Li+)</span>
              <span class="text-emerald-400 font-bold text-sm">{{ twin().chemistry.lithiumLi }} mg/L</span>
            </div>
            <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
              <span class="text-slate-500 text-[10px] block">Silica (SiO₂)</span>
              <span class="text-amber-400 font-bold text-sm">{{ twin().chemistry.silicaSiO2 }} mg/L</span>
            </div>
            <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
              <span class="text-slate-500 text-[10px] block">Calcium (Ca²+)</span>
              <span class="text-slate-200 font-bold">{{ twin().chemistry.calciumCa }} mg/L</span>
            </div>
            <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
              <span class="text-slate-500 text-[10px] block">Sodium (Na+)</span>
              <span class="text-slate-200 font-bold">{{ twin().chemistry.sodiumNa }} mg/L</span>
            </div>
            <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
              <span class="text-slate-500 text-[10px] block">Potassium (K+)</span>
              <span class="text-slate-200 font-bold">{{ twin().chemistry.potassiumK }} mg/L</span>
            </div>
            <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
              <span class="text-slate-500 text-[10px] block">Chloride (Cl-)</span>
              <span class="text-slate-200 font-bold">{{ twin().chemistry.chlorideCl }} mg/L</span>
            </div>
            <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
              <span class="text-slate-500 text-[10px] block">Magnesium (Mg²+)</span>
              <span class="text-slate-200 font-bold">{{ twin().chemistry.magnesiumMg }} mg/L</span>
            </div>
            <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
              <span class="text-slate-500 text-[10px] block">Bicarbonate (HCO₃-)</span>
              <span class="text-slate-200 font-bold">{{ twin().chemistry.bicarbonateHCO3 }} mg/L</span>
            </div>
            <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
              <span class="text-slate-500 text-[10px] block">Dissolved CO₂ / H₂S</span>
              <span class="text-slate-200 font-bold">{{ twin().chemistry.dissolvedCO2 }} / {{ twin().chemistry.h2s }} mg/L</span>
            </div>
          </div>
        </div>

        <!-- Mineral Extraction & Scaling Risk Summary -->
        <div class="lg:col-span-5 bg-slate-900/90 rounded-2xl border border-slate-800 p-4 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
              <div class="flex items-center gap-2">
                <mat-icon class="text-emerald-400">diamond</mat-icon>
                <h3 class="text-sm font-bold text-slate-100 uppercase tracking-wide">Direct Lithium Extraction (DLE)</h3>
              </div>
              <span class="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                Battery Grade
              </span>
            </div>

            <div class="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-2 text-xs font-mono mb-4">
              <div class="flex justify-between">
                <span class="text-slate-400">Daily Lithium Extraction:</span>
                <span class="text-emerald-400 font-bold text-sm">{{ twin().chemistry.lithiumExtractionPotentialKgDay }} kg Li/day</span>
              </div>
              <div class="flex justify-between">
                <span class="text-slate-400">Annual LCE Yield:</span>
                <span class="text-slate-200">{{ (twin().chemistry.lithiumExtractionPotentialKgDay * 365 * 5.323 / 1000).toFixed(1) }} tonnes LCE/yr</span>
              </div>
              <div class="flex justify-between">
                <span class="text-slate-400">Est. Co-product Revenue:</span>
                <span class="text-emerald-300 font-bold">
                  {{ (twin().chemistry.lithiumExtractionPotentialKgDay * 365 * twin().economics.lithiumPriceUSDPerKg / 1e6).toFixed(2) }}M $/yr
                </span>
              </div>
            </div>

            <!-- Scaling & Corrosion Indicators -->
            <div class="space-y-2 text-xs font-mono">
              <div class="flex justify-between items-center bg-slate-950 p-2 rounded-lg border border-slate-800">
                <span class="text-slate-400">Calcite Langelier SI:</span>
                <span class="text-slate-200 font-bold">{{ twin().chemistry.calciteSaturationIndex }} (Nominal)</span>
              </div>
              <div class="flex justify-between items-center bg-slate-950 p-2 rounded-lg border border-slate-800">
                <span class="text-slate-400">Ryznar Stability Index:</span>
                <span class="text-slate-200 font-bold">{{ twin().chemistry.ryznarStabilityIndex }} (Balanced)</span>
              </div>
              <div class="flex justify-between items-center bg-slate-950 p-2 rounded-lg border border-slate-800">
                <span class="text-slate-400">Corrosion Risk Indicator:</span>
                <span class="capitalize px-2 py-0.5 rounded font-bold" [class]="twin().chemistry.corrosionRiskIndicator === 'low' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-amber-500/10 text-amber-400'">
                  {{ twin().chemistry.corrosionRiskIndicator }}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class GeochemistryPage {
  private physics = inject(PhysicsEngineService);
  readonly twin = this.physics.twin;

  cleanHex(): void {
    this.physics.cleanHeatExchangers();
  }
}
