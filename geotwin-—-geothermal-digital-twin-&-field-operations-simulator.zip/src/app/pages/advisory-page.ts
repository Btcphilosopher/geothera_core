import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PhysicsEngineService } from '../services/physics-engine.service';
import { GeminiAdvisoryService } from '../services/gemini-advisory.service';

@Component({
  selector: 'app-advisory-page',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Title Card -->
      <div class="bg-slate-900/90 rounded-2xl border border-slate-800 p-4">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <div class="flex items-center gap-2">
              <mat-icon class="text-emerald-400">psychology</mat-icon>
              <h2 class="text-base font-bold text-slate-100 uppercase tracking-wide">Gemini Geothermal Operations & Subsurface Copilot</h2>
            </div>
            <p class="text-xs text-slate-400 mt-0.5">
              Live physics-coupled thermodynamic diagnostics, geochemical scaling risk evaluations and real-time SCADA optimization advisor
            </p>
          </div>

          <div class="flex items-center gap-2">
            <button 
              (click)="triggerQuickAnalysis('Full Thermodynamic & Reservoir Health Diagnostic')"
              [disabled]="advisor.isAnalyzing()"
              class="px-3.5 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-mono font-bold flex items-center gap-1.5 transition-colors disabled:opacity-50">
              <mat-icon class="!text-sm !w-4 !h-4">auto_awesome</mat-icon>
              {{ advisor.isAnalyzing() ? 'Analyzing Physics State...' : 'Run Copilot Diagnostic' }}
            </button>
          </div>
        </div>
      </div>

      <!-- Quick Analysis Prompts -->
      <div class="flex flex-wrap gap-2 text-xs">
        <button 
          (click)="triggerQuickAnalysis('Analyze Thermal Breakthrough Risk and recommend injection redistribution')"
          class="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 font-mono transition-colors">
          ❄️ Thermal Breakthrough Mitigation
        </button>
        <button 
          (click)="triggerQuickAnalysis('Evaluate Silica Scaling Kinetics (SSI) in Vaporizer HEX and descaling schedule')"
          class="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 font-mono transition-colors">
          🧪 Silica SSI & HEX Fouling Diagnostic
        </button>
        <button 
          (click)="triggerQuickAnalysis('Assess Induced Seismicity Traffic Light System thresholds and pore pressure dissipation')"
          class="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 font-mono transition-colors">
          ⚡ Induced Seismicity & TLS Red Protocol
        </button>
        <button 
          (click)="triggerQuickAnalysis('Optimize Net Electrical Generation vs District Heating cogeneration dispatch')"
          class="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 font-mono transition-colors">
          ⚡ Power vs District Heat Dispatch
        </button>
      </div>

      <!-- Copilot Output Panel -->
      <div class="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 min-h-[420px] flex flex-col justify-between">
        <div>
          <div class="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
            <div class="flex items-center gap-2">
              <mat-icon class="text-emerald-400">terminal</mat-icon>
              <h3 class="text-sm font-bold text-slate-100 uppercase tracking-wide">Engineering Advisory Synthesis</h3>
            </div>
            @if (advisor.analysisSource()) {
              <span class="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded-full border border-emerald-500/20">
                Engine: {{ advisor.analysisSource() }}
              </span>
            }
          </div>

          @if (advisor.isAnalyzing()) {
            <div class="py-16 flex flex-col items-center justify-center gap-3">
              <div class="w-8 h-8 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin"></div>
              <p class="text-xs font-mono text-slate-400">Assimilating 600 reservoir grid cells, well hydraulics & ORC cycle data...</p>
            </div>
          } @else if (advisor.analysisOutput()) {
            <div class="prose prose-invert max-w-none text-xs leading-relaxed font-mono whitespace-pre-wrap text-slate-200 bg-slate-950 p-4 rounded-xl border border-slate-800/80">
              {{ advisor.analysisOutput() }}
            </div>
          } @else {
            <div class="py-16 text-center text-slate-500 font-mono text-xs">
              <mat-icon class="!text-3xl !w-8 !h-8 text-slate-600 mb-2">auto_awesome</mat-icon>
              <p>Click "Run Copilot Diagnostic" or select a specialized geothermal query above.</p>
            </div>
          }
        </div>

        <div class="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-[10px] font-mono text-slate-500">
          <span>Coupled Model Snapshot: FIELD: {{ twin().fieldCode }} | T_res: {{ twin().reservoir.averageTemperature }}°C | P_net: {{ twin().balances.netElectricalPowerMW }} MWe</span>
          <span>Zero Hallucination Physics-Grounded Analysis</span>
        </div>
      </div>
    </div>
  `,
})
export class AdvisoryPage {
  private physics = inject(PhysicsEngineService);
  readonly advisor = inject(GeminiAdvisoryService);
  readonly twin = this.physics.twin;

  triggerQuickAnalysis(query: string): void {
    this.advisor.requestAdvisory(this.twin(), query);
  }
}
