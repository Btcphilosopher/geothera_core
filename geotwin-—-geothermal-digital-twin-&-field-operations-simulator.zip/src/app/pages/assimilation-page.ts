import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PhysicsEngineService } from '../services/physics-engine.service';
import { ScenarioEngineService } from '../services/scenario-engine.service';

@Component({
  selector: 'app-assimilation-page',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Top Title & EnKF Execution Card -->
      <div class="bg-slate-900/90 rounded-2xl border border-slate-800 p-4">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <div class="flex items-center gap-2">
              <mat-icon class="text-emerald-400">auto_mode</mat-icon>
              <h2 class="text-base font-bold text-slate-100 uppercase tracking-wide">Data Assimilation & History Matching (EnKF / ESMDA)</h2>
            </div>
            <p class="text-xs text-slate-400 mt-0.5">
              Bayesian parameter estimation assimilating downhole pressure, DTS temperature & tracer response across 50 ensemble realizations
            </p>
          </div>

          <button 
            (click)="scenarios.runDataAssimilation()"
            class="px-4 py-2 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-mono font-bold flex items-center gap-2 transition-colors">
            <mat-icon class="!text-sm !w-4 !h-4">dataset</mat-icon>
            Ingest Telemetry & Run EnKF Step
          </button>
        </div>
      </div>

      <!-- EnKF Statistics Strip -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div class="bg-slate-900/90 p-4 rounded-2xl border border-slate-800">
          <span class="text-slate-500 text-xs block font-mono">Assimilation Algorithm</span>
          <span class="font-mono text-lg font-bold text-slate-100 mt-1 block">
            {{ twin().dataAssimilation.algorithm }} (50 Realizations)
          </span>
          <span class="text-[10px] text-slate-400">Iterative Ensemble Smoother</span>
        </div>

        <div class="bg-slate-900/90 p-4 rounded-2xl border border-slate-800">
          <span class="text-slate-500 text-xs block font-mono">Current Iteration</span>
          <span class="font-mono text-xl font-bold text-emerald-400 mt-1 block">
            Iteration #{{ twin().dataAssimilation.currentIteration }}
          </span>
          <span class="text-[10px] text-slate-400">EnKF state vector updated</span>
        </div>

        <div class="bg-slate-900/90 p-4 rounded-2xl border border-slate-800">
          <span class="text-slate-500 text-xs block font-mono">History Match Misfit (J)</span>
          <span class="font-mono text-xl font-bold text-amber-400 mt-1 block">
            J = {{ twin().dataAssimilation.misfitObjective }}
          </span>
          <span class="text-[10px] text-slate-400">Objective error norm</span>
        </div>

        <div class="bg-slate-900/90 p-4 rounded-2xl border border-slate-800">
          <span class="text-slate-500 text-xs block font-mono">Uncertainty Reduction</span>
          <span class="font-mono text-xl font-bold text-cyan-400 mt-1 block">
            {{ twin().dataAssimilation.historyMatchErrorReductionPercent }}%
          </span>
          <span class="text-[10px] text-slate-400">Variance contraction</span>
        </div>
      </div>

      <!-- Prior vs Posterior Parameter Distribution Table -->
      <div class="bg-slate-900/90 rounded-2xl border border-slate-800 p-4">
        <div class="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
          <div class="flex items-center gap-2">
            <mat-icon class="text-cyan-400">query_stats</mat-icon>
            <h3 class="text-sm font-bold text-slate-100 uppercase tracking-wide">Calibrated Subsurface Reservoir Parameters</h3>
          </div>
          <span class="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
            Bayesian Conditioning Active
          </span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs font-mono">
            <thead>
              <tr class="text-slate-500 border-b border-slate-800 pb-2">
                <th class="pb-2 font-normal">PARAMETER DESCRIPTION</th>
                <th class="pb-2 font-normal">PRIOR MEAN (μ_prior)</th>
                <th class="pb-2 font-normal">PRIOR STD (σ_prior)</th>
                <th class="pb-2 font-normal">POSTERIOR MEAN (μ_post)</th>
                <th class="pb-2 font-normal">POSTERIOR STD (σ_post)</th>
                <th class="pb-2 font-normal">VARIANCE REDUCTION</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60">
              @for (p of twin().dataAssimilation.assimilatedParameters; track p.parameter) {
                <tr class="hover:bg-slate-950/60 transition-colors">
                  <td class="py-3 text-slate-200 font-semibold">{{ p.parameter }}</td>
                  <td class="py-3 text-slate-400">{{ p.priorMean }} {{ p.unit }}</td>
                  <td class="py-3 text-slate-400">±{{ p.priorStd }} {{ p.unit }}</td>
                  <td class="py-3 text-emerald-400 font-bold">{{ p.posteriorMean }} {{ p.unit }}</td>
                  <td class="py-3 text-emerald-400 font-bold">±{{ p.posteriorStd }} {{ p.unit }}</td>
                  <td class="py-3">
                    <span class="px-2 py-0.5 rounded font-bold bg-cyan-500/10 text-cyan-300 border border-cyan-500/30">
                      -{{ (((p.priorStd - p.posteriorStd) / p.priorStd) * 100).toFixed(0) }}% σ
                    </span>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
})
export class AssimilationPage {
  private physics = inject(PhysicsEngineService);
  readonly scenarios = inject(ScenarioEngineService);
  readonly twin = this.physics.twin;
}
