import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PhysicsEngineService } from '../services/physics-engine.service';
import { ScenarioEngineService, ParetoPoint } from '../services/scenario-engine.service';

@Component({
  selector: 'app-scenarios-page',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Title Card & Active Scenario Header -->
      <div class="bg-slate-900/90 rounded-2xl border border-slate-800 p-4">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <div class="flex items-center gap-2">
              <mat-icon class="text-amber-400">tune</mat-icon>
              <h2 class="text-base font-bold text-slate-100 uppercase tracking-wide">Multi-Objective Pareto Optimisation & 30-Year Forecast</h2>
            </div>
            <p class="text-xs text-slate-400 mt-0.5">
              Trade-space analysis (Power vs Reservoir Longevity vs Seismicity) & 10,000-sample Monte Carlo uncertainty quantification
            </p>
          </div>

          <div class="px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono">
            <span class="text-slate-500">Current Scenario:</span>
            <span class="text-amber-400 font-bold ml-1.5">{{ scenarios.activeScenarioName() }}</span>
          </div>
        </div>
      </div>

      <!-- Multi-Objective Pareto Frontier Trade-Space -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Pareto Frontier Visualizer -->
        <div class="lg:col-span-7 bg-slate-900/90 rounded-2xl border border-slate-800 p-4">
          <div class="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-emerald-400">scatter_plot</mat-icon>
              <div>
                <h3 class="text-sm font-bold text-slate-100 uppercase tracking-wide">Pareto Optimal Trade-Off Space</h3>
                <p class="text-[11px] text-slate-400">Net Electrical Power Output (MWe) vs Reservoir Thermal Lifetime (Years)</p>
              </div>
            </div>
            <span class="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
              Non-Dominated Solutions
            </span>
          </div>

          <!-- SVG Pareto Frontier Graph -->
          <div class="relative w-full h-[260px] bg-slate-950 rounded-xl border border-slate-800/80 p-3">
            <svg class="w-full h-full" viewBox="0 0 500 220" preserveAspectRatio="none">
              <!-- Grid lines -->
              <line x1="50" y1="20" x2="470" y2="20" stroke="#1e293b" stroke-dasharray="2 4" />
              <line x1="50" y1="65" x2="470" y2="65" stroke="#1e293b" stroke-dasharray="2 4" />
              <line x1="50" y1="110" x2="470" y2="110" stroke="#1e293b" stroke-dasharray="2 4" />
              <line x1="50" y1="155" x2="470" y2="155" stroke="#1e293b" stroke-dasharray="2 4" />
              <line x1="50" y1="195" x2="470" y2="195" stroke="#334155" />

              <!-- Y-Axis (Power MWe) -->
              <text x="10" y="25" fill="#64748b" font-size="9" font-family="monospace">30 MWe</text>
              <text x="10" y="115" fill="#64748b" font-size="9" font-family="monospace">20 MWe</text>
              <text x="10" y="195" fill="#64748b" font-size="9" font-family="monospace">10 MWe</text>

              <!-- X-Axis (Reservoir Lifetime Years) -->
              <text x="50" y="212" fill="#64748b" font-size="9" font-family="monospace">15 yrs</text>
              <text x="180" y="212" fill="#64748b" font-size="9" font-family="monospace">25 yrs</text>
              <text x="310" y="212" fill="#64748b" font-size="9" font-family="monospace">35 yrs</text>
              <text x="440" y="212" fill="#64748b" font-size="9" font-family="monospace">45 yrs</text>

              <!-- Convex Pareto Curve (Amber) -->
              <path 
                d="M 80,35 Q 160,80 250,110 T 430,165" 
                fill="none" 
                stroke="#f59e0b" 
                stroke-width="2.5" 
                stroke-dasharray="4 3" 
              />

              <!-- Interactive Points -->
              @for (pt of scenarios.paretoPoints(); track pt.id) {
                <!-- Calculate SVG coordinates -->
                @let cx = 80 + (pt.reservoirLifetimeYears - 18) * 14;
                @let cy = 35 + (28.5 - pt.netPowerMW) * 14;

                <circle 
                  [attr.cx]="cx" 
                  [attr.cy]="cy" 
                  [attr.r]="scenarios.selectedParetoPoint().id === pt.id ? 8 : 5" 
                  [attr.fill]="pt.recommended ? '#10b981' : '#38bdf8'"
                  [attr.stroke]="scenarios.selectedParetoPoint().id === pt.id ? '#ffffff' : '#0f172a'"
                  stroke-width="2"
                  class="cursor-pointer transition-all hover:scale-125"
                  (click)="selectPareto(pt)"
                />
              }
            </svg>
          </div>

          <div class="flex items-center justify-between text-[11px] font-mono text-slate-400 mt-2 px-2">
            <span class="flex items-center gap-1.5 text-emerald-400">
              <span class="w-2.5 h-2.5 rounded-full bg-emerald-500"></span> Recommended Balanced Operating Point
            </span>
            <span class="text-slate-500">Click any node to apply SCADA operating targets</span>
          </div>
        </div>

        <!-- Selected Operating Target Details -->
        <div class="lg:col-span-5 bg-slate-900/90 rounded-2xl border border-slate-800 p-4 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
              <h3 class="text-sm font-bold text-slate-100 uppercase tracking-wide">Selected Operating Regime</h3>
              <span class="font-mono text-xs text-amber-400 font-bold">{{ scenarios.selectedParetoPoint().name }}</span>
            </div>

            <div class="space-y-2.5 text-xs font-mono">
              <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex justify-between">
                <span class="text-slate-400">Net Electrical Power:</span>
                <span class="text-emerald-400 font-bold text-sm">{{ scenarios.selectedParetoPoint().netPowerMW }} MWe</span>
              </div>
              <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex justify-between">
                <span class="text-slate-400">Thermal Longevity:</span>
                <span class="text-cyan-400 font-bold text-sm">{{ scenarios.selectedParetoPoint().reservoirLifetimeYears }} Years</span>
              </div>
              <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex justify-between">
                <span class="text-slate-400">Induced Seismicity Risk:</span>
                <span class="font-bold" [class]="scenarios.selectedParetoPoint().seismicRiskIndex > 5 ? 'text-rose-400' : 'text-emerald-400'">
                  {{ scenarios.selectedParetoPoint().seismicRiskIndex }} / 10
                </span>
              </div>
              <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex justify-between">
                <span class="text-slate-400">Target Field Production:</span>
                <span class="text-slate-200">{{ scenarios.selectedParetoPoint().productionFlowKgS }} kg/s</span>
              </div>
              <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex justify-between">
                <span class="text-slate-400">Levelized Cost (LCOE):</span>
                <span class="text-amber-400 font-bold">{{ scenarios.selectedParetoPoint().lcoeUSDPerMWh }} $/MWh</span>
              </div>
            </div>
          </div>

          <!-- Apply Button -->
          <button 
            (click)="selectPareto(scenarios.selectedParetoPoint())"
            class="mt-4 w-full py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-mono font-bold text-xs transition-colors flex items-center justify-center gap-2">
            <mat-icon class="!text-sm !w-4 !h-4">check_circle</mat-icon>
            Apply Selected Pareto Dispatch
          </button>
        </div>
      </div>

      <!-- 10,000-Run Monte Carlo Uncertainty Quantification Table -->
      <div class="bg-slate-900/90 rounded-2xl border border-slate-800 p-4">
        <div class="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
          <div class="flex items-center gap-2">
            <mat-icon class="text-purple-400">analytics</mat-icon>
            <h3 class="text-sm font-bold text-slate-100 uppercase tracking-wide">10,000-Run Monte Carlo Reservoir Uncertainty (P10 / P50 / P90)</h3>
          </div>
          <span class="text-[10px] font-mono text-purple-400 bg-purple-500/10 px-2 py-0.5 rounded border border-purple-500/20">
            Latin Hypercube Sampling
          </span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
          <div class="bg-slate-950 p-3 rounded-xl border border-slate-800">
            <div class="text-slate-400 font-semibold mb-2">Net Electrical Power Output (MWe)</div>
            <div class="space-y-1">
              <div class="flex justify-between"><span class="text-slate-500">P10 (High Case):</span><span class="text-emerald-400 font-bold">{{ twin().monteCarlo.p10PowerMW }} MWe</span></div>
              <div class="flex justify-between"><span class="text-slate-500">P50 (Median Case):</span><span class="text-slate-200 font-bold">{{ twin().monteCarlo.p50PowerMW }} MWe</span></div>
              <div class="flex justify-between"><span class="text-slate-500">P90 (Conservative):</span><span class="text-amber-400 font-bold">{{ twin().monteCarlo.p90PowerMW }} MWe</span></div>
            </div>
          </div>

          <div class="bg-slate-950 p-3 rounded-xl border border-slate-800">
            <div class="text-slate-400 font-semibold mb-2">Thermal Field Lifetime (Years)</div>
            <div class="space-y-1">
              <div class="flex justify-between"><span class="text-slate-500">P10 (High Case):</span><span class="text-emerald-400 font-bold">{{ twin().monteCarlo.p10LifetimeYears }} Years</span></div>
              <div class="flex justify-between"><span class="text-slate-500">P50 (Median Case):</span><span class="text-slate-200 font-bold">{{ twin().monteCarlo.p50LifetimeYears }} Years</span></div>
              <div class="flex justify-between"><span class="text-slate-500">P90 (Conservative):</span><span class="text-amber-400 font-bold">{{ twin().monteCarlo.p90LifetimeYears }} Years</span></div>
            </div>
          </div>

          <div class="bg-slate-950 p-3 rounded-xl border border-slate-800">
            <div class="text-slate-400 font-semibold mb-2">Thermal Breakthrough Arrival</div>
            <div class="space-y-1">
              <div class="flex justify-between"><span class="text-slate-500">P10 (Slow Sweep):</span><span class="text-emerald-400 font-bold">Year {{ twin().monteCarlo.p10ThermalBreakthroughYear }}</span></div>
              <div class="flex justify-between"><span class="text-slate-500">P50 (Median Sweep):</span><span class="text-slate-200 font-bold">Year {{ twin().monteCarlo.p50ThermalBreakthroughYear }}</span></div>
              <div class="flex justify-between"><span class="text-slate-500">P90 (Rapid Channelling):</span><span class="text-amber-400 font-bold">Year {{ twin().monteCarlo.p90ThermalBreakthroughYear }}</span></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class ScenariosPage {
  private physics = inject(PhysicsEngineService);
  readonly scenarios = inject(ScenarioEngineService);
  readonly twin = this.physics.twin;

  selectPareto(pt: ParetoPoint): void {
    this.scenarios.selectParetoPoint(pt);
  }
}
