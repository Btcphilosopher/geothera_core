import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PhysicsEngineService } from '../services/physics-engine.service';

@Component({
  selector: 'app-economics-page',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Title Card -->
      <div class="bg-slate-900/90 rounded-2xl border border-slate-800 p-4">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <div class="flex items-center gap-2">
              <mat-icon class="text-emerald-400">payments</mat-icon>
              <h2 class="text-base font-bold text-slate-100 uppercase tracking-wide">Field Economics, Life-Cycle Carbon Accounting & Engineering Audit</h2>
            </div>
            <p class="text-xs text-slate-400 mt-0.5">
              Financial model (CAPEX, OPEX, LCOE, NPV, IRR), Scope 1-3 emissions inventory and comprehensive field engineering summary report
            </p>
          </div>

          <button 
            (click)="printReport()"
            class="px-4 py-2 rounded-xl bg-slate-950 hover:bg-slate-800 text-slate-200 border border-slate-700 text-xs font-mono font-bold flex items-center gap-1.5 transition-colors">
            <mat-icon class="!text-sm !w-4 !h-4 text-emerald-400">print</mat-icon>
            Export Engineering Report
          </button>
        </div>
      </div>

      <!-- Financial KPI Cards -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div class="bg-slate-900/90 p-4 rounded-2xl border border-slate-800">
          <span class="text-slate-500 text-xs block font-mono">Levelized Cost (LCOE)</span>
          <span class="font-mono text-2xl font-bold text-emerald-400 mt-1 block">
            {{ twin().economics.lcoeUSDPerMWh }} $/MWh
          </span>
          <span class="text-[10px] text-slate-400">Dispatched baseload</span>
        </div>

        <div class="bg-slate-900/90 p-4 rounded-2xl border border-slate-800">
          <span class="text-slate-500 text-xs block font-mono">Net Present Value (NPV)</span>
          <span class="font-mono text-2xl font-bold text-slate-100 mt-1 block">
            \${{ twin().economics.npvMillionUSD }}M
          </span>
          <span class="text-[10px] text-slate-400">30-yr @ 7.5% discount rate</span>
        </div>

        <div class="bg-slate-900/90 p-4 rounded-2xl border border-slate-800">
          <span class="text-slate-500 text-xs block font-mono">Internal Rate of Return (IRR)</span>
          <span class="font-mono text-2xl font-bold text-amber-400 mt-1 block">
            {{ twin().economics.irrPercent }}%
          </span>
          <span class="text-[10px] text-slate-400">Payback: {{ twin().economics.paybackYears }} yrs</span>
        </div>

        <div class="bg-slate-900/90 p-4 rounded-2xl border border-slate-800">
          <span class="text-slate-500 text-xs block font-mono">Annual Gross Revenue</span>
          <span class="font-mono text-2xl font-bold text-cyan-400 mt-1 block">
            \${{ twin().economics.annualRevenueMillionUSD }}M / yr
          </span>
          <span class="text-[10px] text-slate-400">Power + Heat + Lithium</span>
        </div>
      </div>

      <!-- CAPEX Breakdown & Carbon Accounting -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- CAPEX/OPEX Breakdown -->
        <div class="lg:col-span-6 bg-slate-900/90 rounded-2xl border border-slate-800 p-4">
          <div class="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-amber-400">account_balance</mat-icon>
              <h3 class="text-sm font-bold text-slate-100 uppercase tracking-wide">Capital & Operating Expenditure</h3>
            </div>
            <span class="text-xs font-mono text-slate-400">Total CAPEX: \${{ twin().economics.totalCapexM }}M</span>
          </div>

          <div class="space-y-2.5 text-xs font-mono">
            <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex justify-between">
              <span class="text-slate-400">Deep Drilling CAPEX (6 Wells):</span>
              <span class="text-slate-200 font-bold">\${{ twin().economics.drillingCapexM }}M</span>
            </div>
            <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex justify-between">
              <span class="text-slate-400">Surface Binary ORC Plant CAPEX:</span>
              <span class="text-slate-200 font-bold">\${{ twin().economics.surfacePlantCapexM }}M</span>
            </div>
            <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex justify-between">
              <span class="text-slate-400">132 kV Substation & Interconnection:</span>
              <span class="text-slate-200 font-bold">\${{ twin().economics.gridInterconnectionCapexM }}M</span>
            </div>
            <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex justify-between">
              <span class="text-slate-400">Fixed Operating Cost (OPEX):</span>
              <span class="text-amber-400 font-bold">\${{ twin().economics.fixedOpexMPerYear }}M / year</span>
            </div>
            <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex justify-between">
              <span class="text-slate-400">Variable Operating Cost:</span>
              <span class="text-slate-200">\${{ twin().economics.variableOpexPerMWh }} / MWh</span>
            </div>
          </div>
        </div>

        <!-- Carbon Life-Cycle Inventory -->
        <div class="lg:col-span-6 bg-slate-900/90 rounded-2xl border border-slate-800 p-4">
          <div class="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-emerald-400">eco</mat-icon>
              <h3 class="text-sm font-bold text-slate-100 uppercase tracking-wide">GHG Emissions & Life-Cycle Carbon</h3>
            </div>
            <span class="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
              Closed Binary Loop
            </span>
          </div>

          <div class="space-y-2.5 text-xs font-mono">
            <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex justify-between">
              <span class="text-slate-400">Scope 1 (Fugitive Non-Condensable Gases):</span>
              <span class="text-emerald-400 font-bold">{{ twin().carbon.scope1KgCO2ePerMWh }} kgCO₂e/MWh</span>
            </div>
            <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex justify-between">
              <span class="text-slate-400">Scope 2 (Auxiliary Islanded Power):</span>
              <span class="text-emerald-400 font-bold">{{ twin().carbon.scope2KgCO2ePerMWh }} kgCO₂e/MWh</span>
            </div>
            <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex justify-between">
              <span class="text-slate-400">Scope 3 (Life-cycle Steel, Cement & Drilling):</span>
              <span class="text-slate-200 font-bold">{{ twin().carbon.scope3KgCO2ePerMWh }} kgCO₂e/MWh</span>
            </div>
            <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex justify-between">
              <span class="text-slate-400">Total Intensity vs Fossil Grid (400 kg):</span>
              <span class="text-emerald-300 font-bold">{{ twin().carbon.totalKgCO2ePerMWh }} kgCO₂e/MWh (-95%)</span>
            </div>
            <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex justify-between">
              <span class="text-slate-400">Annual Net Avoided CO₂ Emissions:</span>
              <span class="text-emerald-400 font-bold">{{ twin().carbon.avoidedEmissionsTonsPerYear }} tCO₂e / yr</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Formal Engineering Audit Report Section (Printable Format) -->
      <div class="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 print:p-0 print:border-none">
        <div class="border-b border-slate-800 pb-4 mb-4">
          <div class="flex items-center justify-between">
            <div>
              <h1 class="text-lg font-bold text-slate-100 uppercase tracking-widest font-mono">
                GEOTHERMAL FIELD DIGITAL TWIN AUDIT REPORT
              </h1>
              <p class="text-xs text-slate-400 font-mono mt-1">
                FIELD: {{ twin().fieldCode }} | MODEL: {{ twin().version }} | ARCHITECTURE: {{ twin().architecture | uppercase }}
              </p>
            </div>
            <span class="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-lg border border-emerald-500/30">
              VERIFIED SYNTHETIC BENCHMARK
            </span>
          </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs font-mono text-slate-300">
          <div class="space-y-1.5">
            <div class="font-bold text-emerald-400 border-b border-slate-800 pb-1">1. RESERVOIR & THERMAL STATE</div>
            <div>Average Res. Temperature: <span class="text-slate-100 font-bold">{{ twin().reservoir.averageTemperature }}°C</span></div>
            <div>Average Res. Pressure: <span class="text-slate-100 font-bold">{{ twin().reservoir.averagePressure }} bar</span></div>
            <div>Active Thermal Sweep Vol: <span class="text-slate-100">{{ (twin().reservoir.activeThermalSweepVolumeM3 / 1e6).toFixed(1) }}M m³</span></div>
            <div>Breakthrough Position: <span class="text-slate-100">{{ twin().reservoir.thermalBreakthroughFrontDistanceM }}m</span></div>
            <div>Est. Field Longevity: <span class="text-slate-100 font-bold">{{ twin().reservoir.estimatedBreakthroughYears }} yrs</span></div>
          </div>

          <div class="space-y-1.5">
            <div class="font-bold text-purple-400 border-b border-slate-800 pb-1">2. PLANT & ORC THERMODYNAMICS</div>
            <div>Working Fluid: <span class="text-slate-100 font-bold">{{ twin().workingFluid.name }}</span></div>
            <div>Thermal Energy In: <span class="text-slate-100 font-bold">{{ twin().balances.thermalEnergyInMWth }} MWth</span></div>
            <div>Gross Turbine Power: <span class="text-slate-100 font-bold">{{ twin().balances.grossElectricalPowerMW }} MWe</span></div>
            <div>Net Grid Export Power: <span class="text-slate-100 font-bold">{{ twin().balances.netElectricalPowerMW }} MWe</span></div>
            <div>District Heat Supplied: <span class="text-slate-100 font-bold">{{ twin().balances.districtHeatDeliveredMWth }} MWth</span></div>
          </div>

          <div class="space-y-1.5">
            <div class="font-bold text-amber-400 border-b border-slate-800 pb-1">3. GEOCHEMISTRY & SEISMICITY</div>
            <div>Silica Saturation (SSI): <span class="text-slate-100 font-bold">{{ twin().chemistry.silicaSaturationIndex }}</span></div>
            <div>Calcite Langelier SI: <span class="text-slate-100 font-bold">{{ twin().chemistry.calciteSaturationIndex }}</span></div>
            <div>Lithium DLE Yield: <span class="text-slate-100 font-bold">{{ twin().chemistry.lithiumExtractionPotentialKgDay }} kg/day</span></div>
            <div>Max Seismicity (24h): <span class="text-slate-100 font-bold">Mw {{ twin().seismicity.maxMagnitudePast24h }}</span></div>
            <div>TLS Traffic Protocol: <span class="text-slate-100 font-bold">{{ twin().seismicity.trafficLightStatus | uppercase }}</span></div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class EconomicsPage {
  private physics = inject(PhysicsEngineService);
  readonly twin = this.physics.twin;

  printReport(): void {
    if (typeof window !== 'undefined') {
      window.print();
    }
  }
}
