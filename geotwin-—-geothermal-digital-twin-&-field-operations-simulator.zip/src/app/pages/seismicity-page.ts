import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PhysicsEngineService } from '../services/physics-engine.service';
import { ScenarioEngineService } from '../services/scenario-engine.service';

@Component({
  selector: 'app-seismicity-page',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Top Title Card & TLS Banner -->
      <div class="bg-slate-900/90 rounded-2xl border border-slate-800 p-4">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <div class="flex items-center gap-2">
              <mat-icon class="text-rose-400">sensors</mat-icon>
              <h2 class="text-base font-bold text-slate-100 uppercase tracking-wide">EGS Induced Seismicity & Microseismic Cloud Digital Twin</h2>
            </div>
            <p class="text-xs text-slate-400 mt-0.5">
              Shapiro Pore Pressure Diffusion Front, Gutenberg-Richter (b-value) & Real-time Traffic Light System (TLS) Protocol
            </p>
          </div>

          <!-- Traffic Light Status Badge -->
          <div class="flex items-center gap-3">
            <div class="flex items-center gap-2 px-3.5 py-1.5 rounded-xl border font-mono text-xs font-bold"
              [class]="twin().seismicity.trafficLightStatus === 'green' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' : twin().seismicity.trafficLightStatus === 'amber' ? 'bg-amber-500/10 text-amber-400 border-amber-500/30' : 'bg-rose-500/20 text-rose-400 border-rose-500/50 animate-pulse'">
              <span class="w-3 h-3 rounded-full"
                [class]="twin().seismicity.trafficLightStatus === 'green' ? 'bg-emerald-500' : twin().seismicity.trafficLightStatus === 'amber' ? 'bg-amber-500' : 'bg-rose-500'"></span>
              TLS PROTOCOL: {{ twin().seismicity.trafficLightStatus | uppercase }}
            </div>

            <button 
              (click)="scenarios.applyInducedSeismicityScenario()"
              class="px-3 py-1.5 rounded-xl bg-slate-950 hover:bg-slate-800 text-rose-400 border border-rose-500/30 text-xs font-mono font-bold flex items-center gap-1.5 transition-colors">
              <mat-icon class="!text-sm !w-4 !h-4">bolt</mat-icon>
              Trigger Overpressure Mw Event
            </button>
          </div>
        </div>

        <div class="mt-3 py-1.5 px-3 bg-slate-950/80 rounded-lg border border-slate-800 text-[10px] font-mono text-slate-400 flex items-center gap-2">
          <mat-icon class="!text-xs !w-3.5 !h-3.5 text-amber-400">info</mat-icon>
          <span>SIMULATED SYNTHETIC INDUCED SEISMICITY MODEL — NOT A REAL-WORLD EARTHQUAKE FORECAST (Academic/Engineering Digital Twin Benchmark).</span>
        </div>
      </div>

      <!-- Physics Metrics & Gutenberg-Richter Parameters -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div class="bg-slate-900/90 p-4 rounded-2xl border border-slate-800">
          <span class="text-slate-500 text-xs block font-mono">Max Event Past 24h</span>
          <span class="font-mono text-xl font-bold mt-1 block" [class]="twin().seismicity.maxMagnitudePast24h >= 1.5 ? 'text-rose-400' : 'text-slate-100'">
            M_w {{ twin().seismicity.maxMagnitudePast24h }}
          </span>
          <span class="text-[10px] text-slate-400">Amber: ≥0.5 Mw | Red: ≥1.5 Mw</span>
        </div>

        <div class="bg-slate-900/90 p-4 rounded-2xl border border-slate-800">
          <span class="text-slate-500 text-xs block font-mono">Gutenberg-Richter b-Value</span>
          <span class="font-mono text-xl font-bold text-emerald-400 mt-1 block">
            b = {{ twin().seismicity.bValue }}
          </span>
          <span class="text-[10px] text-slate-400">Fracture criticality slope</span>
        </div>

        <div class="bg-slate-900/90 p-4 rounded-2xl border border-slate-800">
          <span class="text-slate-500 text-xs block font-mono">Pore Overpressure (ΔP)</span>
          <span class="font-mono text-xl font-bold text-amber-400 mt-1 block">
            +{{ twin().seismicity.porePressurePerturbationMaxBar }} bar
          </span>
          <span class="text-[10px] text-slate-400">At fault intersection (DFN-01)</span>
        </div>

        <div class="bg-slate-900/90 p-4 rounded-2xl border border-slate-800">
          <span class="text-slate-500 text-xs block font-mono">Hydraulic Diffusivity (D)</span>
          <span class="font-mono text-xl font-bold text-cyan-400 mt-1 block">
            {{ twin().seismicity.hydraulicDiffusivityM2s }} m²/s
          </span>
          <span class="text-[10px] text-slate-400">Shapiro diffusion r = √(4πDt)</span>
        </div>
      </div>

      <!-- Real-Time Microseismic Event Cloud Log Table -->
      <div class="bg-slate-900/90 rounded-2xl border border-slate-800 p-4">
        <div class="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
          <div class="flex items-center gap-2">
            <mat-icon class="text-amber-400">list_alt</mat-icon>
            <h3 class="text-sm font-bold text-slate-100 uppercase tracking-wide">Downhole Geophone Microseismic Event Stream (Live Telemetry)</h3>
          </div>
          <span class="text-xs font-mono text-slate-400">Total Catalogued: {{ twin().seismicity.events.length }} events</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs font-mono">
            <thead>
              <tr class="text-slate-500 border-b border-slate-800 pb-2">
                <th class="pb-2 font-normal">EVENT ID</th>
                <th class="pb-2 font-normal">MOMENT MAGNITUDE (Mw)</th>
                <th class="pb-2 font-normal">FOCAL DEPTH (Z)</th>
                <th class="pb-2 font-normal">COORDINATES (X, Y)</th>
                <th class="pb-2 font-normal">SOURCE RADIUS</th>
                <th class="pb-2 font-normal">STRESS DROP</th>
                <th class="pb-2 font-normal">NEAREST WELL</th>
                <th class="pb-2 font-normal">FAULT DISTANCE</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60">
              @for (ev of twin().seismicity.events.slice(0, 15); track ev.id) {
                <tr class="hover:bg-slate-950/60 transition-colors">
                  <td class="py-2 text-slate-400">{{ ev.id }}</td>
                  <td class="py-2 font-bold" [class]="ev.magnitude >= 1.5 ? 'text-rose-400' : ev.magnitude >= 0.5 ? 'text-amber-400' : 'text-emerald-400'">
                    Mw {{ ev.magnitude }}
                  </td>
                  <td class="py-2 text-slate-200">{{ ev.z }} m TVD</td>
                  <td class="py-2 text-slate-300">({{ ev.x }}m, {{ ev.y }}m)</td>
                  <td class="py-2 text-slate-300">{{ ev.sourceRadius }} m</td>
                  <td class="py-2 text-slate-300">{{ ev.stressDropMPa }} MPa</td>
                  <td class="py-2 text-cyan-400">{{ ev.nearestWellId }}</td>
                  <td class="py-2 text-slate-400">{{ ev.distanceToFaultM }} m</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
})
export class SeismicityPage {
  private physics = inject(PhysicsEngineService);
  readonly scenarios = inject(ScenarioEngineService);
  readonly twin = this.physics.twin;
}
