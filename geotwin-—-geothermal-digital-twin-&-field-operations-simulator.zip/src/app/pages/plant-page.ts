import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PhysicsEngineService } from '../services/physics-engine.service';
import { WorkingFluidType, CoolingType, GridDispatchMode } from '../models/geothermal.model';
import { WORKING_FLUIDS } from '../utils/thermodynamics';
import { PlantSchematic } from '../components/plant-schematic';

@Component({
  selector: 'app-plant-page',
  imports: [CommonModule, MatIconModule, PlantSchematic],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Title & Working Fluid Selector Banner -->
      <div class="bg-slate-900/90 rounded-2xl border border-slate-800 p-4">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <div class="flex items-center gap-2">
              <mat-icon class="text-purple-400">heat_pump</mat-icon>
              <h2 class="text-base font-bold text-slate-100 uppercase tracking-wide">Surface Power Plant & Binary ORC Thermodynamic Cycle</h2>
            </div>
            <p class="text-xs text-slate-400 mt-0.5">
              Organic Rankine Cycle (ORC), Flash Separators, Counter-Current LMTD Heat Exchangers, Turbine-Generator & Grid Substation
            </p>
          </div>

          <!-- Working Fluid Configurator -->
          <div class="flex items-center gap-2 text-xs">
            <span class="text-slate-400 font-semibold">ORC Working Fluid:</span>
            <select 
              [value]="twin().workingFluid.type" 
              (change)="setFluid($any($event.target).value)"
              class="bg-slate-950 text-purple-300 font-mono font-bold px-3 py-1.5 rounded-xl border border-purple-500/40 outline-none cursor-pointer">
              @for (f of fluidKeys; track f) {
                <option [value]="f" class="bg-slate-900 text-slate-100">{{ allFluids[f].name }}</option>
              }
            </select>
          </div>
        </div>
      </div>

      <!-- Live Interactive PFD Schematic -->
      <app-plant-schematic></app-plant-schematic>

      <!-- Working Fluid Thermodynamic Properties & Turbine/Generator Status -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Working Fluid Properties Card -->
        <div class="lg:col-span-6 bg-slate-900/90 rounded-2xl border border-slate-800 p-4">
          <div class="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-purple-400">science</mat-icon>
              <h3 class="text-sm font-bold text-slate-100 uppercase tracking-wide">Working Fluid Thermodynamic Assay</h3>
            </div>
            <span class="text-[10px] font-mono text-purple-400 bg-purple-500/10 px-2 py-0.5 rounded border border-purple-500/20">
              GWP: {{ twin().workingFluid.gwp }}
            </span>
          </div>

          <div class="grid grid-cols-3 gap-2.5 text-xs font-mono mb-3">
            <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
              <span class="text-slate-500 text-[10px] block">Molecular Weight</span>
              <span class="text-slate-200 font-bold">{{ twin().workingFluid.molecularWeight }} kg/kmol</span>
            </div>
            <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
              <span class="text-slate-500 text-[10px] block">Boiling Point (1 bar)</span>
              <span class="text-cyan-400 font-bold">{{ twin().workingFluid.boilingPoint }}°C</span>
            </div>
            <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
              <span class="text-slate-500 text-[10px] block">Critical Temperature</span>
              <span class="text-rose-400 font-bold">{{ twin().workingFluid.criticalTemperature }}°C</span>
            </div>
            <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
              <span class="text-slate-500 text-[10px] block">Critical Pressure</span>
              <span class="text-amber-400 font-bold">{{ twin().workingFluid.criticalPressure }} bar</span>
            </div>
            <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
              <span class="text-slate-500 text-[10px] block">Liquid Specific Heat</span>
              <span class="text-slate-200 font-bold">{{ twin().workingFluid.specificHeatLiquid }} kJ/(kg·K)</span>
            </div>
            <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
              <span class="text-slate-500 text-[10px] block">Latent Heat (h_fg)</span>
              <span class="text-emerald-400 font-bold">{{ twin().workingFluid.latentHeatVaporization }} kJ/kg</span>
            </div>
          </div>
        </div>

        <!-- Turbine & Generator Electromechanical Card -->
        <div class="lg:col-span-6 bg-slate-900/90 rounded-2xl border border-slate-800 p-4">
          <div class="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-emerald-400">bolt</mat-icon>
              <h3 class="text-sm font-bold text-slate-100 uppercase tracking-wide">Turbine Expander & Generator</h3>
            </div>
            <span class="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
              η_total: {{ (twin().turbine.isentropicEfficiency * twin().generator.efficiency * 100).toFixed(1) }}%
            </span>
          </div>

          <div class="grid grid-cols-3 gap-2.5 text-xs font-mono mb-3">
            <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
              <span class="text-slate-500 text-[10px] block">Turbine Shaft Power</span>
              <span class="text-purple-400 font-bold">{{ twin().turbine.shaftPower }} MW</span>
            </div>
            <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
              <span class="text-slate-500 text-[10px] block">Turbine Inlet State</span>
              <span class="text-amber-400 font-bold">{{ twin().turbine.inletTemperature }}°C / {{ twin().turbine.inletPressure }}b</span>
            </div>
            <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
              <span class="text-slate-500 text-[10px] block">Turbine Expansion Ratio</span>
              <span class="text-slate-200 font-bold">{{ (twin().turbine.inletPressure / twin().turbine.outletPressure).toFixed(1) }}:1</span>
            </div>
            <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
              <span class="text-slate-500 text-[10px] block">Gross Generation</span>
              <span class="text-emerald-400 font-bold text-sm">{{ twin().generator.electricalPowerOutput }} MWe</span>
            </div>
            <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
              <span class="text-slate-500 text-[10px] block">Voltage & Frequency</span>
              <span class="text-slate-200 font-bold">{{ twin().generator.voltage }} kV | {{ twin().generator.frequency }} Hz</span>
            </div>
            <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
              <span class="text-slate-500 text-[10px] block">Bearing Vibration</span>
              <span class="text-emerald-400 font-bold">{{ twin().turbine.vibrationMmS }} mm/s (Nominal)</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Heat Exchanger Performance Array & District Heating Cogeneration -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Heat Exchangers Detailed Table -->
        <div class="lg:col-span-7 bg-slate-900/90 rounded-2xl border border-slate-800 p-4">
          <div class="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-amber-400">sync_alt</mat-icon>
              <h3 class="text-sm font-bold text-slate-100 uppercase tracking-wide">Heat Exchangers & LMTD Effectiveness</h3>
            </div>
          </div>

          <div class="space-y-2.5">
            @for (hx of twin().heatExchangers; track hx.id) {
              <div class="bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs font-mono">
                <div class="flex items-center justify-between mb-1.5">
                  <span class="font-bold text-slate-200">{{ hx.name }} ({{ hx.id }})</span>
                  <span class="text-amber-400 font-bold">Duty: {{ hx.heatDuty }} MWth</span>
                </div>

                <div class="grid grid-cols-4 gap-2 text-[10px] bg-slate-900/60 p-2 rounded-lg">
                  <div>
                    <span class="text-slate-500 block">Hot Stream (In→Out)</span>
                    <span class="text-rose-400">{{ hx.hotSideInletTemp }}°C → {{ hx.hotSideOutletTemp }}°C</span>
                  </div>
                  <div>
                    <span class="text-slate-500 block">Cold Stream (In→Out)</span>
                    <span class="text-cyan-400">{{ hx.coldSideInletTemp }}°C → {{ hx.coldSideOutletTemp }}°C</span>
                  </div>
                  <div>
                    <span class="text-slate-500 block">LMTD (ΔT_lm)</span>
                    <span class="text-slate-200 font-bold">{{ hx.lmtd }}°C</span>
                  </div>
                  <div>
                    <span class="text-slate-500 block">Actual UA / Clean UA</span>
                    <span [class]="hx.foulingFactor > 0.2 ? 'text-rose-400 font-bold' : 'text-emerald-400 font-bold'">
                      {{ hx.ua }} / {{ hx.nominalUa }} kW/K
                    </span>
                  </div>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- District Heating Cogeneration (CHP) -->
        <div class="lg:col-span-5 bg-slate-900/90 rounded-2xl border border-slate-800 p-4 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
              <div class="flex items-center gap-2">
                <mat-icon class="text-pink-400">home</mat-icon>
                <h3 class="text-sm font-bold text-slate-100 uppercase tracking-wide">District Heating & Cogeneration</h3>
              </div>
              <span class="text-[10px] font-mono text-pink-400 bg-pink-500/10 px-2 py-0.5 rounded border border-pink-500/20">
                Connected: {{ twin().districtHeating.buildingsConnected }} homes
              </span>
            </div>

            <div class="space-y-3 text-xs font-mono">
              <div class="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-2">
                <div class="flex justify-between">
                  <span class="text-slate-400">Delivered Thermal Output:</span>
                  <span class="text-pink-400 font-bold text-sm">{{ twin().districtHeating.thermalSuppliedMWth }} MWth</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-400">Supply / Return Temp:</span>
                  <span class="text-slate-200">{{ twin().districtHeating.supplyTemperature }}°C / {{ twin().districtHeating.returnTemperature }}°C</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-400">Water Circulation Flow:</span>
                  <span class="text-cyan-400">{{ twin().districtHeating.waterCirculationFlow }} kg/s</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-400">Network Distribution Length:</span>
                  <span class="text-slate-200">{{ twin().districtHeating.networkLengthKm }} km loop</span>
                </div>
              </div>

              <!-- Thermal Storage Battery (ATES / Stratified Tank) -->
              <div class="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <div class="flex justify-between text-[11px] text-slate-300 font-semibold mb-1">
                  <span>Thermal Storage (Stratified Tank):</span>
                  <span class="text-pink-400">{{ twin().districtHeating.thermalStorageState.currentStoredMWh }} / {{ twin().districtHeating.thermalStorageState.capacityMWh }} MWh</span>
                </div>
                <div class="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div class="bg-pink-500 h-full" [style.width.%]="(twin().districtHeating.thermalStorageState.currentStoredMWh / twin().districtHeating.thermalStorageState.capacityMWh) * 100"></div>
                </div>
              </div>
            </div>
          </div>

          <!-- Cooling Condenser & Dispatch Mode -->
          <div class="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
            <div class="flex items-center gap-2">
              <span class="text-slate-400">Cooling System:</span>
              <select 
                [value]="twin().condenser.coolingType"
                (change)="setCooling($any($event.target).value)"
                class="bg-slate-950 text-sky-300 font-mono px-2 py-1 rounded-lg border border-slate-700 outline-none">
                <option value="air_cooled_acc">Air-Cooled ACC (Dry)</option>
                <option value="wet_cooling_tower">Wet Cooling Tower</option>
                <option value="hybrid_dry">Hybrid Dry/Wet Cooler</option>
              </select>
            </div>

            <div class="flex items-center gap-2">
              <span class="text-slate-400">Grid Mode:</span>
              <select 
                [value]="twin().grid.dispatchMode"
                (change)="setDispatch($any($event.target).value)"
                class="bg-slate-950 text-emerald-300 font-mono px-2 py-1 rounded-lg border border-slate-700 outline-none">
                <option value="baseload">Baseload Export</option>
                <option value="load_following">Load Following</option>
                <option value="curtailment">Curtailment</option>
                <option value="islanding">Islanding (Microgrid)</option>
              </select>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class PlantPage {
  private physics = inject(PhysicsEngineService);
  readonly twin = this.physics.twin;
  readonly allFluids = WORKING_FLUIDS;
  readonly fluidKeys = Object.keys(WORKING_FLUIDS) as WorkingFluidType[];

  setFluid(fluid: WorkingFluidType): void {
    this.physics.setWorkingFluid(fluid);
  }

  setCooling(cooling: CoolingType): void {
    this.physics.setCoolingType(cooling);
  }

  setDispatch(mode: GridDispatchMode): void {
    this.physics.setGridDispatchMode(mode);
  }
}
