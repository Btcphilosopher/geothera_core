import { Component, ChangeDetectionStrategy, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PhysicsEngineService } from '../services/physics-engine.service';

@Component({
  selector: 'app-wells-page',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Top Title & Well Switcher -->
      <div class="bg-slate-900/90 rounded-2xl border border-slate-800 p-4">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <div class="flex items-center gap-2">
              <mat-icon class="text-cyan-400">explore</mat-icon>
              <h2 class="text-base font-bold text-slate-100 uppercase tracking-wide">Well Designer, Hydraulics & Fiber-Optic DTS Telemetry</h2>
            </div>
            <p class="text-xs text-slate-400 mt-0.5">
              Directional Trajectories, Wellbore Pressure Loss, Downhole ESP Pumps & Distributed Temperature Sensing (DTS)
            </p>
          </div>

          <!-- Well Tabs -->
          <div class="flex flex-wrap items-center gap-1.5 bg-slate-950 p-1.5 rounded-xl border border-slate-800 text-xs">
            @for (well of twin().wells; track well.id) {
              <button 
                (click)="selectWell(well.id)"
                [class]="selectedWellId() === well.id ? (well.role === 'production' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold' : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold') : 'text-slate-400 hover:text-slate-200'"
                class="px-3 py-1 rounded-lg font-mono transition-all flex items-center gap-1.5">
                <span class="w-2 h-2 rounded-full" [class]="well.role === 'production' ? 'bg-emerald-400' : 'bg-cyan-400'"></span>
                {{ well.id }}
              </button>
            }
          </div>
        </div>
      </div>

      <!-- Selected Well Detailed Hydraulics & Trajectory Section -->
      @if (currentWell(); as well) {
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <!-- Left Column: Well Architecture & Hydraulic Balance -->
          <div class="lg:col-span-5 space-y-6">
            <!-- Well Identity & Status Card -->
            <div class="bg-slate-900/90 rounded-2xl border border-slate-800 p-4">
              <div class="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
                <div>
                  <h3 class="text-sm font-bold text-slate-100 uppercase font-mono">{{ well.name }}</h3>
                  <span class="text-[11px] text-slate-400 capitalize">{{ well.wellType }} {{ well.role }} Well</span>
                </div>
                <span class="px-2.5 py-1 rounded-full text-[10px] font-mono uppercase font-bold"
                  [class]="well.status === 'active' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30' : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'">
                  {{ well.status }}
                </span>
              </div>

              <!-- Physical Dimensions Table -->
              <div class="grid grid-cols-2 gap-2 text-xs font-mono mb-4">
                <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <span class="text-slate-500 text-[10px] block">Measured Depth (MD)</span>
                  <span class="text-slate-100 font-bold text-sm">{{ well.depth }} m</span>
                </div>
                <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <span class="text-slate-500 text-[10px] block">True Vertical Depth (TVD)</span>
                  <span class="text-slate-100 font-bold text-sm">{{ well.tvd }} m</span>
                </div>
                <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <span class="text-slate-500 text-[10px] block">Casing / Tubing OD</span>
                  <span class="text-slate-200 font-bold">244.5 / 177.8 mm</span>
                </div>
                <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <span class="text-slate-500 text-[10px] block">Productivity Index (PI)</span>
                  <span class="text-emerald-400 font-bold">{{ well.productivityIndex }} (kg/s)/bar</span>
                </div>
              </div>

              <!-- Hydraulic Operating State -->
              <div class="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-2 text-xs font-mono">
                <div class="flex justify-between">
                  <span class="text-slate-400">Flow Rate:</span>
                  <span class="text-emerald-400 font-bold">{{ well.flowRate }} kg/s (Choke: {{ well.chokeOpening }}%)</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-400">Wellhead Pressure:</span>
                  <span class="text-slate-200">{{ well.wellheadPressure }} bar</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-400">Bottomhole Pressure:</span>
                  <span class="text-slate-200">{{ well.bottomholePressure }} bar</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-400">Wellhead Temperature:</span>
                  <span class="text-amber-400 font-bold">{{ well.wellheadTemperature }}°C</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-400">Bottomhole Temp (BHT):</span>
                  <span class="text-rose-400 font-bold">{{ well.bottomholeTemperature }}°C</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-400">Specific Enthalpy:</span>
                  <span class="text-cyan-400">{{ well.wellheadEnthalpy }} kJ/kg</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-400">Skin Factor (s):</span>
                  <span class="text-slate-300">{{ well.skinFactor }}</span>
                </div>
              </div>
            </div>

            <!-- Downhole ESP Pump Performance (If Equipped) -->
            @if (well.hasPump) {
              <div class="bg-slate-900/90 rounded-2xl border border-slate-800 p-4">
                <div class="flex items-center justify-between pb-2 border-b border-slate-800 mb-3">
                  <div class="flex items-center gap-2">
                    <mat-icon class="text-emerald-400">electric_meter</mat-icon>
                    <h3 class="text-sm font-bold text-slate-100 uppercase font-mono">Downhole ESP Pump Module</h3>
                  </div>
                  <span class="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                    Depth: {{ well.pumpSettingDepth }}m
                  </span>
                </div>

                <div class="grid grid-cols-3 gap-2 text-xs font-mono">
                  <div class="bg-slate-950 p-2 rounded-lg border border-slate-800">
                    <span class="text-slate-500 text-[10px] block">Pump Speed</span>
                    <span class="text-slate-200 font-bold">{{ well.pumpRpm }} RPM</span>
                  </div>
                  <div class="bg-slate-950 p-2 rounded-lg border border-slate-800">
                    <span class="text-slate-500 text-[10px] block">Developed Head</span>
                    <span class="text-slate-200 font-bold">{{ well.pumpHead }} m</span>
                  </div>
                  <div class="bg-slate-950 p-2 rounded-lg border border-slate-800">
                    <span class="text-slate-500 text-[10px] block">Power Draw</span>
                    <span class="text-amber-400 font-bold">{{ well.pumpPower }} kW</span>
                  </div>
                </div>
              </div>
            }
          </div>

          <!-- Right Column: DTS Distributed Temperature Sensing & Well Test Horner Plot -->
          <div class="lg:col-span-7 space-y-6">
            <!-- Fiber-Optic DTS Depth Profile -->
            <div class="bg-slate-900/90 rounded-2xl border border-slate-800 p-4">
              <div class="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
                <div class="flex items-center gap-2">
                  <mat-icon class="text-amber-400">show_chart</mat-icon>
                  <div>
                    <h3 class="text-sm font-bold text-slate-100 uppercase tracking-wide">Fiber-Optic DTS Temperature Profile</h3>
                    <p class="text-[11px] text-slate-400">Continuous optical Raman backscatter vs Coupled Physics predicted temperature</p>
                  </div>
                </div>
                <span class="text-[10px] font-mono text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                  ±0.1°C Resolution
                </span>
              </div>

              <!-- SVG Depth Profile Chart -->
              <div class="relative w-full h-[280px] bg-slate-950 rounded-xl border border-slate-800/80 p-3">
                <svg class="w-full h-full" viewBox="0 0 500 240" preserveAspectRatio="none">
                  <!-- Gridlines -->
                  <line x1="50" y1="20" x2="480" y2="20" stroke="#334155" stroke-dasharray="2 4" />
                  <line x1="50" y1="70" x2="480" y2="70" stroke="#334155" stroke-dasharray="2 4" />
                  <line x1="50" y1="120" x2="480" y2="120" stroke="#334155" stroke-dasharray="2 4" />
                  <line x1="50" y1="170" x2="480" y2="170" stroke="#334155" stroke-dasharray="2 4" />
                  <line x1="50" y1="220" x2="480" y2="220" stroke="#334155" />

                  <!-- Depth Labels Y-Axis -->
                  <text x="5" y="25" fill="#64748b" font-size="9" font-family="monospace">0m</text>
                  <text x="5" y="75" fill="#64748b" font-size="9" font-family="monospace">1250m</text>
                  <text x="5" y="125" fill="#64748b" font-size="9" font-family="monospace">2500m</text>
                  <text x="5" y="175" fill="#64748b" font-size="9" font-family="monospace">3750m</text>
                  <text x="5" y="225" fill="#64748b" font-size="9" font-family="monospace">5000m</text>

                  <!-- Temperature Labels X-Axis -->
                  <text x="50" y="235" fill="#64748b" font-size="8" font-family="monospace">20°C</text>
                  <text x="155" y="235" fill="#64748b" font-size="8" font-family="monospace">80°C</text>
                  <text x="260" y="235" fill="#64748b" font-size="8" font-family="monospace">140°C</text>
                  <text x="365" y="235" fill="#64748b" font-size="8" font-family="monospace">200°C</text>
                  <text x="450" y="235" fill="#64748b" font-size="8" font-family="monospace">240°C</text>

                  <!-- Predicted Temperature Line (Green) -->
                  <path 
                    d="M 50,20 L 140,70 L 250,120 L 370,170 L 440,220" 
                    fill="none" 
                    stroke="#10b981" 
                    stroke-width="2.5" 
                  />

                  <!-- Observed DTS Sensor Line (Amber with small jitter) -->
                  <path 
                    d="M 50,20 L 142,70 L 248,120 L 374,170 L 438,220" 
                    fill="none" 
                    stroke="#f59e0b" 
                    stroke-width="2" 
                    stroke-dasharray="4 2" 
                  />

                  <!-- Inflow zone marker -->
                  <circle cx="438" cy="220" r="5" fill="#ef4444" />
                  <text x="320" y="215" fill="#f87171" font-size="9" font-family="monospace">Fracture Inflow Interval</text>
                </svg>

                <div class="flex items-center justify-between text-[11px] font-mono text-slate-400 mt-2 px-2">
                  <span class="flex items-center gap-1.5 text-emerald-400">
                    <span class="w-3 h-0.5 bg-emerald-500"></span> Coupled Physics Model
                  </span>
                  <span class="flex items-center gap-1.5 text-amber-400">
                    <span class="w-3 h-0.5 bg-amber-500 border-dashed"></span> Optical DTS Real-Time
                  </span>
                  <span class="text-slate-500">Residual RMSE: 0.42°C</span>
                </div>
              </div>
            </div>

            <!-- Well Test Diagnostics (Horner Plot Simulation) -->
            <div class="bg-slate-900/90 rounded-2xl border border-slate-800 p-4">
              <div class="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
                <div class="flex items-center gap-2">
                  <mat-icon class="text-purple-400">auto_graph</mat-icon>
                  <div>
                    <h3 class="text-sm font-bold text-slate-100 uppercase tracking-wide">Synthetic Well Test Diagnostics (Horner Plot)</h3>
                    <p class="text-[11px] text-slate-400">Pressure buildup analysis: $P_{{ '{' }}ws{{ '}' }} = P_i - 162.6 \\frac{{ '{' }}q \\mu{{ '}' }}{{ '{' }}kh{{ '}' }} \\log\\left(\\frac{{ '{' }}t_p + \\Delta t{{ '}' }}{{ '{' }}\\Delta t{{ '}' }}\\right)$</p>
                  </div>
                </div>
                <span class="text-[10px] font-mono text-purple-400 bg-purple-500/10 px-2 py-0.5 rounded border border-purple-500/20">
                  Semi-Log Analysis
                </span>
              </div>

              <div class="grid grid-cols-4 gap-2 text-xs font-mono">
                <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <span class="text-slate-500 text-[10px] block">Transmissibility (kh/μ)</span>
                  <span class="text-slate-100 font-bold">14,250 mD·m/cP</span>
                </div>
                <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <span class="text-slate-500 text-[10px] block">Extrapolated Initial P*</span>
                  <span class="text-emerald-400 font-bold">324.5 bar</span>
                </div>
                <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <span class="text-slate-500 text-[10px] block">Skin Factor (s)</span>
                  <span class="text-amber-400 font-bold">{{ well.skinFactor }} (Stimulated)</span>
                </div>
                <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <span class="text-slate-500 text-[10px] block">Wellbore Storage (C)</span>
                  <span class="text-cyan-400 font-bold">0.012 m³/bar</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      }
    </div>
  `,
})
export class WellsPage {
  private physics = inject(PhysicsEngineService);
  readonly twin = this.physics.twin;

  readonly selectedWellId = signal<string>('P-01');
  readonly currentWell = computed(() => this.twin().wells.find(w => w.id === this.selectedWellId()));

  selectWell(id: string): void {
    this.selectedWellId.set(id);
  }
}
