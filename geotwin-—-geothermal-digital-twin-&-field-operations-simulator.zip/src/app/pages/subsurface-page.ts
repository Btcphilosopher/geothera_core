import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PhysicsEngineService } from '../services/physics-engine.service';
import { SubsurfaceViewer } from '../components/subsurface-viewer';

@Component({
  selector: 'app-subsurface-page',
  imports: [CommonModule, MatIconModule, SubsurfaceViewer],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Top Overview Card -->
      <div class="bg-slate-900/90 rounded-2xl border border-slate-800 p-4">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <div class="flex items-center gap-2">
              <mat-icon class="text-amber-400">layers</mat-icon>
              <h2 class="text-base font-bold text-slate-100 uppercase tracking-wide">3D Geological Digital Twin & Reservoir Numerical Grid</h2>
            </div>
            <p class="text-xs text-slate-400 mt-0.5">
              Stratigraphy, Discrete Fracture Network (DFN), 3D Finite-Difference Grid & Thermal Convection-Diffusion Solvers
            </p>
          </div>

          <div class="flex items-center gap-3 text-xs">
            <div class="bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800">
              <span class="text-slate-500 text-[10px] block">Grid Discretization</span>
              <span class="font-mono font-bold text-slate-200">
                {{ twin().reservoir.gridNx }} × {{ twin().reservoir.gridNy }} × {{ twin().reservoir.gridNz }} ({{ twin().reservoir.cells.length }} cells)
              </span>
            </div>
            <div class="bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800">
              <span class="text-slate-500 text-[10px] block">Cell Dimensions</span>
              <span class="font-mono font-bold text-emerald-400">250m × 250m × 400m</span>
            </div>
            <div class="bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800">
              <span class="text-slate-500 text-[10px] block">Target Depth Interval</span>
              <span class="font-mono font-bold text-amber-400">3,200m – 5,200m TVD</span>
            </div>
          </div>
        </div>
      </div>

      <!-- 3D Subsurface Viewer Component -->
      <div class="w-full h-[580px]">
        <app-subsurface-viewer></app-subsurface-viewer>
      </div>

      <!-- Geology Stratigraphy & Discrete Fracture Network (DFN) Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Stratigraphic Column Table -->
        <div class="lg:col-span-6 bg-slate-900/90 rounded-2xl border border-slate-800 p-4">
          <div class="flex items-center gap-2 pb-3 border-b border-slate-800 mb-3">
            <mat-icon class="text-emerald-400">terrain</mat-icon>
            <h3 class="text-sm font-bold text-slate-100 uppercase tracking-wide">Lithological Strata & Rock Mechanics</h3>
          </div>

          <div class="space-y-2.5">
            @for (layer of twin().geology.layers; track layer.id) {
              <div class="bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs">
                <div class="flex items-center justify-between font-mono mb-1">
                  <span class="font-bold text-slate-200 flex items-center gap-2">
                    <span class="w-3 h-3 rounded" [style.background-color]="layer.rockType.color"></span>
                    {{ layer.name }}
                  </span>
                  <span class="text-slate-400">{{ layer.depthStart }}m – {{ layer.depthEnd }}m</span>
                </div>
                <p class="text-[11px] text-slate-400 mb-2">{{ layer.description }}</p>

                <div class="grid grid-cols-4 gap-2 text-[10px] font-mono bg-slate-900/60 p-2 rounded-lg">
                  <div>
                    <span class="text-slate-500 block">Density</span>
                    <span class="text-slate-300 font-bold">{{ layer.rockType.density }} kg/m³</span>
                  </div>
                  <div>
                    <span class="text-slate-500 block">Permeability</span>
                    <span class="text-emerald-400 font-bold">{{ layer.rockType.permeability }} mD</span>
                  </div>
                  <div>
                    <span class="text-slate-500 block">Thermal Cond.</span>
                    <span class="text-amber-400 font-bold">{{ layer.rockType.thermalConductivity }} W/(m·K)</span>
                  </div>
                  <div>
                    <span class="text-slate-500 block">Porosity</span>
                    <span class="text-cyan-400 font-bold">{{ (layer.rockType.porosity * 100).toFixed(1) }}%</span>
                  </div>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Discrete Fracture Network (DFN) & Sweep Metrics -->
        <div class="lg:col-span-6 bg-slate-900/90 rounded-2xl border border-slate-800 p-4">
          <div class="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-amber-400">grain</mat-icon>
              <h3 class="text-sm font-bold text-slate-100 uppercase tracking-wide">Discrete Fracture Network (DFN)</h3>
            </div>
            <span class="text-[11px] font-mono text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
              EGS Stimulated Zones
            </span>
          </div>

          <div class="space-y-3">
            @for (dfn of twin().fractureNetwork.fractures; track dfn.id) {
              <div class="bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs">
                <div class="flex items-center justify-between mb-1.5">
                  <div class="flex items-center gap-2">
                    <span class="font-mono font-bold text-slate-200">{{ dfn.id }}</span>
                    <span class="px-1.5 py-0.5 rounded text-[10px] font-mono" [class]="dfn.activated ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30' : 'bg-slate-800 text-slate-500'">
                      {{ dfn.activated ? 'HYDRAULICALLY ACTIVE' : 'UNSTIMULATED' }}
                    </span>
                  </div>
                  <span class="font-mono text-[11px] text-slate-400">Strike {{ dfn.strike }}° / Dip {{ dfn.dip }}°</span>
                </div>

                <div class="grid grid-cols-4 gap-2 text-[10px] font-mono bg-slate-900/60 p-2 rounded-lg">
                  <div>
                    <span class="text-slate-500 block">Length × Height</span>
                    <span class="text-slate-200">{{ dfn.length }}m × {{ dfn.height }}m</span>
                  </div>
                  <div>
                    <span class="text-slate-500 block">Aperture</span>
                    <span class="text-amber-300 font-bold">{{ dfn.aperture }} mm</span>
                  </div>
                  <div>
                    <span class="text-slate-500 block">Permeability</span>
                    <span class="text-emerald-400 font-bold">{{ dfn.permeability }} Darcy</span>
                  </div>
                  <div>
                    <span class="text-slate-500 block">Hydraulic Cond.</span>
                    <span class="text-cyan-400 font-bold">{{ dfn.hydraulicConductivity }} m/s</span>
                  </div>
                </div>
              </div>
            }
          </div>

          <!-- Total Thermal Sweep Summary Card -->
          <div class="mt-4 p-3 bg-gradient-to-r from-amber-500/10 via-slate-950 to-slate-950 rounded-xl border border-amber-500/30 text-xs">
            <div class="font-semibold text-slate-200 mb-1 flex items-center gap-1.5">
              <mat-icon class="text-amber-400 !text-sm !w-4 !h-4">local_fire_department</mat-icon>
              Active Subsurface Thermal Extraction Metrics
            </div>
            <div class="grid grid-cols-2 gap-3 text-[11px] font-mono mt-2">
              <div>
                <span class="text-slate-400 block">Total Fracture Surface:</span>
                <span class="text-slate-100 font-bold">{{ (twin().fractureNetwork.totalFractureSurfaceAreaM2 / 1e6).toFixed(2) }} km²</span>
              </div>
              <div>
                <span class="text-slate-400 block">Active Thermal Sweep Vol:</span>
                <span class="text-amber-400 font-bold">{{ (twin().reservoir.activeThermalSweepVolumeM3 / 1e6).toFixed(1) }}M m³</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class SubsurfacePage {
  private physics = inject(PhysicsEngineService);
  readonly twin = this.physics.twin;
}
