import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PhysicsEngineService } from '../services/physics-engine.service';
import { ScenarioEngineService } from '../services/scenario-engine.service';
import { PlantSchematic } from '../components/plant-schematic';
import { CrossSectionViewer } from '../components/cross-section-viewer';

@Component({
  selector: 'app-control-center',
  imports: [CommonModule, MatIconModule, PlantSchematic, CrossSectionViewer],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Causal Chain Architecture Banner -->
      <div class="bg-slate-900/90 rounded-2xl border border-slate-800 p-4">
        <div class="flex items-center justify-between mb-3">
          <div class="flex items-center gap-2">
            <mat-icon class="text-emerald-400">hub</mat-icon>
            <h2 class="text-sm font-bold text-slate-100 uppercase tracking-wide">Fully Coupled Physical Causal Chain</h2>
          </div>
          <span class="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded-full border border-emerald-500/20">
            Real-time Conservation Laws Enforced (Mass • Momentum • Energy)
          </span>
        </div>

        <!-- Causal Pipeline Flow -->
        <div class="grid grid-cols-2 md:grid-cols-7 gap-2 text-xs">
          <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800/80">
            <span class="text-[10px] text-slate-500 font-mono block">1. RESERVOIR</span>
            <div class="font-bold text-slate-200 mt-1">{{ twin().reservoir.averageTemperature }}°C</div>
            <div class="text-[10px] text-slate-400">{{ twin().reservoir.averagePressure }} bar (3200m)</div>
          </div>

          <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800/80">
            <span class="text-[10px] text-slate-500 font-mono block">2. WELLBORES</span>
            <div class="font-bold text-emerald-400 mt-1">{{ twin().balances.brineProductionTotalKgS }} kg/s</div>
            <div class="text-[10px] text-slate-400">4 Prod / 2 Inj Wells</div>
          </div>

          <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800/80">
            <span class="text-[10px] text-slate-500 font-mono block">3. GATHERING</span>
            <div class="font-bold text-amber-400 mt-1">{{ twin().gatheringSystem.productionHeaderTempC }}°C</div>
            <div class="text-[10px] text-slate-400">{{ twin().gatheringSystem.productionHeaderPressureBar }} bar header</div>
          </div>

          <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800/80">
            <span class="text-[10px] text-slate-500 font-mono block">4. HEAT EXCHANGE</span>
            <div class="font-bold text-cyan-400 mt-1">{{ twin().heatExchangers[1].heatDuty }} MWth</div>
            <div class="text-[10px] text-slate-400">UA: {{ twin().heatExchangers[1].ua }} kW/K</div>
          </div>

          <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800/80">
            <span class="text-[10px] text-slate-500 font-mono block">5. ORC TURBINE</span>
            <div class="font-bold text-purple-400 mt-1">{{ twin().turbine.shaftPower }} MW</div>
            <div class="text-[10px] text-slate-400">{{ twin().workingFluid.type }} vapor</div>
          </div>

          <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800/80">
            <span class="text-[10px] text-slate-500 font-mono block">6. GRID EXPORT</span>
            <div class="font-bold text-emerald-300 mt-1">{{ twin().grid.exportActivePowerMW }} MWe</div>
            <div class="text-[10px] text-slate-400">132 kV | 50.0 Hz</div>
          </div>

          <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800/80">
            <span class="text-[10px] text-slate-500 font-mono block">7. REINJECTION</span>
            <div class="font-bold text-cyan-400 mt-1">{{ twin().balances.brineReinjectionTotalKgS }} kg/s</div>
            <div class="text-[10px] text-slate-400">{{ twin().gatheringSystem.reinjectionHeaderTempC }}°C @ 28 bar</div>
          </div>
        </div>
      </div>

      <!-- Main SCADA Grid: Left Plant PFD & Right Well Choke Telemetry Controls -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Process Flow Diagram (PFD) -->
        <div class="lg:col-span-8">
          <app-plant-schematic></app-plant-schematic>
        </div>

        <!-- Wellhead & SCADA Operations Panel -->
        <div class="lg:col-span-4 bg-slate-900/90 rounded-2xl border border-slate-800 p-4 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
              <div class="flex items-center gap-2">
                <mat-icon class="text-amber-400">tune</mat-icon>
                <h3 class="text-sm font-bold text-slate-100 uppercase tracking-wide">SCADA Well Controls</h3>
              </div>
              <span class="text-[10px] font-mono text-slate-400">Live Choke Trimming</span>
            </div>

            <!-- Well Choke Sliders -->
            <div class="space-y-3">
              @for (well of twin().wells; track well.id) {
                <div class="bg-slate-950 p-3 rounded-xl border border-slate-800/90">
                  <div class="flex items-center justify-between text-xs mb-1.5">
                    <div class="flex items-center gap-1.5">
                      <span class="w-2 h-2 rounded-full" [class]="well.status === 'active' ? (well.role === 'production' ? 'bg-emerald-500' : 'bg-cyan-500') : 'bg-rose-500'"></span>
                      <span class="font-mono font-bold text-slate-200">{{ well.id }}</span>
                      <span class="text-[10px] text-slate-400">({{ well.role === 'production' ? 'Prod' : 'Inj' }})</span>
                    </div>

                    <div class="flex items-center gap-2">
                      <span class="font-mono font-bold" [class]="well.role === 'production' ? 'text-emerald-400' : 'text-cyan-400'">
                        {{ well.flowRate }} kg/s
                      </span>
                      <button 
                        (click)="toggleWell(well.id)"
                        class="px-1.5 py-0.5 rounded text-[10px] font-mono transition-colors"
                        [class]="well.status === 'active' ? 'bg-rose-500/10 text-rose-400 border border-rose-500/30 hover:bg-rose-500/20' : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/20'">
                        {{ well.status === 'active' ? 'Shut' : 'Open' }}
                      </button>
                    </div>
                  </div>

                  <!-- Slider -->
                  <div class="flex items-center gap-3 text-xs">
                    <input 
                      type="range" 
                      min="0" 
                      max="100" 
                      [value]="well.chokeOpening" 
                      (input)="updateChoke(well.id, $any($event.target).value)"
                      [disabled]="well.status !== 'active'"
                      class="flex-1 accent-emerald-500 bg-slate-800 h-1.5 rounded cursor-pointer disabled:opacity-30" 
                    />
                    <span class="font-mono text-slate-400 text-[11px] w-8 text-right">{{ well.chokeOpening }}%</span>
                  </div>

                  <div class="flex items-center justify-between text-[10px] text-slate-500 font-mono mt-1.5">
                    <span>WHP: {{ well.wellheadPressure }} bar</span>
                    <span>WHT: {{ well.wellheadTemperature }}°C</span>
                    <span>BHP: {{ well.bottomholePressure }} bar</span>
                  </div>
                </div>
              }
            </div>
          </div>

          <!-- Quick Scenario Trigger Buttons -->
          <div class="mt-4 pt-4 border-t border-slate-800 space-y-2">
            <div class="text-[11px] font-semibold text-slate-400">Emergency & Demo Scenario Injections:</div>
            <div class="grid grid-cols-2 gap-2 text-xs">
              <button 
                (click)="scenarios.applyThermalBreakthroughDemo()"
                class="px-2.5 py-2 rounded-xl bg-slate-950 hover:bg-slate-800 text-sky-400 border border-sky-500/20 text-left flex items-center gap-1.5 transition-colors">
                <mat-icon class="!text-sm !w-4 !h-4">ac_unit</mat-icon>
                <span>Breakthrough</span>
              </button>

              <button 
                (click)="scenarios.applyWellFailureScenario()"
                class="px-2.5 py-2 rounded-xl bg-slate-950 hover:bg-slate-800 text-rose-400 border border-rose-500/20 text-left flex items-center gap-1.5 transition-colors">
                <mat-icon class="!text-sm !w-4 !h-4">warning</mat-icon>
                <span>Trip Well P-03</span>
              </button>

              <button 
                (click)="scenarios.applyHeatExchangerFoulingScenario()"
                class="px-2.5 py-2 rounded-xl bg-slate-950 hover:bg-slate-800 text-amber-400 border border-amber-500/20 text-left flex items-center gap-1.5 transition-colors">
                <mat-icon class="!text-sm !w-4 !h-4">hardware</mat-icon>
                <span>HEX Scaling</span>
              </button>

              <button 
                (click)="scenarios.applyBaselineScenario()"
                class="px-2.5 py-2 rounded-xl bg-slate-950 hover:bg-slate-800 text-emerald-400 border border-emerald-500/20 text-left flex items-center gap-1.5 transition-colors">
                <mat-icon class="!text-sm !w-4 !h-4">restore</mat-icon>
                <span>Reset Baseline</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Inter-Well Cross Section & Live Sensor Telemetry Stream -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- 2-Well Section View -->
        <div class="lg:col-span-7">
          <app-cross-section-viewer></app-cross-section-viewer>
        </div>

        <!-- Live Telemetry Residuals Bus -->
        <div class="lg:col-span-5 bg-slate-900/90 rounded-2xl border border-slate-800 p-4 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
              <div class="flex items-center gap-2">
                <mat-icon class="text-cyan-400">sensors</mat-icon>
                <div>
                  <h3 class="text-sm font-bold text-slate-100 uppercase tracking-wide">Digital Twin Sensor Bus</h3>
                  <p class="text-[11px] text-slate-400">Observed vs Physics Predicted Residual Telemetry</p>
                </div>
              </div>
              <span class="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                100% Synced
              </span>
            </div>

            <!-- Telemetry Table -->
            <div class="space-y-2">
              @for (packet of twin().telemetryBus; track packet.sensorId) {
                <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800/90 flex items-center justify-between text-xs">
                  <div>
                    <div class="font-mono text-[11px] text-slate-400">{{ packet.sensorId }}</div>
                    <div class="font-semibold text-slate-200">{{ packet.tag }}</div>
                  </div>

                  <div class="text-right">
                    <div class="font-mono font-bold text-slate-100">
                      {{ packet.observedValue }} {{ packet.unit }}
                    </div>
                    <div class="text-[10px] font-mono" [class]="packet.residual !== 0 ? 'text-amber-400' : 'text-slate-500'">
                      Pred: {{ packet.predictedValue }} | Res: {{ packet.residual > 0 ? '+' : '' }}{{ packet.residual }}
                    </div>
                  </div>
                </div>
              }
            </div>
          </div>

          <!-- Geothermal Mass & Water Conservation Summary -->
          <div class="mt-4 pt-3 border-t border-slate-800 bg-slate-950/60 p-3 rounded-xl border border-slate-800/80 text-xs">
            <div class="flex items-center justify-between text-[11px] text-slate-400 mb-1">
              <span>Reservoir Mass Conservation:</span>
              <span class="font-mono text-emerald-400">ΔM = {{ twin().balances.reservoirMassChangeKgS }} kg/s</span>
            </div>
            <div class="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div class="bg-emerald-500 h-full w-[98%]"></div>
            </div>
            <div class="flex justify-between text-[10px] text-slate-500 mt-1 font-mono">
              <span>Produced: {{ twin().balances.brineProductionTotalKgS }} kg/s</span>
              <span>Injected: {{ twin().balances.brineReinjectionTotalKgS }} kg/s</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class ControlCenter {
  private physics = inject(PhysicsEngineService);
  readonly scenarios = inject(ScenarioEngineService);
  readonly twin = this.physics.twin;

  updateChoke(wellId: string, chokeVal: number): void {
    this.physics.updateWellChoke(wellId, Number(chokeVal));
  }

  toggleWell(wellId: string): void {
    this.physics.toggleWellStatus(wellId);
  }
}
