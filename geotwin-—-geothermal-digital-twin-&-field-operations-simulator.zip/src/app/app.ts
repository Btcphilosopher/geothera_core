import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PhysicsEngineService } from './services/physics-engine.service';
import { GeothermalArchitecture } from './models/geothermal.model';

// Pages
import { ControlCenter } from './pages/control-center';
import { SubsurfacePage } from './pages/subsurface-page';
import { WellsPage } from './pages/wells-page';
import { PlantPage } from './pages/plant-page';
import { GeochemistryPage } from './pages/geochemistry-page';
import { SeismicityPage } from './pages/seismicity-page';
import { AssimilationPage } from './pages/assimilation-page';
import { ScenariosPage } from './pages/scenarios-page';
import { EconomicsPage } from './pages/economics-page';
import { AdvisoryPage } from './pages/advisory-page';

export type NavTab = 
  | 'control_room'
  | 'subsurface'
  | 'wells'
  | 'plant'
  | 'geochemistry'
  | 'seismicity'
  | 'assimilation'
  | 'scenarios'
  | 'economics'
  | 'advisory';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    MatIconModule,
    ControlCenter,
    SubsurfacePage,
    WellsPage,
    PlantPage,
    GeochemistryPage,
    SeismicityPage,
    AssimilationPage,
    ScenariosPage,
    EconomicsPage,
    AdvisoryPage,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  private physics = inject(PhysicsEngineService);
  readonly twin = this.physics.twin;

  readonly activeTab = signal<NavTab>('control_room');

  setTab(tab: NavTab): void {
    this.activeTab.set(tab);
  }

  setArchitecture(arch: GeothermalArchitecture): void {
    this.physics.setArchitecture(arch);
  }

  toggleSimulation(): void {
    if (this.twin().isSimulating) {
      this.physics.pauseSimulation();
    } else {
      this.physics.startSimulation();
    }
  }

  setSpeed(speed: number): void {
    this.physics.setSpeedMultiplier(speed);
  }
}
