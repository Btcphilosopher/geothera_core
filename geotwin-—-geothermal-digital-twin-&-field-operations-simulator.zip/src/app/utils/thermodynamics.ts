/**
 * Engineering Thermodynamics & Reservoir Physics Solvers
 * Implements IAPWS-IF97 industrial approximations, ORC working fluid cycle calculations,
 * Darcy flow, Wellbore hydraulics (hydrostatic + friction + acceleration), LMTD heat transfer,
 * and Geochemical scaling kinetics.
 */

import { FluidProperties, WorkingFluidType } from '../models/geothermal.model';

export const WORKING_FLUIDS: Record<WorkingFluidType, FluidProperties> = {
  R245fa: {
    type: 'R245fa',
    name: '1,1,1,3,3-Pentafluoropropane (R245fa)',
    molecularWeight: 134.05,
    boilingPoint: 15.14,
    criticalTemperature: 154.01,
    criticalPressure: 36.51,
    specificHeatLiquid: 1.36, // kJ/(kg·K)
    latentHeatVaporization: 196.2, // kJ/kg
    gwp: 1030,
  },
  R134a: {
    type: 'R134a',
    name: '1,1,1,2-Tetrafluoroethane (R134a)',
    molecularWeight: 102.03,
    boilingPoint: -26.3,
    criticalTemperature: 101.06,
    criticalPressure: 40.59,
    specificHeatLiquid: 1.42,
    latentHeatVaporization: 216.0,
    gwp: 1430,
  },
  Isobutane: {
    type: 'Isobutane',
    name: 'Isobutane (i-C4H10 / R600a)',
    molecularWeight: 58.12,
    boilingPoint: -11.7,
    criticalTemperature: 134.66,
    criticalPressure: 36.29,
    specificHeatLiquid: 2.38,
    latentHeatVaporization: 366.5,
    gwp: 3,
  },
  'n-Pentane': {
    type: 'n-Pentane',
    name: 'n-Pentane (C5H12 / R601)',
    molecularWeight: 72.15,
    boilingPoint: 36.1,
    criticalTemperature: 196.55,
    criticalPressure: 33.7,
    specificHeatLiquid: 2.32,
    latentHeatVaporization: 358.0,
    gwp: 5,
  },
  Cyclopentane: {
    type: 'Cyclopentane',
    name: 'Cyclopentane (C5H10)',
    molecularWeight: 70.13,
    boilingPoint: 49.3,
    criticalTemperature: 238.6,
    criticalPressure: 45.1,
    specificHeatLiquid: 2.18,
    latentHeatVaporization: 392.0,
    gwp: 11,
  },
};

/**
 * Water & Steam Thermodynamic Functions (IAPWS-IF97 industrial approximation)
 */
export class WaterSteamPhysics {
  /**
   * Saturation Pressure (bar) as a function of Temperature (°C)
   * Antoine / Wagner formulation
   */
  static saturationPressure(tempC: number): number {
    if (tempC <= 0.01) return 0.00611;
    const T = tempC + 273.15; // Kelvin
    const Tc = 647.096; // K
    const Pc = 220.64; // bar
    const tau = 1 - T / Tc;
    if (tau <= 0) return Pc;

    const a1 = -7.85951783;
    const a2 = 1.84408259;
    const a3 = -11.7866497;
    const a4 = 22.6807411;
    const a5 = -15.9618719;
    const a6 = 1.80122502;

    const exponent = (Tc / T) * (a1 * tau + a2 * Math.pow(tau, 1.5) + a3 * Math.pow(tau, 3) + a4 * Math.pow(tau, 3.5) + a5 * Math.pow(tau, 4) + a6 * Math.pow(tau, 7.5));
    return Math.max(0.01, Pc * Math.exp(exponent));
  }

  /**
   * Saturation Temperature (°C) as a function of Pressure (bar)
   */
  static saturationTemperature(pBar: number): number {
    if (pBar <= 0.00611) return 0.01;
    if (pBar >= 220.64) return 374.0;
    // Empirical inverted fit for 0.05 to 100 bar
    const tC = 42.6776 * Math.pow(pBar, 0.231) + 14.5 * Math.log10(pBar + 0.1) + 55.0 * (1 - Math.exp(-0.4 * pBar));
    return Math.min(370, Math.max(10, tC));
  }

  /**
   * Saturated Liquid Water Enthalpy h_f (kJ/kg)
   */
  static saturatedLiquidEnthalpy(tempC: number): number {
    // cp_water approx 4.184 kJ/(kg*K) with slight thermal expansion correction
    return 4.184 * tempC + 0.00045 * Math.pow(tempC, 2);
  }

  /**
   * Saturated Vapor Enthalpy h_g (kJ/kg)
   */
  static saturatedVaporEnthalpy(tempC: number): number {
    // Latent heat decreases with temperature toward critical point
    const h_f = this.saturatedLiquidEnthalpy(tempC);
    const latentHeat = 2501 - 2.38 * tempC;
    return h_f + Math.max(100, latentHeat);
  }

  /**
   * Water density (kg/m3) as function of temperature (°C) and pressure (bar)
   */
  static waterDensity(tempC: number, pBar: number): number {
    const rho0 = 1000 * (1 - Math.pow(tempC + 288.9414, -1) * (tempC - 3.9863) * (tempC - 3.9863) / 508929.2 * (tempC + 68.12963));
    // Simple compressibility factor: 4.5e-5 / bar
    const compressibility = 1 + 4.5e-5 * (pBar - 1);
    return Math.max(700, Math.min(1020, rho0 * compressibility));
  }

  /**
   * Dynamic viscosity of liquid water (Pa·s)
   */
  static waterViscosity(tempC: number): number {
    // Vogel equation: eta = A * exp(B / (T - C))
    const T = tempC + 273.15;
    return 2.414e-5 * Math.pow(10, 247.8 / (T - 140));
  }
}

/**
 * Log Mean Temperature Difference (LMTD) & Heat Exchanger Effectiveness
 */
export class HeatTransferSolver {
  static calculateLMTD(thi: number, tho: number, tci: number, tco: number): number {
    const dt1 = thi - tco; // hot inlet - cold outlet (counter-current)
    const dt2 = tho - tci; // hot outlet - cold inlet
    if (dt1 <= 0 || dt2 <= 0) return 1.0;
    if (Math.abs(dt1 - dt2) < 0.001) return dt1;
    return (dt1 - dt2) / Math.log(dt1 / dt2);
  }

  static calculateHeatDuty(uaKWK: number, lmtdC: number): number {
    // Q = UA * LMTD in kW -> convert to MW
    return (uaKWK * lmtdC) / 1000;
  }
}

/**
 * Wellbore Hydraulic Pressure Drop Solver
 * Integrates: dp/dz = dp_hydrostatic + dp_friction + dp_acceleration
 */
export class WellboreHydraulics {
  /**
   * Friction factor using Haaland equation for Colebrook-White
   */
  static frictionFactor(reynolds: number, relativeRoughness: number): number {
    if (reynolds < 2300) {
      return 64 / Math.max(1, reynolds);
    }
    const term = Math.pow(relativeRoughness / 3.7, 1.11) + 6.9 / reynolds;
    const invSqrtF = -1.8 * Math.log10(term);
    return 1 / (invSqrtF * invSqrtF);
  }

  /**
   * Calculate bottomhole to wellhead pressure drop
   */
  static calculatePressureDrop(
    depthM: number,
    flowRateKgS: number,
    pipeDiameterMm: number,
    roughnessMm: number,
    avgTempC: number,
    reservoirPressureBar: number
  ): { bottomholeP: number; wellheadP: number; frictionLossBar: number; hydrostaticGainBar: number } {
    const dM = pipeDiameterMm / 1000;
    const area = Math.PI * Math.pow(dM / 2, 2);
    const rho = WaterSteamPhysics.waterDensity(avgTempC, reservoirPressureBar / 2);
    const velocity = (flowRateKgS / rho) / area;
    const mu = WaterSteamPhysics.waterViscosity(avgTempC);
    const reynolds = (rho * velocity * dM) / mu;
    const f = this.frictionFactor(reynolds, roughnessMm / pipeDiameterMm);

    // Hydrostatic: rho * g * h (Pa -> bar)
    const hydrostaticLossBar = (rho * 9.80665 * depthM) / 100000;
    // Friction loss: f * (L/D) * (rho * v^2 / 2) (Pa -> bar)
    const frictionLossBar = (f * (depthM / dM) * (rho * velocity * velocity / 2)) / 100000;

    // For production well: P_wellhead = P_reservoir - Drawdown - Hydrostatic - Friction
    // For injection well: P_bottomhole = P_wellhead + Hydrostatic - Friction
    return {
      bottomholeP: reservoirPressureBar,
      wellheadP: Math.max(1.0, reservoirPressureBar - hydrostaticLossBar - frictionLossBar),
      frictionLossBar,
      hydrostaticGainBar: hydrostaticLossBar,
    };
  }
}

/**
 * Geochemical Scaling & Corrosion Models
 */
export class GeochemistryPhysics {
  /**
   * Amorphous Silica Solubility (Fournier & Marshall 1982 equation)
   * log10(SiO2 mg/kg) = 4.52 - 731 / (T_K)
   */
  static amorphousSilicaSolubility(tempC: number): number {
    const Tk = tempC + 273.15;
    const logSol = 4.52 - 731 / Tk;
    return Math.pow(10, logSol);
  }

  /**
   * Calculate Silica Saturation Index (SSI = [SiO2 observed] / [SiO2 equilibrium])
   */
  static calculateSilicaSSI(silicaMgL: number, tempC: number): number {
    const eqSolubility = this.amorphousSilicaSolubility(tempC);
    return silicaMgL / Math.max(10, eqSolubility);
  }

  /**
   * Langelier Saturation Index (LSI) for Calcite scaling
   * LSI = pH - pHs
   */
  static calculateLSI(ph: number, tempC: number, tds: number, caMgL: number, alkalinityMgL: number): number {
    // Empirical approximation of pHs
    const A = (Math.log10(tds) - 1) / 10;
    const B = -13.12 * Math.log10(tempC + 273.15) + 34.55;
    const C = Math.log10(Math.max(1, caMgL * 2.497)) - 0.4;
    const D = Math.log10(Math.max(1, alkalinityMgL));
    const pHs = (9.3 + A + B) - (C + D);
    return ph - pHs;
  }

  /**
   * Ryznar Stability Index (RSI = 2*pHs - pH)
   */
  static calculateRSI(ph: number, lsi: number): number {
    const pHs = ph - lsi;
    return 2 * pHs - ph;
  }
}
