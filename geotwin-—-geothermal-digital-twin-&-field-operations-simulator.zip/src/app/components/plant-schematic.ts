import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PhysicsEngineService } from '../services/physics-engine.service';

@Component({
  selector: 'app-plant-schematic',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-slate-900/90 rounded-2xl border border-slate-800 p-4 flex flex-col h-full">
      <div class="flex items-center justify-between pb-3 border-b border-slate-800 mb-2">
        <div class="flex items-center gap-2">
          <mat-icon class="text-emerald-400">precision_manufacturing</mat-icon>
          <div>
            <h3 class="text-sm font-bold text-slate-100 uppercase tracking-wide">Surface Plant & Binary ORC Process Flow (PFD)</h3>
            <p class="text-[11px] text-slate-400">Thermodynamic state tracking across gathering, heat exchange, expansion & reinjection</p>
          </div>
        </div>

        <div class="flex items-center gap-2 text-xs">
          <span class="px-2.5 py-1 rounded-full font-mono text-[11px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 flex items-center gap-1.5">
            <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            ORC Cycle: {{ twin().workingFluid.name }}
          </span>
          <button 
            (click)="cleanHeatExchangers()"
            class="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 flex items-center gap-1 text-[11px] transition-colors">
            <mat-icon class="!text-xs !w-3.5 !h-3.5 text-amber-400">cleaning_services</mat-icon>
            Flush / Descale HEX
          </button>
        </div>
      </div>

      <!-- Animated SVG Process Flow Diagram -->
      <div class="relative w-full flex-1 min-h-[340px] bg-slate-950 rounded-xl border border-slate-800/80 p-2 overflow-hidden">
        <svg class="w-full h-full" viewBox="0 0 920 420" preserveAspectRatio="xMidYMid meet">
          <defs>
            <linearGradient id="brineFlowGrad" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stop-color="#ef4444" />
              <stop offset="50%" stop-color="#f59e0b" />
              <stop offset="100%" stop-color="#06b6d4" />
            </linearGradient>
            <linearGradient id="orcVaporGrad" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stop-color="#a855f7" />
              <stop offset="100%" stop-color="#3b82f6" />
            </linearGradient>
          </defs>

          <!-- PIPING LINES -->
          <!-- 1. Production Brine Pipe (Red) -->
          <path d="M 60,180 L 140,180 L 140,120 L 220,120" fill="none" stroke="#ef4444" stroke-width="4" stroke-linecap="round" />
          
          <!-- 2. Separator to Vaporizer Brine Pipe -->
          <path d="M 280,120 L 370,120" fill="none" stroke="#f97316" stroke-width="4" />

          <!-- 3. Vaporizer to Preheater Brine Pipe -->
          <path d="M 470,120 L 470,220 L 370,220" fill="none" stroke="#f59e0b" stroke-width="4" />

          <!-- 4. Preheater to District Heat / Reinjection Pipe (Cyan) -->
          <path d="M 270,220 L 180,220 L 180,320 L 370,320 L 470,320 L 560,320 L 760,320 L 840,320" fill="none" stroke="#06b6d4" stroke-width="4" />

          <!-- 5. ORC Vapor Loop (Purple to Turbine) -->
          <path d="M 420,80 L 420,40 L 580,40 L 580,90" fill="none" stroke="#c084fc" stroke-width="4" stroke-dasharray="6 3" />

          <!-- 6. Turbine Outlet to Air-Cooled Condenser -->
          <path d="M 640,130 L 740,130 L 740,180" fill="none" stroke="#60a5fa" stroke-width="4" stroke-dasharray="6 3" />

          <!-- 7. Condenser to ORC Feed Pump to Preheater -->
          <path d="M 740,240 L 740,280 L 640,280 L 640,220 L 470,220" fill="none" stroke="#38bdf8" stroke-width="3" />

          <!-- EQUIPMENT NODES -->
          <!-- WELLHEADS / GATHERING -->
          <g>
            <rect x="20" y="150" width="75" height="60" rx="8" fill="#1e293b" stroke="#ef4444" stroke-width="2" />
            <text x="32" y="172" fill="#fca5a5" font-size="10" font-weight="bold" font-family="monospace">PROD WELLS</text>
            <text x="30" y="190" fill="#cbd5e1" font-size="9" font-family="monospace">{{ twin().balances.brineProductionTotalKgS }} kg/s</text>
            <text x="30" y="202" fill="#cbd5e1" font-size="9" font-family="monospace">{{ twin().gatheringSystem.productionHeaderTempC }}°C | {{ twin().gatheringSystem.productionHeaderPressureBar }}b</text>
          </g>

          <!-- SEPARATOR / FLASH VESSEL -->
          <g>
            <rect x="220" y="80" width="60" height="80" rx="10" fill="#1e293b" stroke="#f97316" stroke-width="2" />
            <text x="226" y="105" fill="#fdba74" font-size="9" font-weight="bold" font-family="monospace">SEPARATOR</text>
            <text x="228" y="125" fill="#fed7aa" font-size="8" font-family="monospace">SEP-01</text>
            <text x="228" y="145" fill="#cbd5e1" font-size="8" font-family="monospace">{{ twin().separator.operatingPressure }} bar</text>
          </g>

          <!-- ORC VAPORIZER -->
          <g>
            <rect x="370" y="80" width="100" height="70" rx="8" fill="#1e293b" stroke="#c084fc" stroke-width="2" />
            <text x="382" y="102" fill="#e9d5ff" font-size="10" font-weight="bold" font-family="monospace">HEX-VAP-01</text>
            <text x="382" y="118" fill="#cbd5e1" font-size="8" font-family="monospace">Duty: {{ twin().heatExchangers[1].heatDuty }} MWth</text>
            <text x="382" y="130" fill="#cbd5e1" font-size="8" font-family="monospace">UA: {{ twin().heatExchangers[1].ua }} kW/K</text>
            <text x="382" y="142" [attr.fill]="twin().heatExchangers[1].foulingFactor > 0.2 ? '#f87171' : '#a7f3d0'" font-size="8" font-family="monospace">
              Foul: {{ (twin().heatExchangers[1].foulingFactor * 100).toFixed(0) }}%
            </text>
          </g>

          <!-- ORC PREHEATER -->
          <g>
            <rect x="370" y="185" width="100" height="70" rx="8" fill="#1e293b" stroke="#38bdf8" stroke-width="2" />
            <text x="382" y="208" fill="#bae6fd" font-size="10" font-weight="bold" font-family="monospace">HEX-PRE-01</text>
            <text x="382" y="224" fill="#cbd5e1" font-size="8" font-family="monospace">Duty: {{ twin().heatExchangers[0].heatDuty }} MWth</text>
            <text x="382" y="238" fill="#cbd5e1" font-size="8" font-family="monospace">LMTD: {{ twin().heatExchangers[0].lmtd }}°C</text>
          </g>

          <!-- TURBINE (Radial Inflow ORC) -->
          <g>
            <polygon points="570,90 640,110 640,150 570,170" fill="#1e293b" stroke="#a855f7" stroke-width="2" />
            <text x="580" y="125" fill="#f3e8ff" font-size="10" font-weight="bold" font-family="monospace">TURBINE</text>
            <text x="580" y="140" fill="#cbd5e1" font-size="8" font-family="monospace">{{ twin().turbine.shaftPower }} MW</text>
          </g>

          <!-- GENERATOR & GRID TRANSFORMER -->
          <g>
            <!-- Generator Shaft -->
            <line x1="640" y1="130" x2="665" y2="130" stroke="#94a3b8" stroke-width="6" />
            
            <!-- Generator Circle -->
            <circle cx="695" cy="130" r="28" fill="#1e293b" stroke="#10b981" stroke-width="2.5" />
            <text x="682" y="128" fill="#6ee7b7" font-size="11" font-weight="bold" font-family="monospace">GEN</text>
            <text x="672" y="142" fill="#a7f3d0" font-size="8" font-family="monospace">{{ twin().generator.electricalPowerOutput }} MWe</text>

            <!-- Transformer Box -->
            <rect x="760" y="105" width="55" height="50" rx="6" fill="#1e293b" stroke="#3b82f6" stroke-width="2" />
            <text x="770" y="125" fill="#93c5fd" font-size="9" font-weight="bold" font-family="monospace">XFMR</text>
            <text x="765" y="142" fill="#bfdbfe" font-size="8" font-family="monospace">132 kV</text>

            <!-- Grid Bus -->
            <line x1="815" y1="130" x2="880" y2="130" stroke="#10b981" stroke-width="4" />
            <polygon points="880,120 905,130 880,140" fill="#10b981" />
            <text x="830" y="120" fill="#34d399" font-size="10" font-weight="bold" font-family="monospace">GRID EXPORT</text>
            <text x="830" y="150" fill="#6ee7b7" font-size="9" font-family="monospace">{{ twin().grid.exportActivePowerMW }} MW</text>
          </g>

          <!-- CONDENSER (Air-Cooled ACC) -->
          <g>
            <rect x="710" y="180" width="70" height="60" rx="8" fill="#1e293b" stroke="#60a5fa" stroke-width="2" />
            <text x="722" y="202" fill="#bfdbfe" font-size="9" font-weight="bold" font-family="monospace">ACC / COND</text>
            <text x="718" y="218" fill="#cbd5e1" font-size="8" font-family="monospace">{{ twin().condenser.heatRejectionDuty }} MWth</text>
            <text x="718" y="230" fill="#cbd5e1" font-size="8" font-family="monospace">{{ twin().condenser.condensingTemperature }}°C | {{ twin().condenser.condenserPressure }}b</text>
          </g>

          <!-- DISTRICT HEATING HEAT EXCHANGER -->
          @if (twin().districtHeating.active) {
            <g>
              <rect x="470" y="290" width="90" height="60" rx="8" fill="#1e293b" stroke="#ec4899" stroke-width="2" />
              <text x="480" y="312" fill="#fbcfe8" font-size="9" font-weight="bold" font-family="monospace">DISTRICT HEAT</text>
              <text x="480" y="328" fill="#cbd5e1" font-size="8" font-family="monospace">{{ twin().districtHeating.thermalSuppliedMWth }} MWth</text>
              <text x="480" y="340" fill="#cbd5e1" font-size="8" font-family="monospace">{{ twin().districtHeating.supplyTemperature }}°C / {{ twin().districtHeating.returnTemperature }}°C</text>
            </g>
          }

          <!-- REINJECTION WELLHEADS -->
          <g>
            <rect x="830" y="290" width="75" height="60" rx="8" fill="#1e293b" stroke="#06b6d4" stroke-width="2" />
            <text x="838" y="312" fill="#a5f3fc" font-size="10" font-weight="bold" font-family="monospace">REINJECTION</text>
            <text x="838" y="328" fill="#cbd5e1" font-size="9" font-family="monospace">{{ twin().balances.brineReinjectionTotalKgS }} kg/s</text>
            <text x="838" y="340" fill="#cbd5e1" font-size="9" font-family="monospace">{{ twin().gatheringSystem.reinjectionHeaderTempC }}°C | {{ twin().gatheringSystem.reinjectionHeaderPressureBar }}b</text>
          </g>
        </svg>
      </div>

      <!-- Live Thermodynamics Strip -->
      <div class="grid grid-cols-2 md:grid-cols-5 gap-2 mt-3 text-xs">
        <div class="bg-slate-950 p-2 rounded-xl border border-slate-800">
          <span class="text-slate-500 text-[10px] block">Thermal Energy In</span>
          <span class="font-mono text-sm font-bold text-rose-400">{{ twin().balances.thermalEnergyInMWth }} MWth</span>
        </div>
        <div class="bg-slate-950 p-2 rounded-xl border border-slate-800">
          <span class="text-slate-500 text-[10px] block">Gross Generator Power</span>
          <span class="font-mono text-sm font-bold text-emerald-400">{{ twin().balances.grossElectricalPowerMW }} MWe</span>
        </div>
        <div class="bg-slate-950 p-2 rounded-xl border border-slate-800">
          <span class="text-slate-500 text-[10px] block">Parasitic Plant Load</span>
          <span class="font-mono text-sm font-bold text-amber-400">{{ twin().balances.parasiticAuxiliaryPowerMW }} MWe</span>
        </div>
        <div class="bg-slate-950 p-2 rounded-xl border border-slate-800">
          <span class="text-slate-500 text-[10px] block">Net Export Power</span>
          <span class="font-mono text-sm font-bold text-emerald-300">{{ twin().balances.netElectricalPowerMW }} MWe</span>
        </div>
        <div class="bg-slate-950 p-2 rounded-xl border border-slate-800">
          <span class="text-slate-500 text-[10px] block">Energy Balance Discrepancy</span>
          <span class="font-mono text-sm font-bold" [class]="twin().balances.energyBalanceDiscrepancyPercent < 1 ? 'text-emerald-400' : 'text-rose-400'">
            {{ twin().balances.energyBalanceDiscrepancyPercent }}% (±0.0 MW)
          </span>
        </div>
      </div>
    </div>
  `,
})
export class PlantSchematic {
  private physics = inject(PhysicsEngineService);
  readonly twin = this.physics.twin;

  cleanHeatExchangers(): void {
    this.physics.cleanHeatExchangers();
  }
}
