import {
  Component,
  ElementRef,
  ViewChild,
  OnInit,
  OnDestroy,
  inject,
  ChangeDetectionStrategy,
  signal,
  effect,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import * as THREE from 'three';
import { PhysicsEngineService } from '../services/physics-engine.service';

@Component({
  selector: 'app-subsurface-viewer',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative w-full h-full min-h-[540px] bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden flex flex-col">
      <!-- 3D Controls Overlay Bar -->
      <div class="absolute top-3 left-3 z-10 flex flex-wrap items-center gap-2 bg-slate-900/90 backdrop-blur-md px-3 py-2 rounded-xl border border-slate-700/60 shadow-lg text-xs">
        <span class="text-slate-400 font-semibold flex items-center gap-1.5 pr-2 border-r border-slate-700">
          <mat-icon class="text-emerald-400 !text-base !w-4 !h-4">layers</mat-icon>
          3D SUBSURFACE
        </span>

        <!-- Color Map Mode -->
        <button 
          (click)="setColorMapMode('temperature')"
          [class]="colorMapMode() === 'temperature' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' : 'text-slate-400 hover:text-slate-200'"
          class="px-2 py-1 rounded font-mono transition-colors">
          Temp Map (°C)
        </button>
        <button 
          (click)="setColorMapMode('pressure')"
          [class]="colorMapMode() === 'pressure' ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40' : 'text-slate-400 hover:text-slate-200'"
          class="px-2 py-1 rounded font-mono transition-colors">
          Pressure (bar)
        </button>

        <!-- Slicing Planes -->
        <div class="flex items-center gap-1 pl-2 border-l border-slate-700">
          <span class="text-slate-500">Slice:</span>
          <button 
            (click)="toggleSlice('xy')"
            [class]="activeSlice() === 'xy' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'text-slate-400'"
            class="px-1.5 py-0.5 rounded font-mono">
            XY
          </button>
          <button 
            (click)="toggleSlice('xz')"
            [class]="activeSlice() === 'xz' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'text-slate-400'"
            class="px-1.5 py-0.5 rounded font-mono">
            XZ
          </button>
          <button 
            (click)="toggleSlice('yz')"
            [class]="activeSlice() === 'yz' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'text-slate-400'"
            class="px-1.5 py-0.5 rounded font-mono">
            YZ
          </button>
          <button 
            (click)="toggleSlice('none')"
            [class]="activeSlice() === 'none' ? 'bg-slate-800 text-slate-200' : 'text-slate-500'"
            class="px-1.5 py-0.5 rounded">
            Off
          </button>
        </div>

        <!-- Layer Toggles -->
        <button 
          (click)="toggleFractures()"
          [class]="showFractures() ? 'text-amber-400 font-semibold' : 'text-slate-500'"
          class="flex items-center gap-1 px-1.5 py-0.5 rounded hover:bg-slate-800">
          <mat-icon class="!text-sm !w-3.5 !h-3.5">grain</mat-icon> DFN
        </button>
        <button 
          (click)="toggleMicroseismics()"
          [class]="showMicroseismic() ? 'text-rose-400 font-semibold' : 'text-slate-500'"
          class="flex items-center gap-1 px-1.5 py-0.5 rounded hover:bg-slate-800">
          <mat-icon class="!text-sm !w-3.5 !h-3.5">sensors</mat-icon> Seismicity
        </button>
      </div>

      <!-- Legend Overlay -->
      <div class="absolute bottom-3 left-3 z-10 bg-slate-900/85 backdrop-blur-md p-2.5 rounded-xl border border-slate-800 text-xs">
        <div class="font-semibold text-slate-300 mb-1.5 flex items-center justify-between gap-4">
          <span>{{ colorMapMode() === 'temperature' ? 'Reservoir Temperature' : 'Pore Pressure' }}</span>
          <span class="font-mono text-emerald-400 text-[10px]">{{ colorMapMode() === 'temperature' ? '65°C → 225°C' : '150 bar → 380 bar' }}</span>
        </div>
        <!-- Gradient bar -->
        <div class="w-48 h-2.5 rounded bg-gradient-to-r from-blue-600 via-emerald-500 via-amber-400 to-rose-600 shadow-inner"></div>
        <div class="flex justify-between text-[10px] text-slate-400 mt-1 font-mono">
          <span>Cold Inflow (65°C)</span>
          <span>Target (220°C)</span>
        </div>
        <div class="mt-2 pt-2 border-t border-slate-800 flex items-center gap-3 text-[10px]">
          <span class="flex items-center gap-1 text-emerald-400">
            <span class="w-2 h-2 rounded-full bg-emerald-500"></span> Prod Wells (P-01..04)
          </span>
          <span class="flex items-center gap-1 text-cyan-400">
            <span class="w-2 h-2 rounded-full bg-cyan-400"></span> Inj Wells (INJ-01..02)
          </span>
        </div>
      </div>

      <!-- Camera instructions -->
      <div class="absolute top-3 right-3 z-10 bg-slate-900/70 backdrop-blur-sm px-2.5 py-1 rounded-lg border border-slate-800/80 text-[10px] text-slate-400 flex items-center gap-2">
        <mat-icon class="!text-xs !w-3 !h-3 text-slate-500">3d_rotation</mat-icon>
        <span>Left Click: Rotate | Right Click: Pan | Scroll: Zoom</span>
      </div>

      <!-- Three.js Canvas Container -->
      <div #canvasContainer class="w-full h-full flex-1 cursor-grab active:cursor-grabbing"></div>
    </div>
  `,
})
export class SubsurfaceViewer implements OnInit, OnDestroy {
  @ViewChild('canvasContainer', { static: true }) canvasContainer!: ElementRef<HTMLDivElement>;

  private physics = inject(PhysicsEngineService);

  readonly colorMapMode = signal<'temperature' | 'pressure'>('temperature');
  readonly activeSlice = signal<'none' | 'xy' | 'xz' | 'yz'>('none');
  readonly showFractures = signal<boolean>(true);
  readonly showMicroseismic = signal<boolean>(true);

  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private animationFrameId: number | null = null;
  private resizeObserver: ResizeObserver | null = null;

  // Scene object groups
  private wellsGroup = new THREE.Group();
  private fracturesGroup = new THREE.Group();
  private seismicityGroup = new THREE.Group();
  private strataGroup = new THREE.Group();
  private thermalPlumeMesh!: THREE.Mesh;
  private slicePlaneMesh!: THREE.Mesh;

  // Camera interaction state
  private isMouseDown = false;
  private isRightMouseDown = false;
  private mousePrevX = 0;
  private mousePrevY = 0;
  private cameraTarget = new THREE.Vector3(0, -18, 0);
  private cameraRadius = 65;
  private cameraTheta = Math.PI / 4;
  private cameraPhi = Math.PI / 3;

  constructor() {
    effect(() => {
      // Re-trigger visual updates when twin state changes
      this.physics.twin();
      this.updateSceneObjects();
    });
  }

  ngOnInit(): void {
    if (typeof window === 'undefined') return;
    this.initThree();
    this.setupEventListeners();
  }

  ngOnDestroy(): void {
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
    }
    if (this.resizeObserver) {
      this.resizeObserver.disconnect();
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  setColorMapMode(mode: 'temperature' | 'pressure'): void {
    this.colorMapMode.set(mode);
    this.updateSceneObjects();
  }

  toggleSlice(slice: 'none' | 'xy' | 'xz' | 'yz'): void {
    this.activeSlice.set(slice);
    this.updateSlicePlane();
  }

  toggleFractures(): void {
    this.showFractures.update(v => !v);
    this.fracturesGroup.visible = this.showFractures();
  }

  toggleMicroseismics(): void {
    this.showMicroseismic.update(v => !v);
    this.seismicityGroup.visible = this.showMicroseismic();
  }

  private initThree(): void {
    const container = this.canvasContainer.nativeElement;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 540;

    // Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x020617); // Slate-950

    // Camera
    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    this.updateCameraPosition();

    // Renderer
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    container.appendChild(this.renderer.domElement);

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.75);
    this.scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0x60a5fa, 1.2);
    dirLight.position.set(50, 80, 50);
    this.scene.add(dirLight);

    const undergroundLight = new THREE.PointLight(0xf59e0b, 1.8, 120);
    undergroundLight.position.set(0, -20, 0);
    this.scene.add(undergroundLight);

    // Grid Floor / Surface
    const gridHelper = new THREE.GridHelper(50, 20, 0x10b981, 0x1e293b);
    gridHelper.position.y = 0;
    this.scene.add(gridHelper);

    // Add Object Groups
    this.scene.add(this.strataGroup);
    this.scene.add(this.wellsGroup);
    this.scene.add(this.fracturesGroup);
    this.scene.add(this.seismicityGroup);

    this.buildGeologicalStrata();
    this.buildThermalPlume();
    this.buildSlicePlane();
    this.updateSceneObjects();

    // Start Render Loop
    this.animate();

    // Resize Observer
    this.resizeObserver = new ResizeObserver(() => {
      if (!this.canvasContainer) return;
      const w = this.canvasContainer.nativeElement.clientWidth;
      const h = this.canvasContainer.nativeElement.clientHeight;
      if (w > 0 && h > 0) {
        this.camera.aspect = w / h;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(w, h);
      }
    });
    this.resizeObserver.observe(container);
  }

  private buildGeologicalStrata(): void {
    this.strataGroup.clear();
    const twin = this.physics.twin();
    const layers = twin.geology.layers;
    const boxWidth = 40;
    const boxDepth = 40;

    layers.forEach((layer) => {
      const topNorm = -(layer.depthStart / 5200) * 35;
      const bottomNorm = -(layer.depthEnd / 5200) * 35;
      const thickness = Math.abs(bottomNorm - topNorm);
      const centerY = topNorm - thickness / 2;

      const geometry = new THREE.BoxGeometry(boxWidth, thickness, boxDepth);
      const color = layer.id === 'L4' ? 0xf59e0b : layer.id === 'L3' ? 0x94a3b8 : layer.id === 'L2' ? 0x334155 : 0x1e293b;
      const material = new THREE.MeshStandardMaterial({
        color,
        transparent: true,
        opacity: layer.id === 'L4' ? 0.25 : 0.12,
        roughness: 0.8,
        wireframe: false,
      });
      const mesh = new THREE.Mesh(geometry, material);
      mesh.position.set(0, centerY, 0);

      // Add bounding wireframe edge
      const edges = new THREE.EdgesGeometry(geometry);
      const line = new THREE.LineSegments(edges, new THREE.LineBasicMaterial({ color: 0x475569, opacity: 0.3, transparent: true }));
      mesh.add(line);

      this.strataGroup.add(mesh);
    });
  }

  private buildThermalPlume(): void {
    const geo = new THREE.CylinderGeometry(8, 14, 18, 32, 8, true);
    const mat = new THREE.MeshBasicMaterial({
      color: 0xef4444,
      transparent: true,
      opacity: 0.22,
      side: THREE.DoubleSide,
      wireframe: true,
    });
    this.thermalPlumeMesh = new THREE.Mesh(geo, mat);
    this.thermalPlumeMesh.position.set(2, -24, 0);
    this.scene.add(this.thermalPlumeMesh);
  }

  private buildSlicePlane(): void {
    const geo = new THREE.PlaneGeometry(42, 42);
    const mat = new THREE.MeshBasicMaterial({
      color: 0x10b981,
      transparent: true,
      opacity: 0.25,
      side: THREE.DoubleSide,
      wireframe: true,
    });
    this.slicePlaneMesh = new THREE.Mesh(geo, mat);
    this.slicePlaneMesh.visible = false;
    this.scene.add(this.slicePlaneMesh);
  }

  private updateSlicePlane(): void {
    const slice = this.activeSlice();
    if (slice === 'none') {
      this.slicePlaneMesh.visible = false;
    } else if (slice === 'xy') {
      this.slicePlaneMesh.visible = true;
      this.slicePlaneMesh.rotation.set(Math.PI / 2, 0, 0);
      this.slicePlaneMesh.position.set(0, -22, 0);
    } else if (slice === 'xz') {
      this.slicePlaneMesh.visible = true;
      this.slicePlaneMesh.rotation.set(0, 0, 0);
      this.slicePlaneMesh.position.set(0, -18, 0);
    } else if (slice === 'yz') {
      this.slicePlaneMesh.visible = true;
      this.slicePlaneMesh.rotation.set(0, Math.PI / 2, 0);
      this.slicePlaneMesh.position.set(0, -18, 0);
    }
  }

  private updateSceneObjects(): void {
    if (!this.scene) return;
    const twin = this.physics.twin();

    // 1. Render Wells
    this.wellsGroup.clear();
    twin.wells.forEach(well => {
      const isProd = well.role === 'production';
      const wellColor = isProd ? 0x10b981 : 0x06b6d4; // Emerald vs Cyan

      // Generate 3D Tube along well trajectory points
      const points: THREE.Vector3[] = well.trajectory.map(pt => {
        const xNorm = (pt.x / 2000) * 18;
        const yNorm = -(pt.measuredDepth / 5200) * 35;
        const zNorm = (pt.y / 2000) * 18;
        return new THREE.Vector3(xNorm, yNorm, zNorm);
      });

      if (points.length >= 2) {
        const curve = new THREE.CatmullRomCurve3(points);
        const tubeGeo = new THREE.TubeGeometry(curve, 32, 0.4, 8, false);
        const tubeMat = new THREE.MeshStandardMaterial({
          color: wellColor,
          emissive: wellColor,
          emissiveIntensity: 0.4,
          roughness: 0.3,
        });
        const tubeMesh = new THREE.Mesh(tubeGeo, tubeMat);
        this.wellsGroup.add(tubeMesh);

        // Wellhead Marker at Surface
        const wellheadGeo = new THREE.SphereGeometry(0.8, 16, 16);
        const wellheadMat = new THREE.MeshBasicMaterial({ color: wellColor });
        const wellheadMesh = new THREE.Mesh(wellheadGeo, wellheadMat);
        wellheadMesh.position.copy(points[0]);
        this.wellsGroup.add(wellheadMesh);

        // Perforation Interval highlight (Bottomhole)
        const perfGeo = new THREE.CylinderGeometry(0.65, 0.65, 3.5, 12);
        const perfMat = new THREE.MeshBasicMaterial({ color: 0xf59e0b, wireframe: true });
        const perfMesh = new THREE.Mesh(perfGeo, perfMat);
        perfMesh.position.copy(points[points.length - 1]);
        this.wellsGroup.add(perfMesh);
      }
    });

    // 2. Render DFN Fracture Planes
    this.fracturesGroup.clear();
    twin.fractureNetwork.fractures.forEach(dfn => {
      const fracGeo = new THREE.PlaneGeometry(dfn.length / 120, dfn.height / 70);
      const fracMat = new THREE.MeshStandardMaterial({
        color: dfn.activated ? 0xf59e0b : 0x64748b,
        transparent: true,
        opacity: dfn.activated ? 0.45 : 0.2,
        side: THREE.DoubleSide,
      });
      const fracMesh = new THREE.Mesh(fracGeo, fracMat);
      
      const xNorm = (dfn.center[0] / 2000) * 18;
      const yNorm = -(dfn.center[2] / 5200) * 35;
      const zNorm = (dfn.center[1] / 2000) * 18;
      fracMesh.position.set(xNorm, yNorm, zNorm);
      fracMesh.rotation.y = (dfn.strike * Math.PI) / 180;
      fracMesh.rotation.x = ((90 - dfn.dip) * Math.PI) / 180;
      this.fracturesGroup.add(fracMesh);
    });

    // 3. Render Microseismic Events
    this.seismicityGroup.clear();
    twin.seismicity.events.slice(0, 60).forEach(ev => {
      const radius = Math.max(0.25, Math.min(1.6, (ev.magnitude + 1.5) * 0.45));
      const evGeo = new THREE.SphereGeometry(radius, 8, 8);
      const evColor = ev.magnitude >= 1.5 ? 0xef4444 : ev.magnitude >= 0.5 ? 0xf59e0b : 0x10b981;
      const evMat = new THREE.MeshBasicMaterial({
        color: evColor,
        transparent: true,
        opacity: 0.85,
      });
      const evMesh = new THREE.Mesh(evGeo, evMat);
      const xNorm = (ev.x / 2000) * 18;
      const yNorm = -(ev.z / 5200) * 35;
      const zNorm = (ev.y / 2000) * 18;
      evMesh.position.set(xNorm, yNorm, zNorm);
      this.seismicityGroup.add(evMesh);
    });

    // 4. Update Thermal Plume Dimensions
    if (this.thermalPlumeMesh) {
      const sweepFrac = Math.min(2.0, twin.reservoir.activeThermalSweepVolumeM3 / 4.8e7);
      this.thermalPlumeMesh.scale.set(sweepFrac, 1, sweepFrac);
    }
  }

  private animate = (): void => {
    this.animationFrameId = requestAnimationFrame(this.animate);
    if (this.thermalPlumeMesh) {
      this.thermalPlumeMesh.rotation.y += 0.002;
    }
    this.renderer.render(this.scene, this.camera);
  };

  private setupEventListeners(): void {
    const el = this.canvasContainer.nativeElement;

    el.addEventListener('mousedown', (e: MouseEvent) => {
      if (e.button === 2) {
        this.isRightMouseDown = true;
      } else {
        this.isMouseDown = true;
      }
      this.mousePrevX = e.clientX;
      this.mousePrevY = e.clientY;
    });

    window.addEventListener('mousemove', (e: MouseEvent) => {
      if (!this.isMouseDown && !this.isRightMouseDown) return;
      const dx = e.clientX - this.mousePrevX;
      const dy = e.clientY - this.mousePrevY;
      this.mousePrevX = e.clientX;
      this.mousePrevY = e.clientY;

      if (this.isMouseDown) {
        // Orbit rotation
        this.cameraTheta -= dx * 0.008;
        this.cameraPhi = Math.max(0.1, Math.min(Math.PI - 0.1, this.cameraPhi - dy * 0.008));
        this.updateCameraPosition();
      } else if (this.isRightMouseDown) {
        // Pan
        this.cameraTarget.y += dy * 0.06;
        this.updateCameraPosition();
      }
    });

    window.addEventListener('mouseup', () => {
      this.isMouseDown = false;
      this.isRightMouseDown = false;
    });

    el.addEventListener('wheel', (e: WheelEvent) => {
      e.preventDefault();
      this.cameraRadius = Math.max(15, Math.min(160, this.cameraRadius + e.deltaY * 0.05));
      this.updateCameraPosition();
    }, { passive: false });

    el.addEventListener('contextmenu', (e: MouseEvent) => e.preventDefault());
  }

  private updateCameraPosition(): void {
    const x = this.cameraTarget.x + this.cameraRadius * Math.sin(this.cameraPhi) * Math.sin(this.cameraTheta);
    const y = this.cameraTarget.y + this.cameraRadius * Math.cos(this.cameraPhi);
    const z = this.cameraTarget.z + this.cameraRadius * Math.sin(this.cameraPhi) * Math.cos(this.cameraTheta);
    this.camera.position.set(x, y, z);
    this.camera.lookAt(this.cameraTarget);
  }
}
