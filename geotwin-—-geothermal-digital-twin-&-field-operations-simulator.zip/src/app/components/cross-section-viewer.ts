import { Component, ChangeDetectionStrategy, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PhysicsEngineService } from '../services/physics-engine.service';

@Component({
  selector: 'app-cross-section-viewer',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-slate-900/90 rounded-2xl border border-slate-800 p-4 flex flex-col h-full">
      <div class="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
        <div class="flex items-center gap-2">
          <mat-icon class="text-amber-400">content_cut</mat-icon>
          <div>
            <h3 class="text-sm font-bold text-slate-100 uppercase tracking-wide">Inter-Well Cross Section & Thermal Sweep</h3>
            <p class="text-[11px] text-slate-400">Injection → Fracture Network → Thermal Conduction → Production</p>
          </div>
        </div>

        <!-- Well Pair Selectors -->
        <div class="flex items-center gap-2 text-xs">
          <div class="flex items-center gap-1 bg-slate-950 px-2 py-1 rounded-lg border border-slate-800">
            <span class="text-cyan-400 font-semibold font-mono">Inj:</span>
            <select 
              [value]="selectedInjWellId()" 
              (change)="setInjWell($any($event.target).value)"
              class="bg-transparent text-slate-200 font-mono outline-none cursor-pointer">
              @for (w of injectionWells(); track w.id) {
                <option [value]="w.id" class="bg-slate-900 text-slate-200">{{ w.name }}</option>
              }
            </select>
          </div>

          <mat-icon class="text-slate-600 !text-sm !w-4 !h-4">arrow_forward</mat-icon>

          <div class="flex items-center gap-1 bg-slate-950 px-2 py-1 rounded-lg border border-slate-800">
            <span class="text-emerald-400 font-semibold font-mono">Prod:</span>
            <select 
              [value]="selectedProdWellId()" 
              (change)="setProdWell($any($event.target).value)"
              class="bg-transparent text-slate-200 font-mono outline-none cursor-pointer">
              @for (w of productionWells(); track w.id) {
                <option [value]="w.id" class="bg-slate-900 text-slate-200">{{ w.name }}</option>
              }
            </select>
          </div>
        </div>
      </div>

      <!-- 2D SVG Subsurface Geological Cutaway -->
      <div class="relative w-full flex-1 min-h-[300px] bg-slate-950 rounded-xl border border-slate-800/80 overflow-hidden">
        <svg class="w-full h-full" viewBox="0 0 800 450" preserveAspectRatio="none">
          <!-- Background Geological Strata Gradients -->
          <defs>
            <linearGradient id="strataSurface" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stop-color="#1e293b" />
              <stop offset="100%" stop-color="#334155" />
            </linearGradient>
            <linearGradient id="strataCaprock" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stop-color="#334155" />
              <stop offset="100%" stop-color="#475569" />
            </linearGradient>
            <linearGradient id="strataGranite" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stop-color="#475569" />
              <stop offset="100%" stop-color="#78350f" />
            </linearGradient>
            <linearGradient id="thermalSweepPlume" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stop-color="#06b6d4" stop-opacity="0.8" />
              <stop [attr.offset]="breakthroughPercent() + '%'" stop-color="#0ea5e9" stop-opacity="0.6" />
              <stop offset="85%" stop-color="#f59e0b" stop-opacity="0.4" />
              <stop offset="100%" stop-color="#ef4444" stop-opacity="0.8" />
            </linearGradient>
            <pattern id="fractureGrid" width="40" height="40" patternUnits="userSpaceOnUse">
              <line x1="0" y1="0" x2="40" y2="40" stroke="#f59e0b" stroke-width="0.75" stroke-opacity="0.4" />
              <line x1="40" y1="0" x2="0" y2="40" stroke="#f59e0b" stroke-width="0.75" stroke-opacity="0.25" />
              <line x1="20" y1="0" x2="20" y2="40" stroke="#f59e0b" stroke-dasharray="2 4" stroke-width="0.5" stroke-opacity="0.3" />
            </pattern>
          </defs>

          <!-- Geological Strata Layers -->
          <rect x="0" y="0" width="800" height="35" fill="url(#strataSurface)" />
          <text x="15" y="22" fill="#94a3b8" font-size="10" font-family="monospace">0m Surface Alluvium</text>

          <rect x="0" y="35" width="800" height="95" fill="url(#strataCaprock)" />
          <text x="15" y="65" fill="#cbd5e1" font-size="10" font-family="monospace">1200m Killas Slate Caprock (Sealing Barrier)</text>

          <rect x="0" y="130" width="800" height="130" fill="url(#strataGranite)" />
          <text x="15" y="160" fill="#fde68a" font-size="10" font-family="monospace">3200m Cornubian Granite Batholith (High Heat Flow)</text>

          <!-- Target Geothermal Reservoir Zone -->
          <rect x="0" y="260" width="800" height="190" fill="#1c1917" />
          <rect x="0" y="260" width="800" height="190" fill="url(#fractureGrid)" />
          <text x="15" y="285" fill="#f59e0b" font-size="11" font-weight="bold" font-family="monospace">
            5000m Deep Fractured Reservoir Zone (T = {{ twin().reservoir.averageTemperature }}°C)
          </text>

          <!-- Thermal Sweep Volume between Wells -->
          <polygon 
            points="180,310 620,320 640,430 160,420" 
            fill="url(#thermalSweepPlume)" 
            class="transition-all duration-1000"
          />

          <!-- Cold Breakthrough Front Line -->
          <line 
            [attr.x1]="180 + (440 * (breakthroughPercent() / 100))" 
            y1="300" 
            [attr.x2]="160 + (480 * (breakthroughPercent() / 100))" 
            y2="440" 
            stroke="#38bdf8" 
            stroke-width="3" 
            stroke-dasharray="6 4"
          />
          <text 
            [attr.x]="160 + (440 * (breakthroughPercent() / 100))" 
            y="295" 
            fill="#38bdf8" 
            font-size="9" 
            font-weight="bold" 
            font-family="monospace">
            Thermal Front ({{ twin().reservoir.thermalBreakthroughFrontDistanceM }}m)
          </text>

          <!-- INJECTION WELL (Left) -->
          <g>
            <!-- Wellbore Casing -->
            <path d="M 180,20 L 180,180 Q 180,240 170,330 L 160,420" fill="none" stroke="#06b6d4" stroke-width="5" />
            <!-- Perforations -->
            <line x1="150" y1="360" x2="170" y2="360" stroke="#38bdf8" stroke-width="3" />
            <line x1="145" y1="385" x2="165" y2="385" stroke="#38bdf8" stroke-width="3" />
            <line x1="140" y1="410" x2="160" y2="410" stroke="#38bdf8" stroke-width="3" />
            <!-- Wellhead -->
            <rect x="168" y="10" width="24" height="15" rx="3" fill="#0891b2" stroke="#67e8f9" stroke-width="1.5" />
            <text x="135" y="8" fill="#67e8f9" font-size="11" font-weight="bold" font-family="monospace">{{ currentInjWell()?.name }}</text>
            <text x="95" y="45" fill="#a5f3fc" font-size="9" font-family="monospace">Tin: 65°C | Pin: {{ currentInjWell()?.wellheadPressure }} bar</text>
            <text x="95" y="58" fill="#a5f3fc" font-size="9" font-family="monospace">Flow: {{ currentInjWell()?.flowRate }} kg/s</text>
          </g>

          <!-- PRODUCTION WELL (Right) -->
          <g>
            <!-- Wellbore Casing -->
            <path d="M 620,20 L 620,160 Q 620,240 630,330 L 640,430" fill="none" stroke="#10b981" stroke-width="5" />
            <!-- Perforations -->
            <line x1="630" y1="360" x2="650" y2="360" stroke="#34d399" stroke-width="3" />
            <line x1="635" y1="385" x2="655" y2="385" stroke="#34d399" stroke-width="3" />
            <line x1="640" y1="410" x2="660" y2="410" stroke="#34d399" stroke-width="3" />
            <!-- Wellhead -->
            <rect x="608" y="10" width="24" height="15" rx="3" fill="#059669" stroke="#6ee7b7" stroke-width="1.5" />
            <text x="590" y="8" fill="#6ee7b7" font-size="11" font-weight="bold" font-family="monospace">{{ currentProdWell()?.name }}</text>
            <text x="645" y="45" fill="#a7f3d0" font-size="9" font-family="monospace">Tout: {{ currentProdWell()?.wellheadTemperature }}°C</text>
            <text x="645" y="58" fill="#a7f3d0" font-size="9" font-family="monospace">Flow: {{ currentProdWell()?.flowRate }} kg/s | P: {{ currentProdWell()?.wellheadPressure }} bar</text>
          </g>

          <!-- Animated Fluid Stream Flow Particles -->
          <g class="animate-pulse">
            <circle cx="240" cy="350" r="3.5" fill="#38bdf8" />
            <circle cx="330" cy="365" r="3.5" fill="#38bdf8" />
            <circle cx="420" cy="375" r="3.5" fill="#f59e0b" />
            <circle cx="510" cy="380" r="3.5" fill="#ef4444" />
            <circle cx="590" cy="390" r="3.5" fill="#ef4444" />
          </g>
        </svg>
      </div>

      <!-- Quantitative Breakthrough Metrics Card -->
      <div class="grid grid-cols-4 gap-2 mt-3 text-xs">
        <div class="bg-slate-950/80 p-2 rounded-xl border border-slate-800">
          <div class="text-slate-400 text-[10px]">Inter-Well Spacing</div>
          <div class="font-mono text-sm font-bold text-slate-100 mt-0.5">1,450 m</div>
          <div class="text-[10px] text-slate-500">Cornwall granite doublet</div>
        </div>

        <div class="bg-slate-950/80 p-2 rounded-xl border border-slate-800">
          <div class="text-slate-400 text-[10px]">Thermal Sweep Volume</div>
          <div class="font-mono text-sm font-bold text-amber-400 mt-0.5">
            {{ (twin().reservoir.activeThermalSweepVolumeM3 / 1e6).toFixed(1) }}M m³
          </div>
          <div class="text-[10px] text-slate-500">Active DFN volume</div>
        </div>

        <div class="bg-slate-950/80 p-2 rounded-xl border border-slate-800">
          <div class="text-slate-400 text-[10px]">Thermal Front Position</div>
          <div class="font-mono text-sm font-bold text-cyan-400 mt-0.5">
            {{ twin().reservoir.thermalBreakthroughFrontDistanceM }} m
          </div>
          <div class="text-[10px] text-slate-500">From injection wellhead</div>
        </div>

        <div class="bg-slate-950/80 p-2 rounded-xl border border-slate-800">
          <div class="text-slate-400 text-[10px]">Est. Breakthrough Time</div>
          <div class="font-mono text-sm font-bold text-emerald-400 mt-0.5">
            {{ twin().reservoir.estimatedBreakthroughYears }} yrs
          </div>
          <div class="text-[10px] text-slate-500">Until >5% ΔT decline</div>
        </div>
      </div>
    </div>
  `,
})
export class CrossSectionViewer {
  private physics = inject(PhysicsEngineService);
  readonly twin = this.physics.twin;

  readonly selectedInjWellId = signal<string>('INJ-01');
  readonly selectedProdWellId = signal<string>('P-01');

  readonly injectionWells = computed(() => this.twin().wells.filter(w => w.role === 'injection'));
  readonly productionWells = computed(() => this.twin().wells.filter(w => w.role === 'production'));

  readonly currentInjWell = computed(() => this.twin().wells.find(w => w.id === this.selectedInjWellId()));
  readonly currentProdWell = computed(() => this.twin().wells.find(w => w.id === this.selectedProdWellId()));

  readonly breakthroughPercent = computed(() => {
    const dist = this.twin().reservoir.thermalBreakthroughFrontDistanceM;
    return Math.min(95, Math.max(5, (dist / 1800) * 100));
  });

  setInjWell(id: string): void {
    this.selectedInjWellId.set(id);
  }

  setProdWell(id: string): void {
    this.selectedProdWellId.set(id);
  }
}
