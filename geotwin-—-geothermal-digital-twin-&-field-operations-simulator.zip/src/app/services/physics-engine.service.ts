import { Injectable, signal } from '@angular/core';
import {
  GeothermalDigitalTwin,
  GeothermalArchitecture,
  GridDispatchMode,
  WorkingFluidType,
  CoolingType,
  WellModel,
  ReservoirGridCell,
  DiscreteFracture,
  HeatExchangerModel,
  MicroseismicEvent,
  SensorTelemetryPacket,
  ProductionForecastPoint,
  MonteCarloResult,
} from '../models/geothermal.model';
import {
  WORKING_FLUIDS,
  WaterSteamPhysics,
  HeatTransferSolver,
  WellboreHydraulics,
  GeochemistryPhysics,
} from '../utils/thermodynamics';

@Injectable({
  providedIn: 'root',
})
export class PhysicsEngineService {
  // Primary Digital Twin reactive state
  readonly twin = signal<GeothermalDigitalTwin>(this.createInitialDigitalTwin());
  
  // Simulation loop reference
  private loopIntervalId: ReturnType<typeof setInterval> | null = null;
  private simulationTickCount = 0;
  
  // Historical telemetry log (last 60 ticks)
  readonly telemetryHistory = signal<{ timestamp: number; netPowerMW: number; reservoirTempC: number; injectionPressureBar: number; silicaSSI: number; seismicityCount: number }[]>([]);

  constructor() {
    this.startSimulation();
  }

  startSimulation(): void {
    if (this.loopIntervalId) return;
    this.twin.update(t => ({ ...t, isSimulating: true }));
    this.loopIntervalId = setInterval(() => {
      this.stepCoupledPhysics();
    }, 1000);
  }

  pauseSimulation(): void {
    if (this.loopIntervalId) {
      clearInterval(this.loopIntervalId);
      this.loopIntervalId = null;
    }
    this.twin.update(t => ({ ...t, isSimulating: false }));
  }

  setSpeedMultiplier(speed: number): void {
    this.twin.update(t => ({ ...t, simulationSpeedMultiplier: speed }));
  }

  setArchitecture(arch: GeothermalArchitecture): void {
    this.twin.update(t => {
      const updated = { ...t, architecture: arch };
      if (arch === 'hydrothermal') {
        updated.name = 'Wairakei-Style Hydrothermal Field';
        updated.geology.layers[3].rockType.permeability = 85; // higher natural perm
      } else if (arch === 'egs') {
        updated.name = 'Cornwall EGS Granite Field';
        updated.geology.layers[3].rockType.permeability = 2.5; // low matrix, engineered fractures
      } else if (arch === 'deep_heat') {
        updated.name = 'Paris Basin Deep Geothermal Heat System';
        updated.districtHeating.active = true;
      } else if (arch === 'hybrid_chp') {
        updated.name = 'Hengill Hybrid Power & District Heat System';
        updated.districtHeating.active = true;
      }
      return updated;
    });
    this.stepCoupledPhysics();
  }

  setWorkingFluid(fluidType: WorkingFluidType): void {
    const fluid = WORKING_FLUIDS[fluidType];
    this.twin.update(t => ({
      ...t,
      workingFluid: fluid,
    }));
    this.stepCoupledPhysics();
  }

  setGridDispatchMode(mode: GridDispatchMode): void {
    this.twin.update(t => ({
      ...t,
      grid: { ...t.grid, dispatchMode: mode },
    }));
    this.stepCoupledPhysics();
  }

  setCoolingType(cooling: CoolingType): void {
    this.twin.update(t => ({
      ...t,
      condenser: { ...t.condenser, coolingType: cooling },
    }));
    this.stepCoupledPhysics();
  }

  updateWellChoke(wellId: string, chokePercent: number): void {
    this.twin.update(t => ({
      ...t,
      wells: t.wells.map(w => w.id === wellId ? { ...w, chokeOpening: Math.max(0, Math.min(100, chokePercent)) } : w),
    }));
    this.stepCoupledPhysics();
  }

  toggleWellStatus(wellId: string): void {
    this.twin.update(t => ({
      ...t,
      wells: t.wells.map(w => {
        if (w.id === wellId) {
          const newStatus = w.status === 'active' ? 'shut_in' : 'active';
          return { ...w, status: newStatus };
        }
        return w;
      }),
    }));
    this.stepCoupledPhysics();
  }

  setDistrictHeatingDemand(demandMWth: number): void {
    this.twin.update(t => ({
      ...t,
      districtHeating: {
        ...t.districtHeating,
        active: demandMWth > 0,
        thermalDemandMWth: demandMWth,
      },
    }));
    this.stepCoupledPhysics();
  }

  cleanHeatExchangers(): void {
    this.twin.update(t => ({
      ...t,
      heatExchangers: t.heatExchangers.map(hx => ({
        ...hx,
        foulingFactor: 0,
        ua: hx.nominalUa,
      })),
      maintenance: t.maintenance.map(m => m.category === 'heat_exchanger' ? {
        ...m,
        foulingOrWearPercent: 0,
        healthIndex: 98,
        status: 'nominal',
        recentAnomaly: 'Cleaned via chemical flush and mechanical pigging',
      } : m),
    }));
    this.stepCoupledPhysics();
  }

  /**
   * The Core Digital Twin Coupled Physics Solver
   * Propagates: Reservoir -> Fractures -> Wells -> Gathering -> Flash/ORC -> Grid -> Reinjection -> Chemistry -> Seismicity
   */
  stepCoupledPhysics(): void {
    this.simulationTickCount++;
    const t = this.twin();
    const speed = t.simulationSpeedMultiplier;
    const now = Date.now();

    // 1. Calculate Reservoir Evolution & Thermal Sweep
    const totalProductionChoke = t.wells
      .filter(w => w.role === 'production' && w.status === 'active')
      .reduce((sum, w) => sum + (w.chokeOpening / 100) * w.targetFlowRate, 0);

    const totalInjectionChoke = t.wells
      .filter(w => w.role === 'injection' && w.status === 'active')
      .reduce((sum, w) => sum + (w.chokeOpening / 100) * w.targetFlowRate, 0);

    // Thermal breakthrough progression
    const sweepVolume = t.reservoir.activeThermalSweepVolumeM3 + totalInjectionChoke * 0.15 * speed;
    const coldFrontDist = Math.min(1800, t.reservoir.thermalBreakthroughFrontDistanceM + (totalInjectionChoke / 120) * 0.4 * speed);
    const breakthroughYears = Math.max(1.5, 28 - (totalInjectionChoke / 150) * 8 - (speed * 0.05));

    // Reservoir temperature and pressure drawdown
    const pressureDepletion = (totalProductionChoke - totalInjectionChoke) * 0.002;
    const currentResPressure = Math.max(120, 310 - pressureDepletion);
    const thermalDepletion = (totalProductionChoke * 0.00015 * (speed / 10)) + (coldFrontDist > 1400 ? 0.05 * (coldFrontDist - 1400) / 100 : 0);
    const currentResTemp = Math.max(110, 215.0 - thermalDepletion);

    // Update Reservoir Grid Cells (3D distribution)
    const updatedCells: ReservoirGridCell[] = t.reservoir.cells.map(cell => {
      // Inflow near injection wells (x=2, y=3 and x=8, y=7) cools local cells
      const distToInj = Math.sqrt(Math.pow(cell.posX - 400, 2) + Math.pow(cell.posY - 600, 2));
      const coolingEffect = distToInj < 500 ? (1 - distToInj / 500) * 15 * (coldFrontDist / 1800) : 0;
      const cellTemp = Math.max(65, cell.initialTemperature - coolingEffect - thermalDepletion * 0.8);
      const cellPress = Math.max(80, cell.initialPressure - (distToInj < 400 ? -15 : 12));
      return {
        ...cell,
        temperature: cellTemp,
        pressure: cellPress,
        enthalpy: WaterSteamPhysics.saturatedLiquidEnthalpy(cellTemp),
      };
    });

    // 2. Solve Well Hydraulics & Temperature Profile (DTS)
    let totalBrineFlowKgS = 0;
    let totalThermalPowerMWth = 0;
    const updatedWells: WellModel[] = t.wells.map(well => {
      if (well.status !== 'active') {
        return {
          ...well,
          flowRate: 0,
          wellheadPressure: 1.0,
          wellheadTemperature: 25.0,
          steamQuality: 0,
        };
      }

      const flow = (well.chokeOpening / 100) * well.targetFlowRate;
      if (well.role === 'production') {
        totalBrineFlowKgS += flow;
        // Hydraulics: Bottomhole P = P_res - q/PI
        const drawdown = flow / Math.max(0.1, well.productivityIndex);
        const pwf = Math.max(20, currentResPressure - drawdown);
        
        // Pressure loss up wellbore
        const drop = WellboreHydraulics.calculatePressureDrop(
          well.depth,
          flow,
          well.tubingDiameter,
          well.roughness,
          (currentResTemp + 160) / 2,
          pwf
        );

        // Wellhead temperature with wellbore heat conduction loss
        const wellheadT = Math.max(50, currentResTemp - (drop.frictionLossBar * 0.05) - (well.depth / 1000) * 3.2);
        const wellheadP = Math.max(4.5, pwf - drop.hydrostaticGainBar - drop.frictionLossBar);
        const satT = WaterSteamPhysics.saturationTemperature(wellheadP);
        const isFlashing = wellheadT > satT && wellheadP < 25;
        const steamQuality = isFlashing ? Math.min(0.35, (wellheadT - satT) / 120) : 0;
        const wellheadH = WaterSteamPhysics.saturatedLiquidEnthalpy(wellheadT) + steamQuality * 2100;
        
        const qWell = flow * (wellheadH - WaterSteamPhysics.saturatedLiquidEnthalpy(70)) / 1000;
        totalThermalPowerMWth += Math.max(0, qWell);

        // DTS profile
        const dts = well.dtsProfile.map(pt => {
          const depthFrac = pt.depth / well.depth;
          const predT = 20 + depthFrac * (currentResTemp - 20);
          const obsT = predT + Math.sin(pt.depth / 300 + this.simulationTickCount * 0.1) * 0.6;
          return {
            ...pt,
            predictedTemp: Number(predT.toFixed(1)),
            observedTemp: Number(obsT.toFixed(1)),
            strainMicro: Number((depthFrac * 140 + flow * 0.2).toFixed(1)),
          };
        });

        // ESP pump power if equipped
        let pumpPowerKW = 0;
        if (well.hasPump && well.pumpHead) {
          pumpPowerKW = (flow * 9.81 * well.pumpHead) / (1000 * (well.pumpEfficiency || 0.72));
        }

        return {
          ...well,
          flowRate: Number(flow.toFixed(1)),
          bottomholePressure: Number(pwf.toFixed(1)),
          wellheadPressure: Number(wellheadP.toFixed(1)),
          bottomholeTemperature: Number(currentResTemp.toFixed(1)),
          wellheadTemperature: Number(wellheadT.toFixed(1)),
          wellheadEnthalpy: Number(wellheadH.toFixed(1)),
          steamQuality: Number(steamQuality.toFixed(3)),
          pumpPower: Number(pumpPowerKW.toFixed(1)),
          dtsProfile: dts,
        };
      } else {
        // Injection Well
        const injectionPwf = currentResPressure + flow / Math.max(0.1, well.productivityIndex);
        const injWellheadP = Math.max(15, injectionPwf - (well.depth * 9.81 * 990 / 100000) + 12);
        return {
          ...well,
          flowRate: Number(flow.toFixed(1)),
          bottomholePressure: Number(injectionPwf.toFixed(1)),
          wellheadPressure: Number(injWellheadP.toFixed(1)),
          bottomholeTemperature: 75.0,
          wellheadTemperature: 65.0,
        };
      }
    });

    // 3. Surface Gathering & Separator
    const headerP = Math.max(3.5, 9.8 - (totalBrineFlowKgS / 200) * 1.2);
    const headerT = currentResTemp - 6.5;
    const sepSteamFlow = t.architecture === 'hydrothermal' ? totalBrineFlowKgS * 0.18 : 0;
    const sepBrineFlow = totalBrineFlowKgS - sepSteamFlow;

    // 4. Geochemistry & Feedback into Heat Exchanger Fouling
    const silicaSSI = GeochemistryPhysics.calculateSilicaSSI(t.chemistry.silicaSiO2, headerT - 40);
    const lsi = GeochemistryPhysics.calculateLSI(t.chemistry.ph, headerT - 30, t.chemistry.tds, t.chemistry.calciumCa, 240);
    const rsi = GeochemistryPhysics.calculateRSI(t.chemistry.ph, lsi);
    const scalingRate = silicaSSI > 1.0 ? (silicaSSI - 1.0) * 1.8 + (lsi > 0 ? lsi * 0.5 : 0) : 0.05;
    const corrosionRisk = rsi > 7.5 ? 'high' : rsi > 6.8 ? 'moderate' : 'low';
    const lithiumExtraction = (totalBrineFlowKgS * 3600 * 24 * (t.chemistry.lithiumLi / 1000000)) * 0.85; // kg/day with 85% DLE recovery

    // Increment fouling based on scaling rate over time
    const foulingIncrement = (scalingRate / 365) * 0.001 * speed;
    const updatedHeatExchangers: HeatExchangerModel[] = t.heatExchangers.map(hx => {
      const newFouling = Math.min(0.65, hx.foulingFactor + foulingIncrement);
      const actualUA = hx.nominalUa * (1 - newFouling);
      
      let hotIn = headerT;
      let hotOut = 75.0;
      let coldIn = 35.0;
      let coldOut = t.workingFluid.criticalTemperature * 0.75;
      const coldFlow = (totalBrineFlowKgS * 1.15) * (actualUA / hx.nominalUa);

      if (hx.type === 'preheater') {
        hotIn = 110.0;
        hotOut = 70.0;
        coldIn = 32.0;
        coldOut = 95.0;
      } else if (hx.type === 'vaporizer') {
        hotIn = headerT;
        hotOut = 108.0;
        coldIn = 95.0;
        coldOut = Math.min(t.workingFluid.criticalTemperature - 15, headerT - 12);
      } else if (hx.type === 'district_hx') {
        hotIn = 85.0;
        hotOut = 45.0;
        coldIn = t.districtHeating.returnTemperature;
        coldOut = t.districtHeating.supplyTemperature;
      }

      const lmtd = HeatTransferSolver.calculateLMTD(hotIn, hotOut, coldIn, coldOut);
      const duty = HeatTransferSolver.calculateHeatDuty(actualUA, lmtd);

      return {
        ...hx,
        foulingFactor: Number(newFouling.toFixed(4)),
        ua: Number(actualUA.toFixed(1)),
        hotSideInletTemp: Number(hotIn.toFixed(1)),
        hotSideOutletTemp: Number(hotOut.toFixed(1)),
        coldSideInletTemp: Number(coldIn.toFixed(1)),
        coldSideOutletTemp: Number(coldOut.toFixed(1)),
        hotSideFlow: Number(sepBrineFlow.toFixed(1)),
        coldSideFlow: Number(coldFlow.toFixed(1)),
        lmtd: Number(lmtd.toFixed(1)),
        heatDuty: Number(duty.toFixed(2)),
      };
    });

    // 5. Binary ORC Cycle / Turbine / Generator Solver
    const vapHX = updatedHeatExchangers.find(h => h.type === 'vaporizer') || updatedHeatExchangers[0];
    const preHX = updatedHeatExchangers.find(h => h.type === 'preheater') || updatedHeatExchangers[0];
    const totalORCHexDutyMWth = (vapHX.heatDuty + preHX.heatDuty);

    // Organic Rankine Cycle efficiency (Carnot * 0.55 typical ORC second law efficiency)
    const tHotK = (vapHX.coldSideOutletTemp + 273.15);
    const tColdK = (t.condenser.condensingTemperature + 273.15);
    const carnotEff = 1 - (tColdK / Math.max(tColdK + 10, tHotK));
    const orcThermalEff = Math.max(0.05, carnotEff * 0.58); // typically 11% - 16% for geothermal ORC

    const grossShaftPowerMW = totalORCHexDutyMWth * orcThermalEff;
    const isTurbineTripped = t.grid.dispatchMode === 'curtailment' && t.grid.curtailmentPercent >= 100;
    const actualTurbineMW = isTurbineTripped ? 0 : grossShaftPowerMW;
    const grossElectricalMW = actualTurbineMW * t.generator.efficiency;

    // Parasitic loads: Feed pumps + Condenser cooling fans + Well ESPs
    const espParasiticMW = updatedWells.reduce((sum, w) => sum + (w.pumpPower || 0), 0) / 1000;
    const condenserParasiticMW = (t.condenser.parasiticFanPower + t.condenser.parasiticPumpPower) / 1000;
    const plantAuxMW = 0.45 + (totalBrineFlowKgS / 200) * 0.35 + espParasiticMW + condenserParasiticMW;
    const netElectricalMW = Math.max(0, grossElectricalMW - plantAuxMW);

    // 6. District Heating Cogeneration
    let districtHeatSupplied = 0;
    if (t.districtHeating.active) {
      const distHX = updatedHeatExchangers.find(h => h.type === 'district_hx');
      districtHeatSupplied = Math.min(t.districtHeating.thermalDemandMWth, distHX ? distHX.heatDuty : 12.5);
    }

    // 7. Grid Dispatch & Substation
    const exportMW = t.grid.dispatchMode === 'curtailment' 
      ? netElectricalMW * (1 - t.grid.curtailmentPercent / 100) 
      : t.grid.dispatchMode === 'islanding' ? Math.min(netElectricalMW, 5.0) : netElectricalMW;

    // 8. Induced Seismicity (Shapiro Pore Pressure Diffusion in EGS)
    let updatedEvents = [...t.seismicity.events];
    let maxMw = t.seismicity.maxMagnitudePast24h;
    const injWell = updatedWells.find(w => w.role === 'injection' && w.status === 'active');
    const injectionP = injWell ? injWell.bottomholePressure : 150;
    const excessP = Math.max(0, injectionP - 220); // critical overpressure threshold

    if (t.architecture === 'egs' && excessP > 5 && Math.random() < 0.35) {
      // Synthetic microseismic event nucleation
      const rFront = Math.sqrt(4 * Math.PI * t.seismicity.hydraulicDiffusivityM2s * (this.simulationTickCount * 60));
      const evX = 350 + (Math.random() - 0.5) * Math.min(800, rFront);
      const evY = 550 + (Math.random() - 0.5) * Math.min(800, rFront);
      const evZ = 3800 + (Math.random() - 0.5) * 400;
      
      // Gutenberg-Richter magnitude sampling
      const u = Math.random();
      const mw = Number((-1.2 - Math.log10(1 - u * 0.98) / t.seismicity.bValue + (excessP / 50) * 0.6).toFixed(2));
      
      const newEvent: MicroseismicEvent = {
        id: `EV-${now}-${Math.floor(Math.random() * 1000)}`,
        timestamp: now,
        x: Math.round(evX),
        y: Math.round(evY),
        z: Math.round(evZ),
        magnitude: mw,
        sourceRadius: Math.round(Math.pow(10, (mw + 1.5) / 3) * 8),
        stressDropMPa: Number((1.5 + Math.random() * 2.5).toFixed(2)),
        nearestWellId: injWell?.id || 'INJ-01',
        distanceToFaultM: Math.round(120 + Math.random() * 200),
      };
      updatedEvents = [newEvent, ...updatedEvents.slice(0, 150)];
      maxMw = Math.max(maxMw, mw);
    }

    const trafficLight: 'green' | 'amber' | 'red' = 
      maxMw >= t.seismicity.redThresholdMw ? 'red' :
      maxMw >= t.seismicity.amberThresholdMw ? 'amber' : 'green';

    // 9. Mass, Energy, & Water Balances Check
    const thermalIn = totalThermalPowerMWth;
    const condRejectionMWth = totalORCHexDutyMWth - actualTurbineMW;
    const thermalLosses = thermalIn * 0.035;
    const accountedEnergy = grossElectricalMW + districtHeatSupplied + condRejectionMWth + thermalLosses;
    const energyDiscrepancy = thermalIn > 0 ? (Math.abs(thermalIn - accountedEnergy) / thermalIn) * 100 : 0;
    
    const reinjectionTotalKgS = updatedWells.filter(w => w.role === 'injection' && w.status === 'active').reduce((s, w) => s + w.flowRate, 0);
    const waterLoss = totalBrineFlowKgS * 0.015;
    const waterDiscrepancy = totalBrineFlowKgS > 0 ? (Math.abs(totalBrineFlowKgS - (reinjectionTotalKgS + waterLoss)) / totalBrineFlowKgS) * 100 : 0;

    // 10. Sensor Telemetry Bus & Residuals
    const telemetryBus: SensorTelemetryPacket[] = [
      {
        sensorId: 'TT-WELL-P01-BHP',
        tag: 'P-01 Bottomhole Temp',
        unit: '°C',
        observedValue: Number((currentResTemp + (Math.random() - 0.5) * 0.4).toFixed(1)),
        predictedValue: Number(currentResTemp.toFixed(1)),
        residual: Number(((Math.random() - 0.5) * 0.4).toFixed(2)),
        timestamp: now,
        quality: 'GOOD',
      },
      {
        sensorId: 'PT-HDR-PROD',
        tag: 'Production Header Pressure',
        unit: 'bar',
        observedValue: Number((headerP + (Math.random() - 0.5) * 0.1).toFixed(2)),
        predictedValue: Number(headerP.toFixed(2)),
        residual: Number(((Math.random() - 0.5) * 0.1).toFixed(2)),
        timestamp: now,
        quality: 'GOOD',
      },
      {
        sensorId: 'FT-BRINE-TOTAL',
        tag: 'Total Geothermal Brine Flow',
        unit: 'kg/s',
        observedValue: Number(totalBrineFlowKgS.toFixed(1)),
        predictedValue: Number(totalBrineFlowKgS.toFixed(1)),
        residual: 0.0,
        timestamp: now,
        quality: 'GOOD',
      },
      {
        sensorId: 'WT-TURB-GEN',
        tag: 'Gross Generator Power',
        unit: 'MWe',
        observedValue: Number((grossElectricalMW + (Math.random() - 0.5) * 0.05).toFixed(2)),
        predictedValue: Number(grossElectricalMW.toFixed(2)),
        residual: Number(((Math.random() - 0.5) * 0.05).toFixed(2)),
        timestamp: now,
        quality: 'GOOD',
      },
      {
        sensorId: 'QT-DIST-HEAT',
        tag: 'District Heat Export',
        unit: 'MWth',
        observedValue: Number(districtHeatSupplied.toFixed(2)),
        predictedValue: Number(districtHeatSupplied.toFixed(2)),
        residual: 0.0,
        timestamp: now,
        quality: 'GOOD',
      },
      {
        sensorId: 'ST-SILICA-SSI',
        tag: 'Amorphous Silica Saturation Index',
        unit: 'SSI',
        observedValue: Number(silicaSSI.toFixed(2)),
        predictedValue: Number(silicaSSI.toFixed(2)),
        residual: 0.0,
        timestamp: now,
        quality: silicaSSI > 1.2 ? 'WARNING' : 'GOOD',
      },
    ];

    // 11. Maintenance Health Status Update (Causal degradation)
    const updatedMaintenance = t.maintenance.map(item => {
      let wear = item.foulingOrWearPercent;
      let health = item.healthIndex;
      let anomaly = item.recentAnomaly;
      let status = item.status;

      if (item.category === 'heat_exchanger') {
        wear = Math.round(vapHX.foulingFactor * 100);
        health = Math.max(10, 100 - wear * 1.5);
        if (wear > 35) {
          status = 'warning';
          anomaly = `Silica & calcite scaling detected. Overall UA degraded to ${vapHX.ua} kW/K (-${wear}%).`;
        }
      } else if (item.category === 'production_well') {
        const pWell = updatedWells.find(w => w.id === item.id);
        if (pWell && pWell.status === 'failed') {
          health = 0;
          status = 'critical';
          anomaly = 'ESP casing short-circuit / mechanical shear detected.';
        }
      }
      return {
        ...item,
        operatingHours: item.operatingHours + (1 * speed) / 3600,
        foulingOrWearPercent: wear,
        healthIndex: health,
        status: status as 'nominal' | 'warning' | 'critical' | 'under_maintenance',
        recentAnomaly: anomaly,
      };
    });

    // 12. Economics Calculation
    const annualHours = 8760 * 0.94; // 94% capacity factor
    const annualMWh = netElectricalMW * annualHours;
    const annualMWhth = districtHeatSupplied * annualHours;
    const powerRev = (annualMWh * t.economics.powerPPAUSDPerMWh) / 1e6;
    const heatRev = (annualMWhth * t.economics.heatPriceUSDPerMWhth) / 1e6;
    const lithiumRev = (lithiumExtraction * 365 * t.economics.lithiumPriceUSDPerKg) / 1e6;
    const totalRev = powerRev + heatRev + lithiumRev;
    const totalOpex = t.economics.fixedOpexMPerYear + (annualMWh * t.economics.variableOpexPerMWh) / 1e6;
    const netCashFlow = totalRev - totalOpex;
    
    // Simple 30-yr NPV approximation: CF * PVIFA(r, 30) - CAPEX
    const r = t.economics.discountRatePercent / 100;
    const pvifa = (1 - Math.pow(1 + r, -30)) / r;
    const npv = netCashFlow * pvifa - t.economics.totalCapexM;
    const lcoe = (t.economics.totalCapexM * 1e6 / 20 + totalOpex * 1e6) / Math.max(1, annualMWh);

    // Commit updated twin state
    const updatedTwin: GeothermalDigitalTwin = {
      ...t,
      simulatedTimestamp: now,
      reservoir: {
        ...t.reservoir,
        cells: updatedCells,
        averageTemperature: Number(currentResTemp.toFixed(1)),
        averagePressure: Number(currentResPressure.toFixed(1)),
        activeThermalSweepVolumeM3: Math.round(sweepVolume),
        thermalBreakthroughFrontDistanceM: Math.round(coldFrontDist),
        estimatedBreakthroughYears: Number(breakthroughYears.toFixed(1)),
      },
      wells: updatedWells,
      gatheringSystem: {
        ...t.gatheringSystem,
        productionHeaderPressureBar: Number(headerP.toFixed(2)),
        productionHeaderTempC: Number(headerT.toFixed(1)),
      },
      heatExchangers: updatedHeatExchangers,
      turbine: {
        ...t.turbine,
        massFlow: Number(vapHX.coldSideFlow.toFixed(1)),
        shaftPower: Number(actualTurbineMW.toFixed(2)),
        inletTemperature: Number(vapHX.coldSideOutletTemp.toFixed(1)),
      },
      generator: {
        ...t.generator,
        mechanicalPowerInput: Number(actualTurbineMW.toFixed(2)),
        electricalPowerOutput: Number(grossElectricalMW.toFixed(2)),
      },
      districtHeating: {
        ...t.districtHeating,
        thermalSuppliedMWth: Number(districtHeatSupplied.toFixed(2)),
      },
      grid: {
        ...t.grid,
        exportActivePowerMW: Number(exportMW.toFixed(2)),
      },
      chemistry: {
        ...t.chemistry,
        silicaSaturationIndex: Number(silicaSSI.toFixed(2)),
        calciteSaturationIndex: Number(lsi.toFixed(2)),
        ryznarStabilityIndex: Number(rsi.toFixed(2)),
        scalingDepositionRateMmYr: Number(scalingRate.toFixed(2)),
        corrosionRiskIndicator: corrosionRisk,
        lithiumExtractionPotentialKgDay: Number(lithiumExtraction.toFixed(1)),
      },
      seismicity: {
        ...t.seismicity,
        trafficLightStatus: trafficLight,
        maxMagnitudePast24h: Number(maxMw.toFixed(2)),
        events: updatedEvents,
        eventCountPast24h: updatedEvents.length,
      },
      maintenance: updatedMaintenance,
      balances: {
        thermalEnergyInMWth: Number(thermalIn.toFixed(2)),
        grossElectricalPowerMW: Number(grossElectricalMW.toFixed(2)),
        netElectricalPowerMW: Number(netElectricalMW.toFixed(2)),
        districtHeatDeliveredMWth: Number(districtHeatSupplied.toFixed(2)),
        condenserHeatRejectionMWth: Number(condRejectionMWth.toFixed(2)),
        parasiticAuxiliaryPowerMW: Number(plantAuxMW.toFixed(2)),
        thermalLossesMWth: Number(thermalLosses.toFixed(2)),
        energyBalanceDiscrepancyPercent: Number(energyDiscrepancy.toFixed(2)),
        brineProductionTotalKgS: Number(totalBrineFlowKgS.toFixed(1)),
        brineReinjectionTotalKgS: Number(reinjectionTotalKgS.toFixed(1)),
        steamProductionTotalKgS: Number(sepSteamFlow.toFixed(1)),
        waterLossesKgS: Number(waterLoss.toFixed(1)),
        waterBalanceDiscrepancyPercent: Number(waterDiscrepancy.toFixed(2)),
        reservoirMassChangeKgS: Number((reinjectionTotalKgS - totalBrineFlowKgS).toFixed(1)),
      },
      economics: {
        ...t.economics,
        annualRevenueMillionUSD: Number(totalRev.toFixed(2)),
        annualElectricityMWh: Math.round(annualMWh),
        annualHeatMWhth: Math.round(annualMWhth),
        npvMillionUSD: Number(npv.toFixed(1)),
        lcoeUSDPerMWh: Number(lcoe.toFixed(2)),
      },
      telemetryBus,
    };

    this.twin.set(updatedTwin);

    // Telemetry log buffer
    this.telemetryHistory.update(hist => [
      ...hist.slice(-59),
      {
        timestamp: now,
        netPowerMW: Number(netElectricalMW.toFixed(2)),
        reservoirTempC: Number(currentResTemp.toFixed(1)),
        injectionPressureBar: Number(injectionP.toFixed(1)),
        silicaSSI: Number(silicaSSI.toFixed(2)),
        seismicityCount: updatedEvents.length,
      },
    ]);
  }

  /**
   * Generates initial baseline synthetic demonstration field CORNWALL-DEMO-01
   */
  private createInitialDigitalTwin(): GeothermalDigitalTwin {
    // 3D Geological Strata
    const layers = [
      {
        id: 'L1',
        name: 'Surface & Quaternary Alluvium',
        depthStart: 0,
        depthEnd: 150,
        rockType: {
          name: 'Alluvium & Mudstone',
          color: '#64748b',
          density: 2100,
          porosity: 0.28,
          permeability: 120,
          thermalConductivity: 1.8,
          specificHeat: 920,
          matrixCompressibility: 8e-5,
        },
        description: 'Unconsolidated sediments and weathered mudstone cap',
        faultPresence: false,
      },
      {
        id: 'L2',
        name: 'Killas Sedimentary Slate (Caprock)',
        depthStart: 150,
        depthEnd: 1200,
        rockType: {
          name: 'Metasedimentary Slate',
          color: '#475569',
          density: 2650,
          porosity: 0.04,
          permeability: 0.01,
          thermalConductivity: 2.9,
          specificHeat: 840,
          matrixCompressibility: 2e-5,
        },
        description: 'Impermeable thermal insulator and caprock seal',
        faultPresence: true,
      },
      {
        id: 'L3',
        name: 'Upper Cornubian Granite',
        depthStart: 1200,
        depthEnd: 3200,
        rockType: {
          name: 'Biotite Granite',
          color: '#e2e8f0',
          density: 2620,
          porosity: 0.015,
          permeability: 0.05,
          thermalConductivity: 3.4,
          specificHeat: 880,
          matrixCompressibility: 1.2e-5,
        },
        description: 'High heat-producing radioactive granite batholith',
        faultPresence: true,
      },
      {
        id: 'L4',
        name: 'Deep Geothermal Reservoir (Porthtowan Fault Zone)',
        depthStart: 3200,
        depthEnd: 5200,
        rockType: {
          name: 'Hydrothermally Altered Fractured Granite',
          color: '#f59e0b',
          density: 2580,
          porosity: 0.075,
          permeability: 18.5,
          thermalConductivity: 3.6,
          specificHeat: 910,
          matrixCompressibility: 3.5e-5,
        },
        description: 'Permeable target geothermal zone with high heat flow (125 mW/m²)',
        faultPresence: true,
      },
    ];

    // Generate 3D Reservoir Grid (8 x 8 x 5 = 320 cells)
    const gridCells: ReservoirGridCell[] = [];
    const nx = 8;
    const ny = 8;
    const nz = 5;
    const dx = 250;
    const dy = 250;
    const dz = 400;

    for (let k = 0; k < nz; k++) {
      const zDepth = 3200 + k * dz + dz / 2;
      const tBase = 185 + (k * dz / 1000) * 35; // 35 °C/km geothermal gradient
      const pBase = 320 + (k * dz * 9.81 * 1000 / 100000);
      for (let j = 0; j < ny; j++) {
        for (let i = 0; i < nx; i++) {
          gridCells.push({
            x: i,
            y: j,
            z: k,
            posX: i * dx + dx / 2,
            posY: j * dy + dy / 2,
            posZ: zDepth,
            temperature: tBase,
            initialTemperature: tBase,
            pressure: pBase,
            initialPressure: pBase,
            enthalpy: WaterSteamPhysics.saturatedLiquidEnthalpy(tBase),
            permeability: 12.0 + Math.random() * 15.0,
            porosity: 0.06 + Math.random() * 0.03,
            fluidMass: 1.2e7,
            fluidSaturation: 1.0,
            vaporMassFraction: 0.0,
            tracerConcentration: 0.0,
          });
        }
      }
    }

    // Discrete Fracture Network (DFN)
    const fractures: DiscreteFracture[] = [
      {
        id: 'DFN-01',
        strike: 310,
        dip: 78,
        center: [500, 600, 4200],
        length: 1200,
        height: 600,
        aperture: 2.8,
        permeability: 850,
        hydraulicConductivity: 0.0045,
        apertureCompliance: 0.08,
        activated: true,
      },
      {
        id: 'DFN-02',
        strike: 315,
        dip: 82,
        center: [900, 1100, 4500],
        length: 1500,
        height: 750,
        aperture: 3.4,
        permeability: 1200,
        hydraulicConductivity: 0.0072,
        apertureCompliance: 0.09,
        activated: true,
      },
      {
        id: 'DFN-03',
        strike: 130,
        dip: 72,
        center: [1400, 800, 4800],
        length: 900,
        height: 500,
        aperture: 1.6,
        permeability: 420,
        hydraulicConductivity: 0.0028,
        apertureCompliance: 0.06,
        activated: false,
      },
    ];

    // Wells Setup (4 Production + 2 Injection)
    const wells: WellModel[] = [
      {
        id: 'P-01',
        name: 'Production Well P-01 (UD-1)',
        role: 'production',
        wellType: 'deviated',
        depth: 5050,
        tvd: 4850,
        casingDiameter: 244.5,
        tubingDiameter: 177.8,
        roughness: 0.045,
        status: 'active',
        chokeOpening: 95,
        flowRate: 65.0,
        targetFlowRate: 65.0,
        wellheadPressure: 8.8,
        bottomholePressure: 315.0,
        wellheadTemperature: 198.5,
        bottomholeTemperature: 215.0,
        wellheadEnthalpy: 845.0,
        steamQuality: 0.0,
        productivityIndex: 3.4,
        skinFactor: -1.2,
        hasPump: true,
        pumpType: 'esp',
        pumpSettingDepth: 750,
        pumpRpm: 3500,
        pumpHead: 480,
        pumpPower: 420,
        pumpEfficiency: 0.74,
        perforations: [{ topDepth: 4500, bottomDepth: 5050, productivityMultiplier: 1.0 }],
        trajectory: this.generateWellTrajectory(5050, 4850, 32, 315, 300, 450),
        dtsProfile: this.generateDTS(5050, 215.0),
      },
      {
        id: 'P-02',
        name: 'Production Well P-02 (UD-2)',
        role: 'production',
        wellType: 'deviated',
        depth: 4850,
        tvd: 4620,
        casingDiameter: 244.5,
        tubingDiameter: 177.8,
        roughness: 0.045,
        status: 'active',
        chokeOpening: 90,
        flowRate: 58.0,
        targetFlowRate: 60.0,
        wellheadPressure: 8.4,
        bottomholePressure: 308.0,
        wellheadTemperature: 194.2,
        bottomholeTemperature: 212.0,
        wellheadEnthalpy: 825.0,
        steamQuality: 0.0,
        productivityIndex: 3.1,
        skinFactor: -0.8,
        hasPump: true,
        pumpType: 'esp',
        pumpSettingDepth: 700,
        pumpRpm: 3400,
        pumpHead: 450,
        pumpPower: 380,
        pumpEfficiency: 0.73,
        perforations: [{ topDepth: 4300, bottomDepth: 4850, productivityMultiplier: 1.0 }],
        trajectory: this.generateWellTrajectory(4850, 4620, 28, 325, 600, 750),
        dtsProfile: this.generateDTS(4850, 212.0),
      },
      {
        id: 'P-03',
        name: 'Production Well P-03 (UD-3)',
        role: 'production',
        wellType: 'multilateral',
        depth: 5200,
        tvd: 4950,
        casingDiameter: 244.5,
        tubingDiameter: 177.8,
        roughness: 0.045,
        status: 'active',
        chokeOpening: 85,
        flowRate: 52.0,
        targetFlowRate: 55.0,
        wellheadPressure: 8.1,
        bottomholePressure: 312.0,
        wellheadTemperature: 196.0,
        bottomholeTemperature: 216.0,
        wellheadEnthalpy: 835.0,
        steamQuality: 0.0,
        productivityIndex: 2.9,
        skinFactor: 0.2,
        hasPump: true,
        pumpType: 'esp',
        pumpSettingDepth: 800,
        pumpRpm: 3300,
        pumpHead: 460,
        pumpPower: 360,
        pumpEfficiency: 0.72,
        perforations: [{ topDepth: 4600, bottomDepth: 5200, productivityMultiplier: 1.2 }],
        trajectory: this.generateWellTrajectory(5200, 4950, 36, 135, 1200, 650),
        dtsProfile: this.generateDTS(5200, 216.0),
      },
      {
        id: 'P-04',
        name: 'Production Well P-04 (UD-4)',
        role: 'production',
        wellType: 'vertical',
        depth: 4600,
        tvd: 4600,
        casingDiameter: 244.5,
        tubingDiameter: 177.8,
        roughness: 0.045,
        status: 'active',
        chokeOpening: 80,
        flowRate: 45.0,
        targetFlowRate: 50.0,
        wellheadPressure: 7.9,
        bottomholePressure: 302.0,
        wellheadTemperature: 191.5,
        bottomholeTemperature: 209.0,
        wellheadEnthalpy: 815.0,
        steamQuality: 0.0,
        productivityIndex: 2.6,
        skinFactor: 0.5,
        hasPump: true,
        pumpType: 'esp',
        pumpSettingDepth: 650,
        pumpRpm: 3200,
        pumpHead: 430,
        pumpPower: 310,
        pumpEfficiency: 0.71,
        perforations: [{ topDepth: 4100, bottomDepth: 4600, productivityMultiplier: 1.0 }],
        trajectory: this.generateWellTrajectory(4600, 4600, 0, 0, 1600, 1200),
        dtsProfile: this.generateDTS(4600, 209.0),
      },
      {
        id: 'INJ-01',
        name: 'Injection Well INJ-01 (IN-1)',
        role: 'injection',
        wellType: 'deviated',
        depth: 4500,
        tvd: 4200,
        casingDiameter: 244.5,
        tubingDiameter: 177.8,
        roughness: 0.045,
        status: 'active',
        chokeOpening: 95,
        flowRate: 110.0,
        targetFlowRate: 110.0,
        wellheadPressure: 28.5,
        bottomholePressure: 395.0,
        wellheadTemperature: 65.0,
        bottomholeTemperature: 75.0,
        wellheadEnthalpy: 275.0,
        steamQuality: 0.0,
        productivityIndex: 4.2, // Injectivity index
        skinFactor: -0.5,
        hasPump: false,
        perforations: [{ topDepth: 3800, bottomDepth: 4500, productivityMultiplier: 1.0 }],
        trajectory: this.generateWellTrajectory(4500, 4200, 25, 290, 400, 600),
        dtsProfile: this.generateDTS(4500, 75.0),
      },
      {
        id: 'INJ-02',
        name: 'Injection Well INJ-02 (IN-2)',
        role: 'injection',
        wellType: 'deviated',
        depth: 4700,
        tvd: 4400,
        casingDiameter: 244.5,
        tubingDiameter: 177.8,
        roughness: 0.045,
        status: 'active',
        chokeOpening: 90,
        flowRate: 105.0,
        targetFlowRate: 110.0,
        wellheadPressure: 26.8,
        bottomholePressure: 388.0,
        wellheadTemperature: 65.0,
        bottomholeTemperature: 78.0,
        wellheadEnthalpy: 275.0,
        steamQuality: 0.0,
        productivityIndex: 3.9,
        skinFactor: 0.0,
        hasPump: false,
        perforations: [{ topDepth: 4000, bottomDepth: 4700, productivityMultiplier: 1.0 }],
        trajectory: this.generateWellTrajectory(4700, 4400, 22, 305, 800, 950),
        dtsProfile: this.generateDTS(4700, 78.0),
      },
    ];

    // Heat Exchangers
    const heatExchangers: HeatExchangerModel[] = [
      {
        id: 'HEX-PRE-01',
        name: 'ORC Brine Preheater (Shell & Tube)',
        type: 'preheater',
        nominalUa: 1850,
        ua: 1850,
        foulingFactor: 0.0,
        hotSideInletTemp: 110.0,
        hotSideOutletTemp: 70.0,
        hotSideFlow: 220.0,
        coldSideInletTemp: 32.0,
        coldSideOutletTemp: 95.0,
        coldSideFlow: 250.0,
        lmtd: 23.4,
        heatDuty: 43.3,
        effectiveness: 0.88,
      },
      {
        id: 'HEX-VAP-01',
        name: 'ORC Brine Vaporizer (Kettle Evaporator)',
        type: 'vaporizer',
        nominalUa: 2400,
        ua: 2400,
        foulingFactor: 0.0,
        hotSideInletTemp: 195.0,
        hotSideOutletTemp: 110.0,
        hotSideFlow: 220.0,
        coldSideInletTemp: 95.0,
        coldSideOutletTemp: 142.0,
        coldSideFlow: 250.0,
        lmtd: 31.8,
        heatDuty: 76.3,
        effectiveness: 0.91,
      },
      {
        id: 'HEX-DIST-01',
        name: 'District Heating Heat Exchanger (Plate Pack)',
        type: 'district_hx',
        nominalUa: 1200,
        ua: 1200,
        foulingFactor: 0.0,
        hotSideInletTemp: 85.0,
        hotSideOutletTemp: 45.0,
        hotSideFlow: 80.0,
        coldSideInletTemp: 45.0,
        coldSideOutletTemp: 82.0,
        coldSideFlow: 85.0,
        lmtd: 12.5,
        heatDuty: 15.0,
        effectiveness: 0.92,
      },
    ];

    // 30-Year Production Forecast Data Points
    const forecast: ProductionForecastPoint[] = [];
    for (let yr = 1; yr <= 30; yr++) {
      const tRes = 215.0 - (yr <= 8 ? yr * 0.4 : 3.2 + (yr - 8) * 1.4);
      const pNet = Math.max(8.0, 24.5 - (yr <= 8 ? yr * 0.15 : 1.2 + (yr - 8) * 0.55));
      forecast.push({
        year: yr,
        reservoirAvgTempC: Number(tRes.toFixed(1)),
        reservoirAvgPressureBar: Number((310 - yr * 1.8).toFixed(1)),
        productionFlowKgS: Number((220 - yr * 0.9).toFixed(1)),
        productionTempC: Number((tRes - 8.5).toFixed(1)),
        grossPowerMW: Number((pNet + 2.8).toFixed(2)),
        netPowerMW: Number(pNet.toFixed(2)),
        districtHeatMWth: 15.0,
        cumulativeEnergyGWh: Math.round(yr * pNet * 8760 * 0.94 / 1000),
        cumRevenueM: Number((yr * pNet * 8760 * 0.94 * 85 / 1e6).toFixed(1)),
        p10NetPowerMW: Number((pNet * 1.12).toFixed(2)),
        p90NetPowerMW: Number((pNet * 0.86).toFixed(2)),
      });
    }

    // Monte Carlo Distribution Results (10,000 runs summary)
    const monteCarlo: MonteCarloResult = {
      p10PowerMW: 26.8,
      p50PowerMW: 24.5,
      p90PowerMW: 20.8,
      p10LifetimeYears: 42,
      p50LifetimeYears: 32,
      p90LifetimeYears: 22,
      p10ThermalBreakthroughYear: 28,
      p50ThermalBreakthroughYear: 22,
      p90ThermalBreakthroughYear: 16,
      runsCount: 10000,
      samples: [
        { permeability: 14.2, thermalCond: 3.6, breakthroughYr: 23, year10MW: 24.8, lcoe: 68.2 },
        { permeability: 18.5, thermalCond: 3.8, breakthroughYr: 26, year10MW: 25.4, lcoe: 64.8 },
        { permeability: 8.4, thermalCond: 3.2, breakthroughYr: 18, year10MW: 21.2, lcoe: 79.5 },
        { permeability: 22.1, thermalCond: 4.1, breakthroughYr: 31, year10MW: 27.1, lcoe: 61.2 },
        { permeability: 11.6, thermalCond: 3.5, breakthroughYr: 20, year10MW: 23.0, lcoe: 72.4 },
      ],
    };

    return {
      id: 'DT-CORNWALL-001',
      name: 'Cornwall EGS & Hydrothermal Hybrid Field',
      fieldCode: 'CORNWALL-DEMO-01',
      version: 'v14.4.2 (Coupled EGS/ORC)',
      stateMode: 'current',
      architecture: 'hybrid_chp',
      workingFluid: WORKING_FLUIDS['Isobutane'],
      simulatedTimestamp: Date.now(),
      simulationSpeedMultiplier: 1,
      isSimulating: true,
      geology: {
        layers,
        faultDipDeg: 78,
        faultStrikeDeg: 315,
        regionalStressMaxMPa: 85.0,
        regionalStressMinMPa: 48.0,
      },
      reservoir: {
        gridNx: nx,
        gridNy: ny,
        gridNz: nz,
        dx,
        dy,
        dz,
        cells: gridCells,
        averageTemperature: 215.0,
        averagePressure: 310.0,
        activeThermalSweepVolumeM3: 4.8e7,
        thermalBreakthroughFrontDistanceM: 680,
        estimatedBreakthroughYears: 24.5,
      },
      fractureNetwork: {
        fractures,
        totalFractureSurfaceAreaM2: 3.6e6,
        averageConductivityM2: 0.0052,
        dominantFlowPathWellIds: ['INJ-01', 'P-01'],
      },
      wells,
      gatheringSystem: {
        productionHeaderPressureBar: 8.8,
        productionHeaderTempC: 195.0,
        reinjectionHeaderPressureBar: 28.0,
        reinjectionHeaderTempC: 65.0,
        pipelineLossPressureBar: 0.45,
        pipelineThermalLossC: 1.2,
      },
      separator: {
        id: 'SEP-01',
        operatingPressure: 8.5,
        operatingTemperature: 195.0,
        inletFlow: 220.0,
        inletEnthalpy: 830.0,
        steamFlow: 0.0,
        brineFlow: 220.0,
        steamQuality: 0.0,
        efficiency: 99.5,
      },
      heatExchangers,
      turbine: {
        id: 'TURB-ORC-01',
        inletPressure: 32.5,
        inletTemperature: 138.0,
        inletEnthalpy: 680.0,
        outletPressure: 4.8,
        outletTemperature: 48.0,
        outletEnthalpy: 575.0,
        massFlow: 250.0,
        isentropicEfficiency: 0.88,
        mechanicalEfficiency: 0.98,
        shaftPower: 26.25,
        rpm: 3000,
        vibrationMmS: 1.4,
      },
      generator: {
        id: 'GEN-01',
        mechanicalPowerInput: 26.25,
        electricalPowerOutput: 25.46,
        efficiency: 0.97,
        voltage: 11.0,
        frequency: 50.0,
        powerFactor: 0.92,
        reactivePower: 8.4,
        temperature: 68.0,
      },
      condenser: {
        id: 'ACC-01',
        coolingType: 'air_cooled_acc',
        ambientTemperature: 14.5,
        ambientRelativeHumidity: 65,
        condenserPressure: 4.8,
        condensingTemperature: 35.0,
        coolingWaterFlow: 1200,
        heatRejectionDuty: 93.4,
        parasiticFanPower: 650,
        parasiticPumpPower: 220,
      },
      districtHeating: {
        active: true,
        thermalDemandMWth: 15.0,
        thermalSuppliedMWth: 15.0,
        supplyTemperature: 82.0,
        returnTemperature: 45.0,
        waterCirculationFlow: 96.5,
        networkLengthKm: 18.5,
        buildingsConnected: 3400,
        thermalStorageState: {
          type: 'stratified_tank',
          capacityMWh: 120,
          currentStoredMWh: 88,
          chargeRateMWth: 4.5,
          dischargeRateMWth: 6.0,
          lossRatePercentPerDay: 1.8,
        },
      },
      grid: {
        dispatchMode: 'baseload',
        substationVoltageKV: 132.0,
        frequencyHz: 50.0,
        exportActivePowerMW: 23.99,
        exportReactivePowerMVAr: 7.8,
        curtailmentPercent: 0,
        gridDemandMW: 24.0,
        powerFactor: 0.92,
        transmissionLossMW: 0.35,
        interconnectionStatus: 'synchronized',
      },
      chemistry: {
        ph: 6.2,
        tds: 32500,
        silicaSiO2: 440,
        calciumCa: 1850,
        magnesiumMg: 120,
        sodiumNa: 9400,
        potassiumK: 1280,
        lithiumLi: 220, // 220 mg/L high value Cornwall brine!
        chlorideCl: 18900,
        bicarbonateHCO3: 180,
        sulfateSO4: 420,
        dissolvedCO2: 120,
        h2s: 1.5,
        silicaSaturationIndex: 0.88,
        calciteSaturationIndex: 0.12,
        ryznarStabilityIndex: 6.4,
        scalingDepositionRateMmYr: 0.12,
        corrosionRiskIndicator: 'low',
        lithiumExtractionPotentialKgDay: 3550,
      },
      seismicity: {
        trafficLightStatus: 'green',
        maxMagnitudePast24h: 0.22,
        eventCountPast24h: 18,
        bValue: 0.98,
        aValue: 3.4,
        porePressurePerturbationMaxBar: 18.5,
        hydraulicDiffusivityM2s: 0.08,
        injectionPressureLimitBar: 420.0,
        amberThresholdMw: 0.5,
        redThresholdMw: 1.5,
        events: this.generateInitialSeismicEvents(),
      },
      maintenance: [
        {
          id: 'HEX-VAP-01',
          name: 'Brine Vaporizer HEX-VAP-01',
          category: 'heat_exchanger',
          operatingHours: 8450,
          healthIndex: 94,
          foulingOrWearPercent: 6,
          failureProbabilityNext30d: 0.02,
          vibrationLevelMmS: 0.4,
          corrosionWallLossMm: 0.12,
          lastServiceDate: '2026-06-15',
          nextScheduledService: '2027-06-15',
          status: 'nominal',
        },
        {
          id: 'P-01',
          name: 'Production Well P-01 ESP Unit',
          category: 'pump',
          operatingHours: 12800,
          healthIndex: 91,
          foulingOrWearPercent: 9,
          failureProbabilityNext30d: 0.04,
          vibrationLevelMmS: 1.8,
          corrosionWallLossMm: 0.25,
          lastServiceDate: '2026-03-10',
          nextScheduledService: '2027-03-10',
          status: 'nominal',
        },
        {
          id: 'TURB-ORC-01',
          name: 'ORC Radial Inflow Turbine',
          category: 'turbine',
          operatingHours: 16400,
          healthIndex: 96,
          foulingOrWearPercent: 4,
          failureProbabilityNext30d: 0.01,
          vibrationLevelMmS: 1.4,
          corrosionWallLossMm: 0.05,
          lastServiceDate: '2026-01-20',
          nextScheduledService: '2027-01-20',
          status: 'nominal',
        },
        {
          id: 'INJ-01',
          name: 'Injection Well INJ-01 Perforations',
          category: 'injection_well',
          operatingHours: 14200,
          healthIndex: 88,
          foulingOrWearPercent: 12,
          failureProbabilityNext30d: 0.03,
          vibrationLevelMmS: 0.2,
          corrosionWallLossMm: 0.35,
          lastServiceDate: '2026-04-12',
          nextScheduledService: '2026-10-12',
          status: 'nominal',
        },
      ],
      economics: {
        currency: 'USD',
        drillingCapexM: 85.0, // 6 deep wells @ ~$14M each
        surfacePlantCapexM: 48.0,
        gridInterconnectionCapexM: 12.0,
        totalCapexM: 145.0,
        fixedOpexMPerYear: 4.8,
        variableOpexPerMWh: 6.5,
        powerPPAUSDPerMWh: 88.0,
        heatPriceUSDPerMWhth: 38.0,
        lithiumPriceUSDPerKg: 18.0,
        discountRatePercent: 7.5,
        lcoeUSDPerMWh: 68.4,
        npvMillionUSD: 64.8,
        irrPercent: 14.2,
        paybackYears: 6.8,
        annualRevenueMillionUSD: 31.4,
        annualElectricityMWh: 197400,
        annualHeatMWhth: 123500,
      },
      carbon: {
        scope1KgCO2ePerMWh: 4.2, // closed binary ORC has zero non-condensable direct venting
        scope2KgCO2ePerMWh: 0.8,
        scope3KgCO2ePerMWh: 12.5, // steel casing, cement, plant manufacturing life cycle
        totalKgCO2ePerMWh: 17.5,
        avoidedEmissionsTonsPerYear: 78500, // vs gas-fired baseline
      },
      balances: {
        thermalEnergyInMWth: 128.5,
        grossElectricalPowerMW: 25.46,
        netElectricalPowerMW: 23.99,
        districtHeatDeliveredMWth: 15.0,
        condenserHeatRejectionMWth: 85.2,
        parasiticAuxiliaryPowerMW: 1.47,
        thermalLossesMWth: 2.84,
        energyBalanceDiscrepancyPercent: 0.12,
        brineProductionTotalKgS: 220.0,
        brineReinjectionTotalKgS: 215.0,
        steamProductionTotalKgS: 0.0,
        waterLossesKgS: 5.0,
        waterBalanceDiscrepancyPercent: 0.0,
        reservoirMassChangeKgS: -5.0,
      },
      telemetryBus: [],
      dataAssimilation: {
        algorithm: 'EnKF',
        ensembleMembers: 50,
        currentIteration: 14,
        misfitObjective: 0.042,
        assimilatedParameters: [
          { parameter: 'Fracture Permeability', priorMean: 12.0, posteriorMean: 18.5, priorStd: 6.0, posteriorStd: 1.8, unit: 'mD' },
          { parameter: 'Active Thermal Sweep Volume', priorMean: 3.5e7, posteriorMean: 4.8e7, priorStd: 1.2e7, posteriorStd: 3.5e6, unit: 'm³' },
          { parameter: 'Granite Thermal Conductivity', priorMean: 3.1, posteriorMean: 3.6, priorStd: 0.6, posteriorStd: 0.15, unit: 'W/(m·K)' },
          { parameter: 'Injection Well Skin Factor', priorMean: 1.5, posteriorMean: -0.5, priorStd: 1.0, posteriorStd: 0.25, unit: 'dim' },
        ],
        historyMatchErrorReductionPercent: 78.4,
      },
      forecast,
      monteCarlo,
    };
  }

  private generateWellTrajectory(mdMax: number, tvdMax: number, maxInc: number, azimuth: number, endX: number, endY: number) {
    const points = [];
    const steps = 20;
    for (let i = 0; i <= steps; i++) {
      const frac = i / steps;
      const md = mdMax * frac;
      const inc = frac < 0.2 ? 0 : Math.sin((frac - 0.2) / 0.8 * (Math.PI / 2)) * maxInc;
      const tvd = tvdMax * frac;
      const x = frac < 0.2 ? 0 : endX * Math.pow((frac - 0.2) / 0.8, 1.4);
      const y = frac < 0.2 ? 0 : endY * Math.pow((frac - 0.2) / 0.8, 1.4);
      points.push({
        measuredDepth: Math.round(md),
        trueVerticalDepth: Math.round(tvd),
        inclination: Number(inc.toFixed(1)),
        azimuth,
        x: Math.round(x),
        y: Math.round(y),
        temperature: Number((20 + frac * 195).toFixed(1)),
        pressure: Number((1.0 + frac * 310).toFixed(1)),
      });
    }
    return points;
  }

  private generateDTS(depthMax: number, bht: number) {
    const dts = [];
    for (let d = 0; d <= depthMax; d += 250) {
      const frac = d / depthMax;
      const pred = 20 + frac * (bht - 20);
      dts.push({
        depth: d,
        predictedTemp: Number(pred.toFixed(1)),
        observedTemp: Number((pred + (Math.random() - 0.5) * 0.8).toFixed(1)),
        strainMicro: Number((frac * 120 + Math.random() * 5).toFixed(1)),
      });
    }
    return dts;
  }

  private generateInitialSeismicEvents(): MicroseismicEvent[] {
    const events: MicroseismicEvent[] = [];
    const now = Date.now();
    for (let i = 0; i < 35; i++) {
      const timeOffset = Math.random() * 86400 * 1000;
      events.push({
        id: `EV-INIT-${i}`,
        timestamp: now - timeOffset,
        x: Math.round(350 + (Math.random() - 0.5) * 500),
        y: Math.round(550 + (Math.random() - 0.5) * 500),
        z: Math.round(3900 + (Math.random() - 0.5) * 600),
        magnitude: Number((-0.8 + Math.random() * 1.1).toFixed(2)),
        sourceRadius: Math.round(12 + Math.random() * 25),
        stressDropMPa: Number((1.2 + Math.random() * 2.0).toFixed(2)),
        nearestWellId: 'INJ-01',
        distanceToFaultM: Math.round(80 + Math.random() * 150),
      });
    }
    return events.sort((a, b) => b.timestamp - a.timestamp);
  }
}
