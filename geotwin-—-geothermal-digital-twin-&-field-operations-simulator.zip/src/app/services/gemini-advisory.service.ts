import { Injectable, signal } from '@angular/core';
import { GeothermalDigitalTwin } from '../models/geothermal.model';

@Injectable({
  providedIn: 'root',
})
export class GeminiAdvisoryService {
  readonly isAnalyzing = signal<boolean>(false);
  readonly analysisOutput = signal<string>('');
  readonly analysisSource = signal<string>('');
  readonly error = signal<string | null>(null);

  async requestAdvisory(twin: GeothermalDigitalTwin, query?: string): Promise<void> {
    this.isAnalyzing.set(true);
    this.error.set(null);
    try {
      const res = await fetch('/api/geothermal-advisor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fieldData: twin, query }),
      });
      const data = await res.json();
      if (data.success) {
        this.analysisOutput.set(data.analysis);
        this.analysisSource.set(data.source);
      } else {
        this.error.set(data.error || 'Failed to generate advisory');
      }
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Connection error with advisor service';
      this.error.set(msg);
    } finally {
      this.isAnalyzing.set(false);
    }
  }
}
