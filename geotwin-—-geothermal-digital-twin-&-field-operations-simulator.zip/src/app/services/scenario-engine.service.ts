import { Injectable, inject, signal } from '@angular/core';
import { PhysicsEngineService } from './physics-engine.service';

export interface ParetoPoint {
  id: string;
  name: string;
  netPowerMW: number;
  reservoirLifetimeYears: number;
  seismicRiskIndex: number; // 0..10
  productionFlowKgS: number;
  injectionPressureBar: number;
  lcoeUSDPerMWh: number;
  recommended: boolean;
}

@Injectable({
  providedIn: 'root',
})
export class ScenarioEngineService {
  private physics = inject(PhysicsEngineService);

  readonly activeScenarioName = signal<string>('Baseline Nominal State');
  readonly scenarioDescription = signal<string>('Standard balanced hydrothermal/EGS hybrid operation with 4 active production wells and 2 injection wells.');
  
  // Pareto frontier dataset
  readonly paretoPoints = signal<ParetoPoint[]>([
    { id: 'OPT-1', name: 'Maximum Extraction (Aggressive)', netPowerMW: 28.5, reservoirLifetimeYears: 18, seismicRiskIndex: 7.8, productionFlowKgS: 260, injectionPressureBar: 395, lcoeUSDPerMWh: 59.2, recommended: false },
    { id: 'OPT-2', name: 'Balanced Production (Nominal)', netPowerMW: 24.0, reservoirLifetimeYears: 28, seismicRiskIndex: 3.2, productionFlowKgS: 220, injectionPressureBar: 360, lcoeUSDPerMWh: 68.4, recommended: true },
    { id: 'OPT-3', name: 'Conservative Thermal Preservation', netPowerMW: 19.5, reservoirLifetimeYears: 42, seismicRiskIndex: 1.1, productionFlowKgS: 175, injectionPressureBar: 320, lcoeUSDPerMWh: 76.5, recommended: false },
    { id: 'OPT-4', name: 'Low-Seismicity EGS Protocol', netPowerMW: 21.8, reservoirLifetimeYears: 35, seismicRiskIndex: 0.8, productionFlowKgS: 195, injectionPressureBar: 335, lcoeUSDPerMWh: 72.1, recommended: false },
    { id: 'OPT-5', name: 'High-Heat District CHP Mode', netPowerMW: 20.2, reservoirLifetimeYears: 32, seismicRiskIndex: 2.5, productionFlowKgS: 210, injectionPressureBar: 350, lcoeUSDPerMWh: 64.0, recommended: false },
  ]);

  readonly selectedParetoPoint = signal<ParetoPoint>(this.paretoPoints()[1]);

  applyBaselineScenario(): void {
    this.activeScenarioName.set('Baseline Nominal State');
    this.scenarioDescription.set('Standard balanced hybrid operation with 4 active production wells and 2 injection wells.');
    this.physics.twin.update(t => {
      return {
        ...t,
        stateMode: 'baseline',
        reservoir: {
          ...t.reservoir,
          averageTemperature: 215.0,
          thermalBreakthroughFrontDistanceM: 680,
          estimatedBreakthroughYears: 24.5,
        },
        wells: t.wells.map(w => ({
          ...w,
          status: 'active',
          chokeOpening: w.role === 'production' ? 90 : 95,
        })),
        heatExchangers: t.heatExchangers.map(h => ({
          ...h,
          foulingFactor: 0.0,
          ua: h.nominalUa,
        })),
        seismicity: {
          ...t.seismicity,
          trafficLightStatus: 'green',
          maxMagnitudePast24h: 0.22,
        },
      };
    });
    this.physics.stepCoupledPhysics();
  }

  applyThermalBreakthroughDemo(): void {
    this.activeScenarioName.set('Thermal Breakthrough Simulation (10-Year Fast-Forward)');
    this.scenarioDescription.set('Injected cold brine (65°C) sweeps along dominant DFN-01 fracture toward production well P-01. Production enthalpy declines.');
    this.physics.twin.update(t => {
      return {
        ...t,
        stateMode: 'scenario',
        simulationSpeedMultiplier: 10,
        reservoir: {
          ...t.reservoir,
          thermalBreakthroughFrontDistanceM: 1750,
          estimatedBreakthroughYears: 3.2,
          averageTemperature: 182.0,
        },
        wells: t.wells.map(w => {
          if (w.id === 'P-01') {
            return {
              ...w,
              wellheadTemperature: 154.0,
              bottomholeTemperature: 172.0,
              wellheadEnthalpy: 650.0,
            };
          }
          return w;
        }),
      };
    });
    this.physics.stepCoupledPhysics();
  }

  applyWellFailureScenario(): void {
    this.activeScenarioName.set('Production Well P-03 Mechanical Shear / ESP Trip');
    this.scenarioDescription.set('Downhole ESP electrical insulation breakdown on Well P-03 causes immediate well shut-in. Flow redistributed, ORC power drops.');
    this.physics.twin.update(t => {
      return {
        ...t,
        stateMode: 'scenario',
        wells: t.wells.map(w => {
          if (w.id === 'P-03') {
            return {
              ...w,
              status: 'failed',
              flowRate: 0,
              wellheadPressure: 1.0,
              wellheadTemperature: 25.0,
            };
          }
          return w;
        }),
      };
    });
    this.physics.stepCoupledPhysics();
  }

  applyHeatExchangerFoulingScenario(): void {
    this.activeScenarioName.set('Severe Silica & Calcite Scaling Event');
    this.scenarioDescription.set('Brine cooling below 110°C triggers amorphous silica supersaturation (SSI = 1.45), rapidly depositing amorphous scale in Vaporizer HEX-VAP-01, reducing UA by 40%.');
    this.physics.twin.update(t => {
      return {
        ...t,
        stateMode: 'scenario',
        chemistry: {
          ...t.chemistry,
          silicaSaturationIndex: 1.48,
          calciteSaturationIndex: 0.85,
          scalingDepositionRateMmYr: 2.8,
        },
        heatExchangers: t.heatExchangers.map(h => {
          if (h.type === 'vaporizer') {
            const fouledUA = h.nominalUa * 0.58;
            return {
              ...h,
              foulingFactor: 0.42,
              ua: Number(fouledUA.toFixed(1)),
            };
          }
          return h;
        }),
      };
    });
    this.physics.stepCoupledPhysics();
  }

  applyInducedSeismicityScenario(): void {
    this.activeScenarioName.set('High Injection Overpressure & Induced Seismicity (TLS Red)');
    this.scenarioDescription.set('Excess bottomhole injection pressure (>420 bar) reduces effective normal stress on active fault, generating Mw 1.62 microseismic event. Traffic Light System switches to RED.');
    const now = Date.now();
    this.physics.twin.update(t => {
      const redEvent = {
        id: `EV-TLS-RED-${now}`,
        timestamp: now,
        x: 480,
        y: 620,
        z: 4150,
        magnitude: 1.62,
        sourceRadius: 85,
        stressDropMPa: 3.8,
        nearestWellId: 'INJ-01',
        distanceToFaultM: 35,
      };
      return {
        ...t,
        stateMode: 'scenario',
        seismicity: {
          ...t.seismicity,
          trafficLightStatus: 'red',
          maxMagnitudePast24h: 1.62,
          porePressurePerturbationMaxBar: 42.0,
          events: [redEvent, ...t.seismicity.events],
        },
      };
    });
    this.physics.stepCoupledPhysics();
  }

  runDataAssimilation(): void {
    this.activeScenarioName.set('Ensemble Kalman Filter (EnKF) Telemetry Assimilation');
    this.scenarioDescription.set('Observed sensor data from W-02 DTS fiber optic and bottomhole pressure gauges assimilated across 50 Monte Carlo realizations. Model parameters updated.');
    this.physics.twin.update(t => {
      return {
        ...t,
        dataAssimilation: {
          ...t.dataAssimilation,
          currentIteration: t.dataAssimilation.currentIteration + 1,
          misfitObjective: Number((t.dataAssimilation.misfitObjective * 0.72).toFixed(4)),
          historyMatchErrorReductionPercent: Math.min(95, t.dataAssimilation.historyMatchErrorReductionPercent + 6.5),
        },
      };
    });
    this.physics.stepCoupledPhysics();
  }

  selectParetoPoint(point: ParetoPoint): void {
    this.selectedParetoPoint.set(point);
    this.physics.twin.update(t => {
      const perWellFlow = point.productionFlowKgS / 4;
      return {
        ...t,
        wells: t.wells.map(w => {
          if (w.role === 'production') {
            return {
              ...w,
              targetFlowRate: perWellFlow,
              chokeOpening: 92,
            };
          } else {
            return {
              ...w,
              targetFlowRate: (point.productionFlowKgS * 0.98) / 2,
              chokeOpening: 95,
            };
          }
        }),
      };
    });
    this.physics.stepCoupledPhysics();
  }
}
