/**
 * GEOTHERMAL DIGITAL TWIN DOMAIN MODEL
 * Coupled physical system: Earth -> Geology -> Reservoir -> Fractures -> Wells -> Gathering -> ORC/Flash -> Grid -> Reinjection
 */

export type GeothermalArchitecture = 'hydrothermal' | 'egs' | 'deep_heat' | 'hybrid_chp';
export type SimulationStateMode = 'baseline' | 'current' | 'forecast' | 'scenario';
export type GridDispatchMode = 'baseload' | 'load_following' | 'curtailment' | 'islanding';
export type WorkingFluidType = 'R245fa' | 'R134a' | 'Isobutane' | 'n-Pentane' | 'Cyclopentane';
export type CoolingType = 'wet_cooling_tower' | 'air_cooled_acc' | 'hybrid_dry';
export type WellType = 'vertical' | 'deviated' | 'horizontal' | 'multilateral';
export type WellRole = 'production' | 'injection' | 'monitoring';
export type PumpType = 'esp' | 'surface_centrifugal' | 'submersible';
export type SeismicTrafficLight = 'green' | 'amber' | 'red';

export interface FluidProperties {
  type: WorkingFluidType;
  name: string;
  molecularWeight: number; // kg/kmol
  boilingPoint: number; // °C at 1 bar
  criticalTemperature: number; // °C
  criticalPressure: number; // bar
  specificHeatLiquid: number; // kJ/(kg·K)
  latentHeatVaporization: number; // kJ/kg
  gwp: number; // Global Warming Potential
}

export interface RockTypeProperties {
  name: string;
  color: string;
  density: number; // kg/m3
  porosity: number; // fraction 0..1
  permeability: number; // milliDarcy (mD)
  thermalConductivity: number; // W/(m·K)
  specificHeat: number; // J/(kg·K)
  matrixCompressibility: number; // 1/bar
}

export interface GeologicalLayer {
  id: string;
  name: string;
  depthStart: number; // m
  depthEnd: number; // m
  rockType: RockTypeProperties;
  description: string;
  faultPresence: boolean;
}

export interface ReservoirGridCell {
  x: number; // grid index
  y: number;
  z: number;
  posX: number; // m
  posY: number; // m
  posZ: number; // m (depth)
  temperature: number; // °C
  initialTemperature: number; // °C
  pressure: number; // bar
  initialPressure: number; // bar
  enthalpy: number; // kJ/kg
  permeability: number; // mD
  porosity: number;
  fluidMass: number; // kg
  fluidSaturation: number; // fraction
  vaporMassFraction: number; // steam quality (0..1)
  tracerConcentration: number; // ppm
}

export interface DiscreteFracture {
  id: string;
  strike: number; // deg
  dip: number; // deg
  center: [number, number, number]; // [x, y, z] in m
  length: number; // m
  height: number; // m
  aperture: number; // mm
  permeability: number; // Darcy
  hydraulicConductivity: number; // m/s
  apertureCompliance: number; // mm/MPa
  activated: boolean;
}

export interface WellTrajectoryPoint {
  measuredDepth: number; // m
  trueVerticalDepth: number; // m
  inclination: number; // deg (0 = vertical)
  azimuth: number; // deg
  x: number; // easting offset (m)
  y: number; // northing offset (m)
  temperature: number; // °C
  pressure: number; // bar
}

export interface WellModel {
  id: string;
  name: string;
  role: WellRole;
  wellType: WellType;
  depth: number; // m MD
  tvd: number; // m TVD
  casingDiameter: number; // mm (e.g. 244.5 mm / 9-5/8")
  tubingDiameter: number; // mm
  roughness: number; // mm
  status: 'active' | 'choked' | 'shut_in' | 'failed' | 'servicing';
  trajectory: WellTrajectoryPoint[];
  perforations: { topDepth: number; bottomDepth: number; productivityMultiplier: number }[];
  
  // Hydraulic & Operational state
  chokeOpening: number; // 0..100%
  flowRate: number; // kg/s or L/s
  targetFlowRate: number; // kg/s
  wellheadPressure: number; // bar
  bottomholePressure: number; // bar
  wellheadTemperature: number; // °C
  bottomholeTemperature: number; // °C
  wellheadEnthalpy: number; // kJ/kg
  steamQuality: number; // 0..1
  productivityIndex: number; // (kg/s)/bar (PI) or Injectivity Index (II)
  skinFactor: number;
  
  // Pump equipment
  hasPump: boolean;
  pumpType?: PumpType;
  pumpSettingDepth?: number; // m
  pumpRpm?: number; // RPM
  pumpHead?: number; // m
  pumpPower?: number; // kW
  pumpEfficiency?: number; // 0..1
  
  // Fiber optic telemetry
  dtsProfile: { depth: number; observedTemp: number; predictedTemp: number; strainMicro: number }[];
}

export interface SeparatorModel {
  id: string;
  operatingPressure: number; // bar
  operatingTemperature: number; // °C
  inletFlow: number; // kg/s
  inletEnthalpy: number; // kJ/kg
  steamFlow: number; // kg/s
  brineFlow: number; // kg/s
  steamQuality: number; // 0..1
  efficiency: number; // %
}

export interface HeatExchangerModel {
  id: string;
  name: string;
  type: 'preheater' | 'vaporizer' | 'superheater' | 'district_hx';
  ua: number; // kW/K (Overall heat transfer coefficient * Area)
  nominalUa: number; // kW/K (clean baseline)
  foulingFactor: number; // 0..1 (0 = clean, 0.4 = 40% fouled)
  hotSideInletTemp: number; // °C
  hotSideOutletTemp: number; // °C
  hotSideFlow: number; // kg/s
  coldSideInletTemp: number; // °C
  coldSideOutletTemp: number; // °C
  coldSideFlow: number; // kg/s
  lmtd: number; // Log Mean Temperature Difference (°C)
  heatDuty: number; // MWth
  effectiveness: number; // fraction
}

export interface TurbineModel {
  id: string;
  inletPressure: number; // bar
  inletTemperature: number; // °C
  inletEnthalpy: number; // kJ/kg
  outletPressure: number; // bar (condenser pressure)
  outletTemperature: number; // °C
  outletEnthalpy: number; // kJ/kg
  massFlow: number; // kg/s
  isentropicEfficiency: number; // fraction (e.g. 0.86)
  mechanicalEfficiency: number; // fraction (e.g. 0.98)
  shaftPower: number; // MWe
  rpm: number;
  vibrationMmS: number;
}

export interface GeneratorModel {
  id: string;
  mechanicalPowerInput: number; // MWe
  electricalPowerOutput: number; // MWe
  efficiency: number; // fraction (e.g. 0.97)
  voltage: number; // kV (e.g. 11 kV)
  frequency: number; // Hz (50.0 Hz or 60.0 Hz)
  powerFactor: number; // cos phi (e.g. 0.92)
  reactivePower: number; // MVAr
  temperature: number; // °C
}

export interface CondenserModel {
  id: string;
  coolingType: CoolingType;
  ambientTemperature: number; // °C
  ambientRelativeHumidity: number; // %
  condenserPressure: number; // bar (e.g. 0.08 bar wet, 0.15 bar dry)
  condensingTemperature: number; // °C
  coolingWaterFlow: number; // kg/s or fan airflow m3/s
  heatRejectionDuty: number; // MWth
  parasiticFanPower: number; // kW
  parasiticPumpPower: number; // kW
}

export interface DistrictHeatingModel {
  active: boolean;
  thermalDemandMWth: number; // MWth requested
  thermalSuppliedMWth: number; // MWth delivered
  supplyTemperature: number; // °C (e.g. 85°C)
  returnTemperature: number; // °C (e.g. 45°C)
  waterCirculationFlow: number; // kg/s
  networkLengthKm: number;
  buildingsConnected: number;
  thermalStorageState: {
    type: 'ates' | 'btes' | 'stratified_tank';
    capacityMWh: number;
    currentStoredMWh: number;
    chargeRateMWth: number;
    dischargeRateMWth: number;
    lossRatePercentPerDay: number;
  };
}

export interface BrineChemistry {
  ph: number;
  tds: number; // Total Dissolved Solids mg/L
  silicaSiO2: number; // mg/L
  calciumCa: number; // mg/L
  magnesiumMg: number; // mg/L
  sodiumNa: number; // mg/L
  potassiumK: number; // mg/L
  lithiumLi: number; // mg/L (potential mineral extraction)
  chlorideCl: number; // mg/L
  bicarbonateHCO3: number; // mg/L
  sulfateSO4: number; // mg/L
  dissolvedCO2: number; // mg/L
  h2s: number; // mg/L
  
  // Geochemical Indices
  silicaSaturationIndex: number; // SSI (> 1.0 means amorphous silica scaling risk)
  calciteSaturationIndex: number; // Langelier SI (> 0 means CaCO3 scaling risk)
  ryznarStabilityIndex: number; // RSI (< 6.0 heavy scale, > 7.5 corrosion)
  scalingDepositionRateMmYr: number; // mm/year
  corrosionRiskIndicator: 'low' | 'moderate' | 'high' | 'severe';
  lithiumExtractionPotentialKgDay: number; // kg Li/day
}

export interface MicroseismicEvent {
  id: string;
  timestamp: number; // ms
  x: number; // m
  y: number; // m
  z: number; // m depth
  magnitude: number; // Mw (-1.5 to 2.5)
  sourceRadius: number; // m
  stressDropMPa: number;
  nearestWellId: string;
  distanceToFaultM: number;
}

export interface SeismicityState {
  trafficLightStatus: SeismicTrafficLight;
  maxMagnitudePast24h: number;
  eventCountPast24h: number;
  bValue: number; // Gutenberg-Richter slope (~ 0.8 - 1.2)
  aValue: number;
  porePressurePerturbationMaxBar: number;
  hydraulicDiffusivityM2s: number;
  injectionPressureLimitBar: number;
  events: MicroseismicEvent[];
  amberThresholdMw: number; // e.g. 0.5 Mw
  redThresholdMw: number; // e.g. 1.5 Mw
}

export interface GridConnectionState {
  dispatchMode: GridDispatchMode;
  substationVoltageKV: number;
  frequencyHz: number;
  exportActivePowerMW: number;
  exportReactivePowerMVAr: number;
  curtailmentPercent: number;
  gridDemandMW: number;
  powerFactor: number;
  transmissionLossMW: number;
  interconnectionStatus: 'synchronized' | 'islanded' | 'tripped';
}

export interface MaintenanceAsset {
  id: string;
  name: string;
  category: 'production_well' | 'injection_well' | 'pump' | 'separator' | 'heat_exchanger' | 'turbine' | 'generator' | 'cooling_tower' | 'valve' | 'pipeline';
  operatingHours: number;
  healthIndex: number; // 0..100%
  foulingOrWearPercent: number;
  failureProbabilityNext30d: number;
  vibrationLevelMmS: number;
  corrosionWallLossMm: number;
  lastServiceDate: string;
  nextScheduledService: string;
  status: 'nominal' | 'warning' | 'critical' | 'under_maintenance';
  recentAnomaly?: string;
}

export interface FieldEconomics {
  currency: string;
  drillingCapexM: number; // Million $
  surfacePlantCapexM: number;
  gridInterconnectionCapexM: number;
  totalCapexM: number;
  fixedOpexMPerYear: number;
  variableOpexPerMWh: number;
  powerPPAUSDPerMWh: number; // $/MWh
  heatPriceUSDPerMWhth: number; // $/MWh thermal
  lithiumPriceUSDPerKg: number;
  discountRatePercent: number;
  lcoeUSDPerMWh: number;
  npvMillionUSD: number;
  irrPercent: number;
  paybackYears: number;
  annualRevenueMillionUSD: number;
  annualElectricityMWh: number;
  annualHeatMWhth: number;
}

export interface CarbonAccounting {
  scope1KgCO2ePerMWh: number; // Fugitive non-condensable gases (CO2/CH4 in brine)
  scope2KgCO2ePerMWh: number; // Auxiliary grid power when islanded
  scope3KgCO2ePerMWh: number; // Life-cycle well drilling & steel/cement
  totalKgCO2ePerMWh: number;
  avoidedEmissionsTonsPerYear: number; // vs natural gas baseline (400 kg/MWh)
}

export interface BalancesState {
  thermalEnergyInMWth: number;
  grossElectricalPowerMW: number;
  netElectricalPowerMW: number;
  districtHeatDeliveredMWth: number;
  condenserHeatRejectionMWth: number;
  parasiticAuxiliaryPowerMW: number;
  thermalLossesMWth: number;
  energyBalanceDiscrepancyPercent: number; // (|In - Out| / In) * 100
  
  brineProductionTotalKgS: number;
  brineReinjectionTotalKgS: number;
  steamProductionTotalKgS: number;
  waterLossesKgS: number;
  waterBalanceDiscrepancyPercent: number;
  
  reservoirMassChangeKgS: number;
}

export interface SensorTelemetryPacket {
  sensorId: string;
  tag: string;
  unit: string;
  observedValue: number;
  predictedValue: number;
  residual: number;
  timestamp: number;
  quality: 'GOOD' | 'WARNING' | 'FAULT';
}

export interface DataAssimilationState {
  algorithm: 'EnKF' | 'ESMDA' | 'Ensemble_Smoother';
  ensembleMembers: number;
  currentIteration: number;
  misfitObjective: number;
  assimilatedParameters: {
    parameter: string;
    priorMean: number;
    posteriorMean: number;
    priorStd: number;
    posteriorStd: number;
    unit: string;
  }[];
  historyMatchErrorReductionPercent: number;
}

export interface MonteCarloResult {
  p10PowerMW: number;
  p50PowerMW: number;
  p90PowerMW: number;
  p10LifetimeYears: number;
  p50LifetimeYears: number;
  p90LifetimeYears: number;
  p10ThermalBreakthroughYear: number;
  p50ThermalBreakthroughYear: number;
  p90ThermalBreakthroughYear: number;
  runsCount: number;
  samples: {
    permeability: number;
    thermalCond: number;
    breakthroughYr: number;
    year10MW: number;
    lcoe: number;
  }[];
}

export interface ProductionForecastPoint {
  year: number;
  reservoirAvgTempC: number;
  reservoirAvgPressureBar: number;
  productionFlowKgS: number;
  productionTempC: number;
  grossPowerMW: number;
  netPowerMW: number;
  districtHeatMWth: number;
  cumulativeEnergyGWh: number;
  cumRevenueM: number;
  p10NetPowerMW: number;
  p90NetPowerMW: number;
}

export interface GeothermalDigitalTwin {
  id: string;
  name: string;
  fieldCode: string;
  version: string;
  stateMode: SimulationStateMode;
  architecture: GeothermalArchitecture;
  workingFluid: FluidProperties;
  simulatedTimestamp: number;
  simulationSpeedMultiplier: number;
  isSimulating: boolean;
  
  // Coupling Sub-Systems
  geology: {
    layers: GeologicalLayer[];
    faultDipDeg: number;
    faultStrikeDeg: number;
    regionalStressMaxMPa: number;
    regionalStressMinMPa: number;
  };
  reservoir: {
    gridNx: number;
    gridNy: number;
    gridNz: number;
    dx: number; // m
    dy: number;
    dz: number;
    cells: ReservoirGridCell[];
    averageTemperature: number; // °C
    averagePressure: number; // bar
    activeThermalSweepVolumeM3: number;
    thermalBreakthroughFrontDistanceM: number;
    estimatedBreakthroughYears: number;
  };
  fractureNetwork: {
    fractures: DiscreteFracture[];
    totalFractureSurfaceAreaM2: number;
    averageConductivityM2: number;
    dominantFlowPathWellIds: [string, string];
  };
  wells: WellModel[];
  gatheringSystem: {
    productionHeaderPressureBar: number;
    productionHeaderTempC: number;
    reinjectionHeaderPressureBar: number;
    reinjectionHeaderTempC: number;
    pipelineLossPressureBar: number;
    pipelineThermalLossC: number;
  };
  separator: SeparatorModel;
  heatExchangers: HeatExchangerModel[];
  turbine: TurbineModel;
  generator: GeneratorModel;
  condenser: CondenserModel;
  districtHeating: DistrictHeatingModel;
  grid: GridConnectionState;
  chemistry: BrineChemistry;
  seismicity: SeismicityState;
  maintenance: MaintenanceAsset[];
  economics: FieldEconomics;
  carbon: CarbonAccounting;
  balances: BalancesState;
  telemetryBus: SensorTelemetryPacket[];
  dataAssimilation: DataAssimilationState;
  forecast: ProductionForecastPoint[];
  monteCarlo: MonteCarloResult;
}
