"""
GEOTHERMAL NEXUS — Physics Engine
Geological model, reservoir thermodynamics, well hydraulics.
All units SI unless noted in variable names.
"""

import numpy as np
from scipy.ndimage import convolve
from dataclasses import dataclass, field
from typing import List, Tuple, Dict, Optional
import enum


# ─────────────────────────────────────────────
# ROCK TYPES & THERMAL PROPERTIES
# ─────────────────────────────────────────────

class RockType(enum.Enum):
    GRANITE   = "Granite"
    SANDSTONE = "Sandstone"
    LIMESTONE = "Limestone"
    BASALT    = "Basalt"
    SHALE     = "Shale"
    RHYOLITE  = "Rhyolite"


ROCK_PROPERTIES: Dict[RockType, Dict] = {
    RockType.GRANITE: {
        "thermal_conductivity": 3.1,    # W/m·K
        "heat_capacity":        790,    # J/kg·K
        "density":              2650,   # kg/m³
        "permeability":         3e-15,  # m² — EGS stimulated crystalline basement
        "porosity":             0.02,
        "color":                "#8B4513",
        "description":          "Stimulated crystalline basement (EGS)",
    },
    RockType.SANDSTONE: {
        "thermal_conductivity": 2.5,
        "heat_capacity":        830,
        "density":              2350,
        "permeability":         8e-13,  # High-quality porous sedimentary reservoir
        "porosity":             0.22,
        "color":                "#D2B48C",
        "description":          "Porous sedimentary reservoir rock",
    },
    RockType.LIMESTONE: {
        "thermal_conductivity": 2.8,
        "heat_capacity":        840,
        "density":              2700,
        "permeability":         2e-14,  # Fractured carbonate
        "porosity":             0.12,
        "color":                "#B8B8A0",
        "description":          "Fractured carbonate reservoir",
    },
    RockType.BASALT: {
        "thermal_conductivity": 1.7,
        "heat_capacity":        840,
        "density":              2900,
        "permeability":         5e-13,  # Fractured basalt — Iceland-type volcanic
        "porosity":             0.08,
        "color":                "#2F2F2F",
        "description":          "Fractured volcanic basalt, high perm",
    },
    RockType.SHALE: {
        "thermal_conductivity": 1.5,
        "heat_capacity":        920,
        "density":              2400,
        "permeability":         1e-18,  # Cap rock — very tight
        "porosity":             0.05,
        "color":                "#4A4A5A",
        "description":          "Low-permeability cap rock / seal",
    },
    RockType.RHYOLITE: {
        "thermal_conductivity": 2.0,
        "heat_capacity":        800,
        "density":              2500,
        "permeability":         2e-13,  # Fractured felsic volcanic
        "porosity":             0.10,
        "color":                "#A0522D",
        "description":          "Felsic volcanic rock near heat source",
    },
}


# ─────────────────────────────────────────────
# CONFIGURATION DATACLASSES
# ─────────────────────────────────────────────

@dataclass
class GeologicalConfig:
    """Subsurface geological parameters."""
    nx: int   = 24        # Lateral grid cells
    nz: int   = 16        # Depth grid cells
    dx: float = 400.0     # m — lateral cell width
    dz: float = 250.0     # m — depth cell height

    surface_temp:        float = 12.0   # °C
    geothermal_gradient: float = 32.0   # °C/km

    # Stratigraphy: list of (top_depth_m, RockType name)
    layers: List[Tuple[float, str]] = field(default_factory=lambda: [
        (0,    "SHALE"),
        (500,  "SANDSTONE"),
        (1500, "LIMESTONE"),
        (2800, "GRANITE"),
    ])

    has_heat_anomaly:      bool  = True
    heat_anomaly_depth_m:  float = 3500.0
    heat_anomaly_temp_C:   float = 60.0    # excess °C above gradient
    heat_anomaly_sigma_m:  float = 1800.0  # Gaussian half-width

    fracture_multiplier: float = 150.0   # permeability enhancement in fractures
    n_fracture_zones:    int   = 8


@dataclass
class WellConfig:
    """Configuration for a single borehole."""
    well_id:          str
    well_type:        str    # 'production' or 'injection'
    x_pos_m:          float  # m from field origin
    depth_m:          float  # total drilled depth
    diameter_m:       float  = 0.216  # 8.5-inch bit
    target_flow_kgs:  float  = 60.0   # kg/s
    is_active:        bool   = True

    # Derived cost (set during CAPEX calculation)
    drill_cost_MUSD:  float  = 0.0


@dataclass
class PlantConfig:
    """Surface power plant parameters."""
    plant_type:         str   = "ORC"       # ORC | FLASH | DRY_STEAM
    design_inlet_temp:  float = 160.0       # °C
    injection_temp:     float = 65.0        # °C reinject temperature
    cooling_temp:       float = 25.0        # °C ambient / condenser
    # Parasitic load fraction (pumping, cooling tower, etc.)
    parasitic_fraction: float = 0.12


@dataclass
class EconomicsConfig:
    electricity_price_USD_kWh: float = 0.085
    discount_rate:             float = 0.08
    plant_cost_MUSD_per_MW:    float = 3.2   # Surface plant $/MW
    exploration_cost_MUSD:     float = 8.0
    opex_fraction_of_capex:    float = 0.03  # Annual OPEX / CAPEX


@dataclass
class SystemConfig:
    """Master configuration object."""
    name:       str = "Geothermal Field Alpha-1"
    geology:    GeologicalConfig = field(default_factory=GeologicalConfig)
    plant:      PlantConfig      = field(default_factory=PlantConfig)
    economics:  EconomicsConfig  = field(default_factory=EconomicsConfig)
    wells:      List[WellConfig] = field(default_factory=list)

    dt_years:    float = 0.25    # Quarterly timestep
    total_years: float = 30.0

    random_seed: int = 42


# ─────────────────────────────────────────────
# FLUID PROPERTIES (water/steam)
# ─────────────────────────────────────────────

def water_density(T_C: float) -> float:
    """
    Liquid water density kg/m³.
    Polynomial fit to IAPWS-IF97 data: valid 20–350 °C.
    """
    T_C = np.clip(T_C, 20, 350)
    return 1005.0 - 0.5 * T_C - 0.0015 * T_C**2


def water_viscosity(T_C: float) -> float:
    """
    Dynamic viscosity Pa·s (Vogel equation, T in Kelvin).
    μ = 2.414×10⁻⁵ × 10^(247.8 / (T_K − 140))
    Accurate to ~5% over 20–300 °C.
    """
    T_C = np.clip(T_C, 20, 300)
    T_K = T_C + 273.15
    return 2.414e-5 * 10.0 ** (247.8 / (T_K - 140.0))


def water_enthalpy(T_C: float) -> float:
    """Specific enthalpy kJ/kg (liquid)."""
    return 4.186 * T_C  # Simplified


def orc_efficiency(T_hot_C: float, T_cold_C: float) -> float:
    """
    ORC thermal efficiency.
    Utilisation factor × Carnot (empirical fit to real ORC plant data).
    """
    if T_hot_C <= T_cold_C + 10:
        return 0.0
    T_hot_K  = T_hot_C + 273.15
    T_cold_K = T_cold_C + 273.15
    eta_carnot   = 1.0 - T_cold_K / T_hot_K
    # ORC utilisation factor: 0.45-0.65 of Carnot depending on temperature
    utilisation = 0.40 + 0.15 * np.clip((T_hot_C - 100) / 150, 0, 1)
    return eta_carnot * utilisation


def flash_efficiency(T_hot_C: float, T_cold_C: float) -> float:
    """Single-flash cycle efficiency."""
    if T_hot_C < 180:
        return orc_efficiency(T_hot_C, T_cold_C)
    T_hot_K  = T_hot_C + 273.15
    T_cold_K = T_cold_C + 273.15
    eta_carnot  = 1.0 - T_cold_K / T_hot_K
    utilisation = 0.55 + 0.10 * np.clip((T_hot_C - 180) / 120, 0, 1)
    return eta_carnot * utilisation


def plant_efficiency(plant_type: str, T_hot_C: float, T_cold_C: float) -> float:
    if plant_type == "ORC":
        return orc_efficiency(T_hot_C, T_cold_C)
    elif plant_type == "FLASH":
        return flash_efficiency(T_hot_C, T_cold_C)
    elif plant_type == "DRY_STEAM":
        T_hot_K  = T_hot_C + 273.15
        T_cold_K = T_cold_C + 273.15
        return 0.65 * (1.0 - T_cold_K / T_hot_K)
    return orc_efficiency(T_hot_C, T_cold_C)


# ─────────────────────────────────────────────
# GEOTHERMAL FIELD — RESERVOIR MODEL
# ─────────────────────────────────────────────

class GeothermalField:
    """
    2-D (x–z) geothermal reservoir model.
    z = depth axis (0 = surface, positive downward)
    x = lateral axis
    """

    def __init__(self, config: SystemConfig):
        self.config = config
        gc = config.geology
        np.random.seed(config.random_seed)

        self.nx = gc.nx
        self.nz = gc.nz
        self.dx = gc.dx
        self.dz = gc.dz

        # Cell-centre coordinates
        self.x_centres = (np.arange(self.nx) + 0.5) * self.dx   # m
        self.z_centres = (np.arange(self.nz) + 0.5) * self.dz   # m (depth)

        # Mesh grids for vectorised ops
        self.X, self.Z = np.meshgrid(self.x_centres, self.z_centres)  # (nz, nx)

        # Build static property fields
        self.rock_type_grid = self._build_rock_type_grid()
        self.k_rock    = self._build_property("thermal_conductivity")  # W/m·K
        self.rho_rock  = self._build_property("density")               # kg/m³
        self.cp_rock   = self._build_property("heat_capacity")         # J/kg·K
        self.phi_rock  = self._build_property("porosity")              # –
        self.K_perm    = self._build_permeability()                    # m²

        # Fracture network
        self.fracture_mask = self._generate_fractures()

        # Dynamic fields — initialised to initial state
        self.T = self._init_temperature()          # °C
        self.T0 = self.T.copy()                    # Reference (undisturbed)
        self.P = self._init_pressure()             # MPa

        # Cumulative tracking
        self.heat_extracted_MJ  = np.zeros((self.nz, self.nx))
        self.cum_inject_vol_m3  = 0.0

        # Thermal diffusivity field
        self.alpha = self.k_rock / (self.rho_rock * self.cp_rock)  # m²/s

        # Finite-difference Laplacian coefficients (pre-computed)
        self._build_diffusion_coefficients()

    # ── INITIALISATION ──────────────────────────────────────────────

    def _build_rock_type_grid(self) -> np.ndarray:
        """Assign rock type index to each cell based on stratigraphy."""
        gc = self.config.geology
        layers = sorted([(d, RockType[r]) for d, r in gc.layers], key=lambda x: x[0])
        grid = np.empty((self.nz, self.nx), dtype=object)

        for iz in range(self.nz):
            depth = self.z_centres[iz]
            rt = layers[0][1]
            for layer_depth, layer_rock in layers:
                if depth >= layer_depth:
                    rt = layer_rock
            grid[iz, :] = rt
        return grid

    def _build_property(self, prop_name: str) -> np.ndarray:
        arr = np.zeros((self.nz, self.nx))
        for iz in range(self.nz):
            rt = self.rock_type_grid[iz, 0]
            arr[iz, :] = ROCK_PROPERTIES[rt][prop_name]
        return arr

    def _build_permeability(self) -> np.ndarray:
        """Log-normal heterogeneous permeability field."""
        k_base = np.zeros((self.nz, self.nx))
        for iz in range(self.nz):
            rt = self.rock_type_grid[iz, 0]
            k_base[iz, :] = ROCK_PROPERTIES[rt]["permeability"]

        log_k  = np.log10(k_base)
        noise  = np.random.randn(self.nz, self.nx) * 0.4  # ±0.4 log-order heterogeneity
        return 10.0 ** (log_k + noise)

    def _generate_fractures(self) -> np.ndarray:
        """Stochastic discrete fracture network."""
        gc   = self.config.geology
        mask = np.zeros((self.nz, self.nx), dtype=bool)

        for _ in range(gc.n_fracture_zones):
            ix_c = np.random.randint(1, max(2, self.nx - 1))
            iz_t = np.random.randint(1, max(2, self.nz - 4))
            max_len = max(4, self.nz - iz_t)
            length = np.random.randint(2, min(8, max_len))
            dip    = np.random.choice([-1, 0, 0, 1])  # mostly vertical

            for s in range(length):
                iz = iz_t + s
                ix = ix_c + dip * s
                if 0 <= iz < self.nz and 0 <= ix < self.nx:
                    mask[iz, ix] = True

        # Enhance permeability at fractures
        self.K_perm = getattr(self, "K_perm", self._build_permeability())
        if hasattr(self, "K_perm"):
            self.K_perm[mask] *= gc.fracture_multiplier
        return mask

    def _init_temperature(self) -> np.ndarray:
        """Geothermal gradient + optional heat anomaly."""
        gc = self.config.geology
        T  = gc.surface_temp + gc.geothermal_gradient * self.Z / 1000.0

        if gc.has_heat_anomaly:
            x_c    = self.nx * self.dx / 2.0
            dZ     = self.Z - gc.heat_anomaly_depth_m
            dX     = self.X - x_c
            r2     = dZ**2 + dX**2
            sigma2 = gc.heat_anomaly_sigma_m**2
            T     += gc.heat_anomaly_temp_C * np.exp(-r2 / (2 * sigma2))

        return T

    def _init_pressure(self) -> np.ndarray:
        """Hydrostatic pressure field in MPa."""
        rho_w = 980.0   # kg/m³ — hot brine
        g     = 9.81
        return rho_w * g * self.Z / 1e6

    def _build_diffusion_coefficients(self):
        """Pre-compute spatially variable diffusion coefficients."""
        # Used in Crank-Nicolson or explicit diffusion
        # kx_half[iz, ix] = k between cell (iz,ix) and (iz,ix+1)
        k = self.k_rock
        self.kx_half = 0.5 * (k[:, :-1] + k[:, 1:])    # shape (nz, nx-1)
        self.kz_half = 0.5 * (k[:-1, :] + k[1:, :])    # shape (nz-1, nx)

    # ── WELL UTILITIES ──────────────────────────────────────────────

    def well_cell(self, well: WellConfig) -> Tuple[int, int]:
        """Map well position to nearest grid cell (iz, ix)."""
        iz = int(np.clip(well.depth_m / self.dz, 0, self.nz - 1))
        ix = int(np.clip(well.x_pos_m / self.dx, 0, self.nx - 1))
        return iz, ix

    def achievable_flow_rate(self, well: WellConfig) -> float:
        """
        Productivity Index calculation (Darcy flow, kg/s).
        PI = 2πkh / (μ ln(r_e/r_w))
        """
        iz, ix = self.well_cell(well)
        k   = self.K_perm[iz, ix]        # m²
        T_r = self.T[iz, ix]             # °C
        mu  = water_viscosity(T_r)       # Pa·s
        h   = self.dz                    # m screen length
        r_e = 5.0 * min(self.dx, self.dz)
        r_w = well.diameter_m / 2.0

        PI = (2 * np.pi * k * h) / (mu * np.log(r_e / r_w))  # m³/(s·Pa)

        P_res  = self.P[iz, ix] * 1e6   # Pa
        dP     = P_res * 0.22           # 22% drawdown
        Q_vol  = PI * dP                # m³/s
        rho    = water_density(T_r)     # kg/m³
        Q_mass = Q_vol * rho            # kg/s

        return float(np.clip(Q_mass, 0.5, well.target_flow_kgs))

    # ── EXTRACTION / INJECTION ──────────────────────────────────────

    def extract_heat(self, well: WellConfig, mass_flow_kgs: float,
                     dt_s: float, T_inject_C: float) -> Tuple[float, float]:
        """
        Simulate one timestep of heat extraction at a production well.
        Returns (production_temp_C, power_MW_thermal).
        """
        iz, ix = self.well_cell(well)
        T_prod = float(self.T[iz, ix])

        cp_w     = 4186.0       # J/kg·K water specific heat
        rho_rock = self.rho_rock[iz, ix]
        cp_rock  = self.cp_rock[iz, ix]
        phi      = self.phi_rock[iz, ix]

        # Thermal power extracted [W]
        Q_therm = mass_flow_kgs * cp_w * max(T_prod - T_inject_C, 0)

        # Bulk (rock + fluid) volumetric heat capacity [J/m³·K]
        cp_bulk = (1 - phi) * rho_rock * cp_rock + phi * water_density(T_prod) * cp_w

        # Temperature depletion in influence zone
        cell_vol = self.dx * self.dz * self.dx   # m³
        delta_T  = Q_therm * dt_s / (cp_bulk * cell_vol)

        # Gaussian influence spreading to neighbouring cells
        influence_r = 4  # cells
        for diz in range(-influence_r, influence_r + 1):
            for dix in range(-influence_r, influence_r + 1):
                niz = iz + diz
                nix = ix + dix
                if 0 <= niz < self.nz and 0 <= nix < self.nx:
                    r  = np.sqrt(diz**2 + dix**2) + 1e-3
                    wt = np.exp(-r**2 / (2 * (influence_r * 0.5)**2))
                    self.T[niz, nix] -= delta_T * wt * 0.5

        self.heat_extracted_MJ[iz, ix] += Q_therm * dt_s / 1e6

        return T_prod, Q_therm / 1e6  # °C, MW_thermal

    def inject_fluid(self, well: WellConfig, mass_flow_kgs: float,
                     dt_s: float, T_inject_C: float):
        """
        Simulate cold fluid injection (recharge + thermal plume).
        Models cold-plume propagation toward production wells.
        """
        iz, ix = self.well_cell(well)

        cp_w    = 4186.0
        phi     = self.phi_rock[iz, ix]
        rho_rock = self.rho_rock[iz, ix]
        cp_rock  = self.cp_rock[iz, ix]
        cp_bulk  = (1 - phi) * rho_rock * cp_rock + phi * water_density(T_inject_C) * cp_w

        cell_vol = self.dx * self.dz * self.dx
        # Thermal front velocity [cells/timestep]
        v_darcy   = mass_flow_kgs / (water_density(T_inject_C) * phi * self.dx * self.dz)  # m/s
        cells_adv = v_darcy * dt_s / self.dx

        # Cold plume propagation (upward + laterally)
        spread = max(1, int(cells_adv * 0.3))
        for diz in range(-spread, 1):
            for dix in range(-spread, spread + 1):
                niz = iz + diz
                nix = ix + dix
                if 0 <= niz < self.nz and 0 <= nix < self.nx:
                    r  = np.sqrt(diz**2 + dix**2) + 1e-3
                    wt = np.exp(-r**2 / (2 * max(1, spread)**2))
                    T_cur = self.T[niz, nix]
                    self.T[niz, nix] -= (T_cur - T_inject_C) * wt * 0.04

        self.cum_inject_vol_m3 += mass_flow_kgs * dt_s / water_density(T_inject_C)

        # Partial pressure recovery from reinjection
        self.P[iz, ix] += mass_flow_kgs * dt_s * 1e-3 * 0.05e-6  # small pressure boost

    # ── THERMAL DIFFUSION ───────────────────────────────────────────

    def apply_thermal_diffusion(self, dt_s: float):
        """
        Explicit finite-difference thermal diffusion.
        Stability condition: dt ≤ dx²/(2α)
        """
        alpha_max = float(np.max(self.alpha))
        dt_stable = 0.25 * min(self.dx, self.dz)**2 / alpha_max
        n_sub     = max(1, min(int(dt_s / dt_stable), 20))
        dt_sub    = dt_s / n_sub

        cx = dt_sub / self.dx**2
        cz = dt_sub / self.dz**2

        T = self.T.copy()

        for _ in range(n_sub):
            # Interior fluxes using variable conductivity
            Fx = self.kx_half / (self.rho_rock[:, :-1] * self.cp_rock[:, :-1])
            Fz = self.kz_half / (self.rho_rock[:-1, :] * self.cp_rock[:-1, :])

            T_new = T.copy()
            T_new[:, 1:-1] += cx * (
                Fx[:, 1:] * (T[:, 2:] - T[:, 1:-1]) -
                Fx[:, :-1] * (T[:, 1:-1] - T[:, :-2])
            )
            T_new[1:-1, :] += cz * (
                Fz[1:, :] * (T[2:, :] - T[1:-1, :]) -
                Fz[:-1, :] * (T[1:-1, :] - T[:-2, :])
            )
            # Boundary conditions: fixed gradient at top, insulating at sides
            T_new[0, :]  = self.T0[0, :]    # Surface temperature fixed
            T_new[-1, :] = T_new[-2, :]     # Bottom: insulating
            T_new[:, 0]  = T_new[:, 1]     # Left: insulating
            T_new[:, -1] = T_new[:, -2]    # Right: insulating

            T = T_new

        # Natural recharge — slow drift back toward initial (geological timescale)
        recovery_rate = 5e-9  # per second
        T += (self.T0 - T) * recovery_rate * dt_s

        self.T = T

    def update_pressure(self, production_wells: List[WellConfig],
                        injection_wells: List[WellConfig],
                        flow_rates: Dict[str, float], dt_s: float):
        """Pressure update: drawdown at producers, recharge at injectors."""
        # Simple linear pressure model
        for well in production_wells:
            iz, ix = self.well_cell(well)
            Q = flow_rates.get(well.well_id, 0)
            mu  = water_viscosity(self.T[iz, ix])
            k   = self.K_perm[iz, ix]
            r_e = 5 * min(self.dx, self.dz)
            r_w = well.diameter_m / 2

            # Pressure drawdown (MPa) — Theis equation simplified
            P_draw = (Q * mu * np.log(r_e / r_w)) / (2 * np.pi * k * self.dz) / 1e6
            self.P[iz, ix] = max(self.P[iz, ix] - P_draw * dt_s * 1e-7, 0.1)

        for well in injection_wells:
            iz, ix = self.well_cell(well)
            self.P[iz, ix] = min(self.P[iz, ix] * 1.001, self.P[iz, ix] + 0.05)

        # Pressure diffusion (smooth out gradients)
        kernel = np.array([[0, 0.1, 0], [0.1, 0.6, 0.1], [0, 0.1, 0]])
        self.P = convolve(self.P, kernel, mode='nearest')

    # ── DIAGNOSTICS ─────────────────────────────────────────────────

    def reservoir_mean_temp(self) -> float:
        """Volume-weighted mean reservoir temperature (°C)."""
        return float(np.mean(self.T))

    def thermal_depletion_index(self) -> float:
        """0.0 = undepleted, 1.0 = fully depleted vs initial state."""
        dT   = self.T0 - self.T
        dT0  = np.maximum(self.T0 - self.config.geology.surface_temp, 1)
        return float(np.mean(dT / dT0))

    def max_temp_depth(self) -> Tuple[float, float]:
        """Return (max_temperature, depth_of_max) in °C and m."""
        iz, ix = np.unravel_index(np.argmax(self.T), self.T.shape)
        return float(self.T[iz, ix]), float(self.z_centres[iz])

    def production_zone_temp(self, wells: List[WellConfig]) -> float:
        """Mean temperature at production well locations."""
        temps = []
        for w in wells:
            if w.well_type == "production" and w.is_active:
                iz, ix = self.well_cell(w)
                temps.append(self.T[iz, ix])
        return float(np.mean(temps)) if temps else 0.0
