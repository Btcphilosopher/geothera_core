"""
GEOTHERA CORE
Geothermal Energy System Simulation & Optimisation Engine
Industrial operations control interface
"""

import streamlit as st
import numpy as np
import pandas as pd
import plotly.graph_objects as go
import time
import sys
import os

sys.path.insert(0, os.path.dirname(__file__))

from physics import (
    SystemConfig, GeologicalConfig, PlantConfig, EconomicsConfig,
    WellConfig, RockType, ROCK_PROPERTIES, plant_efficiency
)
from simulation import (
    SimulationEngine, build_default_wells, PRESET_CONFIGS
)
from charts import (
    thermal_heatmap, temperature_profile_chart,
    power_output_chart, cumulative_energy_chart, plant_efficiency_chart,
    well_flow_chart, well_temperature_chart,
    depletion_timeline_chart, reservoir_temp_evolution,
    risk_dashboard, risk_gauge,
    economics_overview_chart, capex_breakdown_chart, well_economics_table,
    optimisation_metrics_chart, pressure_evolution_chart,
    PALETTE,
)

# ─────────────────────────────────────────────
# PAGE CONFIGURATION
# ─────────────────────────────────────────────

st.set_page_config(
    page_title  = "GEOTHERA CORE",
    page_icon   = "🌋",
    layout      = "wide",
    initial_sidebar_state = "expanded",
)

# ─────────────────────────────────────────────
# GLOBAL CSS
# ─────────────────────────────────────────────

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Rajdhani:wght@400;600;700&display=swap');

/* ── Root ── */
html, body, [class*="css"] {
    background-color: #080808 !important;
    color: #D4D4D4;
}
.stApp { background-color: #080808; }

/* ── Sidebar ── */
[data-testid="stSidebar"] {
    background: #0d0d0d !important;
    border-right: 1px solid #2a1a00;
}
[data-testid="stSidebar"] * { color: #B0B0B0 !important; }
[data-testid="stSidebar"] .stSelectbox label,
[data-testid="stSidebar"] .stSlider label,
[data-testid="stSidebar"] .stNumberInput label {
    color: #FFB800 !important;
    font-family: 'Share Tech Mono', monospace !important;
    font-size: 11px !important;
    letter-spacing: 0.05em;
}
[data-testid="stSidebar"] .stMarkdown p {
    color: #707070 !important;
    font-family: 'Share Tech Mono', monospace;
    font-size: 10px;
}

/* ── Tabs ── */
.stTabs [data-baseweb="tab-list"] {
    background: #0d0d0d;
    border-bottom: 1px solid #2a1a00;
    gap: 0px;
}
.stTabs [data-baseweb="tab"] {
    background: transparent;
    color: #707070 !important;
    font-family: 'Share Tech Mono', monospace !important;
    font-size: 11px !important;
    letter-spacing: 0.08em;
    padding: 8px 18px;
    border: none;
    border-right: 1px solid #1a1a1a;
}
.stTabs [aria-selected="true"] {
    background: #161616 !important;
    color: #FFB800 !important;
    border-bottom: 2px solid #FF6B00 !important;
}
.stTabs [data-baseweb="tab-panel"] {
    background: #0a0a0a;
    padding: 12px 0px;
}

/* ── Metric cards ── */
[data-testid="stMetric"] {
    background: #111111;
    border: 1px solid #2a1a00;
    border-radius: 3px;
    padding: 12px 14px;
}
[data-testid="stMetricLabel"] {
    color: #707070 !important;
    font-family: 'Share Tech Mono', monospace !important;
    font-size: 10px !important;
    letter-spacing: 0.06em;
    text-transform: uppercase;
}
[data-testid="stMetricValue"] {
    color: #FFB800 !important;
    font-family: 'Share Tech Mono', monospace !important;
    font-size: 20px !important;
}
[data-testid="stMetricDelta"] {
    font-family: 'Share Tech Mono', monospace !important;
    font-size: 11px !important;
}

/* ── Buttons ── */
.stButton > button {
    background: #1A0800 !important;
    border: 1px solid #FF6B00 !important;
    color: #FF6B00 !important;
    font-family: 'Share Tech Mono', monospace !important;
    font-size: 12px !important;
    letter-spacing: 0.10em;
    padding: 10px 28px;
    border-radius: 2px;
    width: 100%;
    transition: all 0.2s;
}
.stButton > button:hover {
    background: #FF6B00 !important;
    color: #000 !important;
}

/* ── Selectbox, slider, input ── */
.stSelectbox > div > div,
.stTextInput > div > div > input {
    background: #111111 !important;
    border: 1px solid #2a1a00 !important;
    color: #D4D4D4 !important;
    font-family: 'Share Tech Mono', monospace !important;
    font-size: 12px !important;
}
.stSlider [data-baseweb="slider"] div[role="slider"] {
    background: #FF6B00 !important;
}

/* ── Info / warning boxes ── */
.advisory-box {
    background: #110800;
    border: 1px solid #FF6B00;
    border-left: 3px solid #FF6B00;
    border-radius: 2px;
    padding: 8px 14px;
    margin: 4px 0;
    font-family: 'Share Tech Mono', monospace;
    font-size: 11px;
    color: #D4D4D4;
}
.advisory-ok {
    border-color: #00E676;
    border-left-color: #00E676;
}
.risk-critical { border-left-color: #FF1744; }

/* ── Section headers ── */
.section-header {
    font-family: 'Rajdhani', sans-serif;
    font-size: 13px;
    font-weight: 700;
    color: #FFB800;
    letter-spacing: 0.15em;
    text-transform: uppercase;
    border-bottom: 1px solid #2a1a00;
    padding-bottom: 4px;
    margin-bottom: 12px;
}

/* ── KPI bar ── */
.kpi-panel {
    background: #0d0d0d;
    border: 1px solid #2a1a00;
    border-radius: 2px;
    padding: 10px 16px;
    display: flex;
    flex-direction: column;
    align-items: center;
}
.kpi-value {
    font-family: 'Share Tech Mono', monospace;
    font-size: 22px;
    color: #FFB800;
}
.kpi-label {
    font-family: 'Share Tech Mono', monospace;
    font-size: 9px;
    color: #505050;
    letter-spacing: 0.10em;
    text-transform: uppercase;
}

/* ── Progress bar ── */
.stProgress > div > div > div {
    background: linear-gradient(90deg, #FF6B00, #FFB800) !important;
}

/* ── Dividers ── */
hr { border-color: #1E1E1E !important; }

/* ── Scrollbar ── */
::-webkit-scrollbar { width: 5px; background: #0a0a0a; }
::-webkit-scrollbar-thumb { background: #2a1a00; border-radius: 2px; }

/* ── Expander ── */
[data-testid="stExpander"] {
    background: #0d0d0d;
    border: 1px solid #1a1a1a;
    border-radius: 2px;
}
</style>
""", unsafe_allow_html=True)


# ─────────────────────────────────────────────
# SESSION STATE INITIALISATION
# ─────────────────────────────────────────────

if "sim_engine"   not in st.session_state: st.session_state.sim_engine   = None
if "sim_df"       not in st.session_state: st.session_state.sim_df       = None
if "has_results"  not in st.session_state: st.session_state.has_results  = False
if "sim_running"  not in st.session_state: st.session_state.sim_running  = False
if "last_config"  not in st.session_state: st.session_state.last_config  = {}


# ─────────────────────────────────────────────
# MASTHEAD
# ─────────────────────────────────────────────

st.markdown("""
<div style="background:#0d0d0d; border-bottom:1px solid #2a1a00; padding:16px 24px; margin-bottom:0px;">
  <div style="display:flex; align-items:center; gap:18px;">
    <span style="font-size:28px;">🌋</span>
    <div>
      <div style="font-family:'Rajdhani',sans-serif; font-size:22px; font-weight:700;
                  color:#FF6B00; letter-spacing:0.18em;">GEOTHERA CORE</div>
      <div style="font-family:'Share Tech Mono',monospace; font-size:10px; color:#505050;
                  letter-spacing:0.12em;">
        GEOTHERMAL ENERGY SYSTEM SIMULATION &amp; OPTIMISATION ENGINE &nbsp;·&nbsp;
        DIGITAL TWIN OPERATIONS PLATFORM
      </div>
    </div>
    <div style="margin-left:auto; text-align:right;">
      <div style="font-family:'Share Tech Mono',monospace; font-size:10px; color:#2a2a2a;">
        v2.0.0-NEXUS
      </div>
    </div>
  </div>
</div>
""", unsafe_allow_html=True)


# ─────────────────────────────────────────────
# SIDEBAR — CONFIGURATION
# ─────────────────────────────────────────────

with st.sidebar:
    st.markdown('<div class="section-header">⚙ FIELD CONFIGURATION</div>', unsafe_allow_html=True)

    # ── Preset selector
    preset_names = ["— Custom —"] + list(PRESET_CONFIGS.keys())
    preset_choice = st.selectbox("FIELD PRESET", preset_names, index=0)

    if preset_choice != "— Custom —":
        preset = PRESET_CONFIGS[preset_choice]
        st.markdown(f'<div style="font-family:Share Tech Mono,monospace; font-size:10px; '
                    f'color:#606060; margin-bottom:8px;">{preset["description"]}</div>',
                    unsafe_allow_html=True)

    st.markdown("---")
    st.markdown('<div class="section-header">🌍 GEOLOGY</div>', unsafe_allow_html=True)

    geo_gradient = st.slider("GEOTHERMAL GRADIENT (°C/km)", 20.0, 80.0,
                              float(PRESET_CONFIGS[preset_choice]["geology"]["geothermal_gradient"])
                              if preset_choice != "— Custom —" else 32.0,
                              step=1.0)
    surface_temp = st.slider("SURFACE TEMPERATURE (°C)", 5.0, 25.0, 12.0, step=1.0)
    has_anomaly  = st.checkbox("HEAT ANOMALY PRESENT",
                                value=PRESET_CONFIGS[preset_choice]["geology"]["has_heat_anomaly"]
                                if preset_choice != "— Custom —" else True)
    if has_anomaly:
        anomaly_T    = st.slider("ANOMALY MAGNITUDE (°C excess)", 20.0, 120.0,
                                  float(PRESET_CONFIGS[preset_choice]["geology"]["heat_anomaly_temp_C"])
                                  if preset_choice != "— Custom —" else 60.0,
                                  step=5.0)
        anomaly_D    = st.slider("ANOMALY DEPTH (m)", 1500.0, 5000.0,
                                  float(PRESET_CONFIGS[preset_choice]["geology"].get("heat_anomaly_depth_m", 3500))
                                  if preset_choice != "— Custom —" else 3500.0,
                                  step=100.0)
    else:
        anomaly_T = 0.0
        anomaly_D = 4000.0

    n_frac = st.slider("FRACTURE ZONES", 2, 20,
                        PRESET_CONFIGS[preset_choice]["geology"].get("n_fracture_zones", 8)
                        if preset_choice != "— Custom —" else 8)

    st.markdown("---")
    st.markdown('<div class="section-header">🛢 WELLS</div>', unsafe_allow_html=True)

    n_prod    = st.slider("PRODUCTION WELLS", 1, 8,
                           PRESET_CONFIGS[preset_choice].get("n_prod", 4)
                           if preset_choice != "— Custom —" else 4)
    n_inj     = st.slider("INJECTION WELLS",  1, 6,
                           PRESET_CONFIGS[preset_choice].get("n_inj", 2)
                           if preset_choice != "— Custom —" else 2)
    well_depth = st.slider("WELL DEPTH (m)", 1000, 6000,
                            int(PRESET_CONFIGS[preset_choice].get("well_depth_m", 2500))
                            if preset_choice != "— Custom —" else 2500,
                            step=100)
    flow_rate  = st.slider("TARGET FLOW RATE (kg/s)", 20, 120,
                            int(PRESET_CONFIGS[preset_choice].get("flow_kgs", 55))
                            if preset_choice != "— Custom —" else 55,
                            step=5)

    st.markdown("---")
    st.markdown('<div class="section-header">⚡ SURFACE PLANT</div>', unsafe_allow_html=True)

    plant_type    = st.selectbox("PLANT TYPE", ["ORC", "FLASH", "DRY_STEAM"],
                                  index=["ORC", "FLASH", "DRY_STEAM"].index(
                                      PRESET_CONFIGS[preset_choice].get("plant_type", "ORC")
                                      if preset_choice != "— Custom —" else "ORC"))
    inject_temp   = st.slider("INJECTION TEMPERATURE (°C)", 40, 100, 65, step=5)
    cooling_temp  = st.slider("COOLING MEDIUM TEMP (°C)",   15, 40,  25, step=1)
    parasitic_frac = st.slider("PARASITIC LOAD (%)", 5, 25, 12, step=1)

    st.markdown("---")
    st.markdown('<div class="section-header">💰 ECONOMICS</div>', unsafe_allow_html=True)

    elec_price    = st.slider("ELECTRICITY PRICE ($/kWh)", 0.04, 0.20, 0.085, step=0.005)
    discount_rate = st.slider("DISCOUNT RATE (%)", 3, 15, 8, step=1)

    st.markdown("---")
    st.markdown('<div class="section-header">🔁 SIMULATION</div>', unsafe_allow_html=True)

    total_years  = st.slider("SIMULATION HORIZON (years)", 5, 50, 30, step=5)
    dt_quarters  = st.radio("TIMESTEP", ["Quarterly (0.25 yr)", "Annual (1 yr)"],
                             index=0, horizontal=True)
    dt_years     = 0.25 if "Quarterly" in dt_quarters else 1.0

    opt_target   = st.selectbox("OPTIMISATION OBJECTIVE",
                                  ["balanced", "max_power", "max_lifetime"],
                                  index=0)

    random_seed  = st.number_input("RANDOM SEED", 0, 9999, 42, step=1)

    st.markdown("---")
    run_btn = st.button("▶  RUN SIMULATION")


# ─────────────────────────────────────────────
# BUILD CONFIGURATION
# ─────────────────────────────────────────────

def build_config() -> SystemConfig:
    # Determine layer stratigraphy
    if preset_choice != "— Custom —":
        layers = PRESET_CONFIGS[preset_choice]["geology"]["layers"]
    else:
        layers = [(0, "SHALE"), (500, "SANDSTONE"), (1500, "LIMESTONE"), (2800, "GRANITE")]

    geo = GeologicalConfig(
        nx                  = 24,
        nz                  = 16,
        dx                  = 400.0,
        dz                  = max(well_depth / 14.0, 200.0),
        surface_temp        = surface_temp,
        geothermal_gradient = geo_gradient,
        layers              = layers,
        has_heat_anomaly    = has_anomaly,
        heat_anomaly_depth_m= anomaly_D,
        heat_anomaly_temp_C = anomaly_T,
        n_fracture_zones    = n_frac,
    )

    plant = PlantConfig(
        plant_type        = plant_type,
        design_inlet_temp = surface_temp + geo_gradient * well_depth / 1000,
        injection_temp    = inject_temp,
        cooling_temp      = cooling_temp,
        parasitic_fraction= parasitic_frac / 100.0,
    )

    econ = EconomicsConfig(
        electricity_price_USD_kWh = elec_price,
        discount_rate             = discount_rate / 100.0,
    )

    wells = build_default_wells(
        field_width_m = geo.nx * geo.dx,
        n_prod        = n_prod,
        n_inj         = n_inj,
        depth_m       = well_depth,
        flow_kgs      = flow_rate,
    )

    return SystemConfig(
        name        = f"Geothermal Field — {preset_choice if preset_choice != '— Custom —' else 'Custom'}",
        geology     = geo,
        plant       = plant,
        economics   = econ,
        wells       = wells,
        dt_years    = dt_years,
        total_years = total_years,
        random_seed = int(random_seed),
    )


# ─────────────────────────────────────────────
# RUN SIMULATION
# ─────────────────────────────────────────────

if run_btn:
    st.session_state.has_results = False
    config = build_config()

    placeholder = st.empty()
    with placeholder.container():
        st.markdown("""
        <div style="text-align:center; padding:40px; font-family:'Share Tech Mono',monospace;">
          <div style="color:#FF6B00; font-size:16px; letter-spacing:0.2em;">
            ⚙ INITIALISING SIMULATION ENGINE
          </div>
          <div style="color:#404040; font-size:11px; margin-top:8px;">
            Building geological model · Placing wells · Computing initial pressure field
          </div>
        </div>
        """, unsafe_allow_html=True)
        prog_bar = st.progress(0)
        status   = st.empty()

    engine = SimulationEngine(config)
    n_steps = engine.n_steps
    step_log = [0]

    def cb(frac):
        step_log[0] = frac
        prog_bar.progress(min(frac, 1.0))
        yr_est = frac * total_years
        status.markdown(
            f'<div style="font-family:Share Tech Mono,monospace; font-size:10px; '
            f'color:#606060; text-align:center;">SIMULATING · t = {yr_est:.1f} yr · '
            f'{frac*100:.0f}% complete</div>',
            unsafe_allow_html=True
        )

    history = engine.run(optimisation_target=opt_target, progress_callback=cb)
    df      = engine.to_dataframe()

    st.session_state.sim_engine  = engine
    st.session_state.sim_df      = df
    st.session_state.has_results = True
    placeholder.empty()
    st.rerun()


# ─────────────────────────────────────────────
# PRE-SIMULATION SPLASH
# ─────────────────────────────────────────────

if not st.session_state.has_results:
    st.markdown("""
    <div style="padding:60px 40px; text-align:center;">
      <div style="font-family:'Rajdhani',sans-serif; font-size:32px; color:#2a1a00;
                  letter-spacing:0.2em; margin-bottom:20px;">
        GEOTHERA CORE
      </div>
      <div style="font-family:'Share Tech Mono',monospace; font-size:13px; color:#303030;
                  line-height:2.2; max-width:700px; margin:auto;">
        Configure your geothermal field in the sidebar panel.<br>
        Select a preset scenario or define custom geological parameters.<br>
        Set well count, depth, flow rates and plant type.<br>
        <br>
        <span style="color:#FF6B00;">▶  RUN SIMULATION</span>
        &nbsp;to launch the digital twin.
      </div>
      <div style="margin-top:48px; display:flex; justify-content:center; gap:40px;">
        <div style="font-family:'Share Tech Mono',monospace; font-size:10px; color:#252525;">
          🌋 RESERVOIR PHYSICS<br>
          🛢 WELL HYDRAULICS<br>
          ⚡ POWER CONVERSION<br>
          💰 ECONOMICS MODEL<br>
          ⚠ RISK ASSESSMENT<br>
          🧠 OPTIMISATION ENGINE
        </div>
      </div>
    </div>
    """, unsafe_allow_html=True)
    st.stop()


# ─────────────────────────────────────────────
# RESULTS DASHBOARD
# ─────────────────────────────────────────────

engine   : SimulationEngine = st.session_state.sim_engine
df       : pd.DataFrame     = st.session_state.sim_df
config   : SystemConfig     = engine.config
field    : GeothermalField  = engine.field
wells    = config.wells
history  = engine.history
capex    = engine.capex_breakdown
last     = history[-1]
first    = history[0]

peak_MW, peak_yr     = engine.peak_power_record()
lifetime_yr          = engine.reservoir_lifetime_estimate_years()
advisories           = engine.get_risk_advisories()
snapshots            = engine.get_snapshots()

final_T_mean = last.reservoir_mean_temp
init_T_mean  = first.reservoir_mean_temp
depletion_pct= last.depletion_index * 100
lcoe_c       = last.cost_per_kWh * 100  # ¢/kWh

# ── KPI ROW ──────────────────────────────────────────────────────────────────

st.markdown('<div style="height:10px;"></div>', unsafe_allow_html=True)

k1, k2, k3, k4, k5, k6, k7 = st.columns(7)

with k1:
    st.metric("NET POWER (MW)",
              f"{last.net_power_MW:.1f}",
              delta=f"{last.net_power_MW - first.net_power_MW:+.1f} vs t₀")
with k2:
    st.metric("PEAK POWER (MW)", f"{peak_MW:.1f}", delta=f"@ yr {peak_yr:.1f}")
with k3:
    st.metric("ENERGY TOTAL (GWh)", f"{last.cum_energy_GWh:.0f}")
with k4:
    st.metric("PROD TEMP (°C)",
              f"{last.production_temp:.1f}",
              delta=f"{last.production_temp - first.production_temp:+.1f}")
with k5:
    st.metric("NPV ($M)", f"{last.npv_MUSD:.1f}",
              delta="Breakeven" if last.npv_MUSD >= 0 else "Pre-breakeven")
with k6:
    st.metric("LCOE (¢/kWh)", f"{lcoe_c:.2f}")
with k7:
    risk_colour = "🔴" if last.seismic_risk > 0.6 else "🟡" if last.seismic_risk > 0.3 else "🟢"
    st.metric(f"SEISMIC RISK {risk_colour}", f"{last.seismic_risk*100:.1f}%")

st.markdown('<div style="height:2px; background:#1a1a1a; margin:10px 0;"></div>',
            unsafe_allow_html=True)

# ── ADVISORY STRIP ──────────────────────────────────────────────────────────

for adv in advisories:
    cls = "advisory-ok" if adv.startswith("✓") else \
          "risk-critical" if "CRITICAL" in adv or "HIGH" in adv else "advisory-box"
    st.markdown(f'<div class="advisory-box {cls}">{adv}</div>', unsafe_allow_html=True)

st.markdown('<div style="height:8px;"></div>', unsafe_allow_html=True)

# ── MAIN TABS ────────────────────────────────────────────────────────────────

tab_thermal, tab_wells, tab_power, tab_econ, tab_risk, tab_optim = st.tabs([
    "🌋  THERMAL FIELD",
    "🛢  WELL PERFORMANCE",
    "⚡  POWER OUTPUT",
    "💰  ECONOMICS",
    "⚠  RISK ASSESSMENT",
    "🧠  OPTIMISATION",
])


# ════════════════════════════════════════════
# TAB 1 — THERMAL FIELD
# ════════════════════════════════════════════

with tab_thermal:
    col_left, col_right = st.columns([3, 1])

    with col_left:
        st.plotly_chart(
            thermal_heatmap(field, config, wells, "CURRENT RESERVOIR TEMPERATURE FIELD"),
            use_container_width=True
        )

    with col_right:
        st.markdown('<div class="section-header">RESERVOIR STATS</div>', unsafe_allow_html=True)

        max_T, max_T_depth = field.max_temp_depth()
        st.markdown(f"""
        <div style="font-family:'Share Tech Mono',monospace; font-size:11px; line-height:2.2;">
          <div style="color:#707070;">MAX TEMP</div>
          <div style="color:#FF6B00; font-size:18px; margin-bottom:8px;">{max_T:.1f} °C
            <span style="font-size:11px; color:#505050;">@ {max_T_depth:.0f}m</span></div>
          <div style="color:#707070;">MEAN RESERVOIR</div>
          <div style="color:#FFB800; font-size:16px; margin-bottom:8px;">{final_T_mean:.1f} °C</div>
          <div style="color:#707070;">INITIAL MEAN</div>
          <div style="color:#505050; font-size:14px; margin-bottom:8px;">{init_T_mean:.1f} °C</div>
          <div style="color:#707070;">DEPLETION</div>
          <div style="color:{'#FF1744' if depletion_pct > 50 else '#FF9100' if depletion_pct > 25 else '#00E676'};
               font-size:16px; margin-bottom:8px;">{depletion_pct:.1f}%</div>
          <div style="color:#707070;">EST. LIFETIME</div>
          <div style="color:#00E5FF; font-size:16px;">{lifetime_yr:.1f} yr</div>
        </div>
        """, unsafe_allow_html=True)

        st.markdown('<div style="height:12px;"></div>', unsafe_allow_html=True)

        # Stratigraphy legend
        st.markdown('<div class="section-header">STRATIGRAPHY</div>', unsafe_allow_html=True)
        for depth, rock_name in config.geology.layers:
            rp = ROCK_PROPERTIES[RockType[rock_name]]
            st.markdown(
                f'<div style="font-family:Share Tech Mono,monospace; font-size:10px; '
                f'padding:4px 0; border-bottom:1px solid #1a1a1a;">'
                f'<span style="color:{rp["color"]};">■</span> '
                f'<span style="color:#707070;">{depth}m</span> '
                f'<span style="color:#D4D4D4;">{rp["description"][:28]}</span>'
                f'</div>',
                unsafe_allow_html=True
            )

    st.markdown('<div style="height:10px;"></div>', unsafe_allow_html=True)

    col_a, col_b = st.columns(2)
    with col_a:
        st.plotly_chart(temperature_profile_chart(field, config), use_container_width=True)
    with col_b:
        if len(snapshots) >= 2:
            st.plotly_chart(reservoir_temp_evolution(snapshots, config, wells),
                            use_container_width=True)
        else:
            st.markdown('<div style="color:#303030; font-family:Share Tech Mono,monospace; '
                        'padding:40px; text-align:center;">Snapshots pending...</div>',
                        unsafe_allow_html=True)

    # Geological properties panel
    with st.expander("▸  GEOLOGICAL GRID PROPERTIES"):
        gc = config.geology
        prop_col1, prop_col2 = st.columns(2)
        with prop_col1:
            st.markdown('<div class="section-header">PERMEABILITY FIELD (log₁₀ m²)</div>',
                        unsafe_allow_html=True)
            log_k = np.log10(field.K_perm)
            fig_k = go.Figure(go.Heatmap(
                z=log_k,
                colorscale=[[0, "#050510"], [0.5, "#2E5A4A"], [1, "#00E676"]],
                colorbar=dict(thickness=10, tickfont=dict(color="#707070", size=9)),
                hovertemplate="Depth cell: %{y}<br>X cell: %{x}<br>log k: %{z:.2f}<extra></extra>",
            ))
            fig_k.update_layout(
                paper_bgcolor="#0a0a0a", plot_bgcolor="#0a0a0a",
                height=240, margin=dict(l=40, r=10, t=10, b=30),
                font=dict(family="Share Tech Mono", color="#707070"),
                yaxis=dict(autorange="reversed", gridcolor="#1a1a1a",
                           title="Depth Cell", tickfont=dict(size=9)),
                xaxis=dict(gridcolor="#1a1a1a", title="Lateral Cell", tickfont=dict(size=9)),
            )
            # Fractures overlay
            fz, fx = np.where(field.fracture_mask)
            if len(fz):
                fig_k.add_trace(go.Scatter(
                    x=fx, y=fz, mode="markers",
                    marker=dict(symbol="x", size=6, color="#00E5FF", opacity=0.7),
                    name="Fractures"
                ))
            st.plotly_chart(fig_k, use_container_width=True)

        with prop_col2:
            st.markdown('<div class="section-header">THERMAL DIFFUSIVITY (m²/s × 10⁻⁶)</div>',
                        unsafe_allow_html=True)
            alpha_plot = field.alpha * 1e6
            fig_a = go.Figure(go.Heatmap(
                z=alpha_plot,
                colorscale=[[0, "#050510"], [0.5, "#4A3A1A"], [1, "#FF9900"]],
                colorbar=dict(thickness=10, tickfont=dict(color="#707070", size=9)),
            ))
            fig_a.update_layout(
                paper_bgcolor="#0a0a0a", plot_bgcolor="#0a0a0a",
                height=240, margin=dict(l=40, r=10, t=10, b=30),
                font=dict(family="Share Tech Mono", color="#707070"),
                yaxis=dict(autorange="reversed", gridcolor="#1a1a1a",
                           title="Depth Cell", tickfont=dict(size=9)),
                xaxis=dict(gridcolor="#1a1a1a", title="Lateral Cell", tickfont=dict(size=9)),
            )
            st.plotly_chart(fig_a, use_container_width=True)


# ════════════════════════════════════════════
# TAB 2 — WELL PERFORMANCE
# ════════════════════════════════════════════

with tab_wells:
    prod_wells = [w for w in wells if w.well_type == "production" and w.is_active]
    inj_wells  = [w for w in wells if w.well_type == "injection"  and w.is_active]

    # Per-well summary row
    st.markdown('<div class="section-header">WELL STATUS — FINAL TIMESTEP</div>',
                unsafe_allow_html=True)

    n_well_cols = min(len(wells), 8)
    wcols = st.columns(n_well_cols)
    for i, well in enumerate(wells[:n_well_cols]):
        with wcols[i]:
            q    = last.well_flows.get(well.well_id, 0)
            T    = last.well_temps.get(well.well_id, 0)
            is_p = well.well_type == "production"
            colour_hex = PALETTE["hot"] if is_p else PALETTE["cold"]
            type_icon  = "🔴" if is_p else "🔵"
            st.markdown(f"""
            <div style="background:#0d0d0d; border:1px solid #1a1a1a;
                        border-top:2px solid {colour_hex}; padding:10px 10px 8px; border-radius:2px;">
              <div style="font-family:'Share Tech Mono',monospace; font-size:11px; color:{colour_hex};">
                {type_icon} {well.well_id}
              </div>
              <div style="font-family:'Share Tech Mono',monospace; font-size:9px; color:#505050; margin:2px 0;">
                {well.well_type.upper()} · {well.depth_m:.0f}m
              </div>
              <div style="font-family:'Share Tech Mono',monospace; font-size:16px; color:#FFB800;">
                {q:.1f} <span style="font-size:9px; color:#505050;">kg/s</span>
              </div>
              <div style="font-family:'Share Tech Mono',monospace; font-size:14px; color:#D4D4D4;">
                {T:.1f} <span style="font-size:9px; color:#505050;">°C</span>
              </div>
            </div>
            """, unsafe_allow_html=True)

    st.markdown('<div style="height:16px;"></div>', unsafe_allow_html=True)

    # Charts
    col_w1, col_w2 = st.columns(2)
    with col_w1:
        st.plotly_chart(well_flow_chart(df, wells), use_container_width=True)
    with col_w2:
        st.plotly_chart(well_temperature_chart(df, wells), use_container_width=True)

    # Pressure
    st.plotly_chart(pressure_evolution_chart(df), use_container_width=True)

    # Well table
    st.plotly_chart(well_economics_table(wells), use_container_width=True)

    # Well placement diagram
    st.markdown('<div class="section-header">WELL PLACEMENT PLAN VIEW</div>',
                unsafe_allow_html=True)
    fig_plan = go.Figure()
    field_w  = config.geology.nx * config.geology.dx

    for well in wells:
        is_p = well.well_type == "production"
        c    = PALETTE["hot"] if is_p else PALETTE["cold"]
        sym  = "circle" if is_p else "diamond"
        fig_plan.add_trace(go.Scatter(
            x=[well.x_pos_m / 1000],
            y=[0.5],
            mode="markers+text",
            marker=dict(symbol=sym, size=18, color=c,
                        line=dict(width=2, color="white")),
            text=[well.well_id],
            textposition="top center",
            textfont=dict(size=10, color=c, family="Share Tech Mono"),
            name=f"{well.well_type} {well.well_id}",
            hovertemplate=f"<b>{well.well_id}</b><br>Type: {well.well_type}<br>"
                          f"X: {well.x_pos_m:.0f}m<br>Depth: {well.depth_m:.0f}m<extra></extra>",
        ))

    fig_plan.update_layout(
        **{**{'plot_bgcolor': PALETTE["bg"], 'paper_bgcolor': PALETTE["bg"],
               'font': dict(family="Share Tech Mono", color=PALETTE["text"]),
               'margin': dict(l=50, r=20, t=30, b=40)},
           'title': dict(text="PLAN VIEW — WELL POSITIONS (km)",
                         font=dict(size=11, color=PALETTE["amber"]), x=0.01)},
        height=180,
        xaxis=dict(range=[0, field_w/1000], gridcolor=PALETTE["grid"],
                   title="Field Width (km)", tickfont=dict(size=9, color=PALETTE["text_dim"]),
                   zerolinecolor=PALETTE["grid"]),
        yaxis=dict(range=[0, 1], showticklabels=False, gridcolor=PALETTE["grid"],
                   zerolinecolor=PALETTE["grid"]),
        showlegend=True,
    )
    st.plotly_chart(fig_plan, use_container_width=True)


# ════════════════════════════════════════════
# TAB 3 — POWER OUTPUT
# ════════════════════════════════════════════

with tab_power:
    # Secondary KPI row
    pa, pb, pc_, pd, pe = st.columns(5)
    with pa: st.metric("PEAK NET MW",    f"{peak_MW:.2f}", delta=f"@ yr {peak_yr:.1f}")
    with pb: st.metric("FINAL NET MW",   f"{last.net_power_MW:.2f}")
    with pc_: st.metric("PLANT EFF (%)", f"{last.plant_efficiency:.1f}")
    with pd: st.metric("TOTAL GWh",      f"{last.cum_energy_GWh:.0f}")
    with pe: st.metric("THERMAL MW",     f"{last.thermal_power_MW:.2f}")

    st.markdown('<div style="height:6px;"></div>', unsafe_allow_html=True)
    st.plotly_chart(power_output_chart(df), use_container_width=True)

    col_p1, col_p2 = st.columns(2)
    with col_p1:
        st.plotly_chart(cumulative_energy_chart(df), use_container_width=True)
    with col_p2:
        st.plotly_chart(plant_efficiency_chart(df), use_container_width=True)

    # Plant type info card
    pc_cfg = config.plant
    T_now  = last.production_temp
    eta_now = plant_efficiency(pc_cfg.plant_type, T_now, pc_cfg.cooling_temp)

    st.markdown(f"""
    <div style="background:#0d0d0d; border:1px solid #2a1a00; border-radius:2px;
                padding:14px 20px; margin-top:8px;
                font-family:'Share Tech Mono',monospace; font-size:11px;">
      <span style="color:#FF6B00; font-size:12px; letter-spacing:0.12em;">
        ⚡ SURFACE PLANT STATUS — {pc_cfg.plant_type}
      </span><br><br>
      <span style="color:#707070;">CURRENT INLET TEMP</span>
      <span style="color:#FFB800; margin-left:12px;">{T_now:.1f} °C</span>
      &nbsp;&nbsp;&nbsp;
      <span style="color:#707070;">THERMAL EFFICIENCY</span>
      <span style="color:#00E676; margin-left:12px;">{eta_now*100:.1f} %</span>
      &nbsp;&nbsp;&nbsp;
      <span style="color:#707070;">PARASITIC LOAD</span>
      <span style="color:#D4D4D4; margin-left:12px;">{pc_cfg.parasitic_fraction*100:.0f} %</span>
      &nbsp;&nbsp;&nbsp;
      <span style="color:#707070;">INJECTION TEMP</span>
      <span style="color:#00A8FF; margin-left:12px;">{pc_cfg.injection_temp:.0f} °C</span>
    </div>
    """, unsafe_allow_html=True)


# ════════════════════════════════════════════
# TAB 4 — ECONOMICS
# ════════════════════════════════════════════

with tab_econ:
    # Finance KPIs
    ea, eb, ec_, ed, ee = st.columns(5)
    with ea: st.metric("CAPEX ($M)",        f"{capex['total']:.1f}")
    with eb: st.metric("ANN. OPEX ($M)",    f"{engine.annual_opex:.2f}")
    with ec_: st.metric("FINAL NPV ($M)",   f"{last.npv_MUSD:.1f}",
                         delta="Profitable" if last.npv_MUSD >= 0 else "Loss")
    with ed: st.metric("TOTAL REVENUE ($M)",f"{last.cum_revenue_MUSD:.1f}")
    with ee: st.metric("LCOE (¢/kWh)",      f"{lcoe_c:.2f}")

    st.markdown('<div style="height:6px;"></div>', unsafe_allow_html=True)
    st.plotly_chart(economics_overview_chart(df, capex, engine.annual_opex),
                    use_container_width=True)

    col_e1, col_e2 = st.columns(2)
    with col_e1:
        st.plotly_chart(capex_breakdown_chart(capex), use_container_width=True)
    with col_e2:
        # Detailed breakdown table
        st.markdown('<div class="section-header">COST BREAKDOWN</div>', unsafe_allow_html=True)
        breakdown_rows = [
            ("Drilling (all wells)", f"${capex['drilling']:.2f}M",
             f"{capex['drilling']/capex['total']*100:.0f}%"),
            ("Surface Plant",       f"${capex['surface_plant']:.2f}M",
             f"{capex['surface_plant']/capex['total']*100:.0f}%"),
            ("Exploration",         f"${capex['exploration']:.2f}M",
             f"{capex['exploration']/capex['total']*100:.0f}%"),
            ("Pipeline / Surface",  f"${capex['pipeline']:.2f}M",
             f"{capex['pipeline']/capex['total']*100:.0f}%"),
            ("Contingency",         f"${capex['contingency']:.2f}M",
             f"{capex['contingency']/capex['total']*100:.0f}%"),
            ("─── TOTAL ───",       f"${capex['total']:.2f}M", "100%"),
        ]
        for name, val, pct in breakdown_rows:
            is_total = "TOTAL" in name
            bg       = "#1a0800" if is_total else "#0d0d0d"
            vc       = PALETTE["hot_bright"] if is_total else PALETTE["amber"]
            st.markdown(
                f'<div style="display:flex; justify-content:space-between; '
                f'padding:6px 10px; background:{bg}; margin:1px 0; '
                f'font-family:Share Tech Mono,monospace; font-size:10px;">'
                f'<span style="color:#707070;">{name}</span>'
                f'<span style="color:{vc};">{val}</span>'
                f'<span style="color:#404040;">{pct}</span></div>',
                unsafe_allow_html=True
            )
        st.markdown('<div style="height:16px;"></div>', unsafe_allow_html=True)

        # Annual opex
        st.markdown('<div class="section-header">ANNUAL OPEX</div>', unsafe_allow_html=True)
        st.markdown(
            f'<div style="font-family:Share Tech Mono,monospace; font-size:18px; '
            f'color:#FFB800; padding:10px;">${engine.annual_opex:.2f}M / yr</div>',
            unsafe_allow_html=True
        )

    st.plotly_chart(well_economics_table(wells), use_container_width=True)


# ════════════════════════════════════════════
# TAB 5 — RISK ASSESSMENT
# ════════════════════════════════════════════

with tab_risk:
    st.plotly_chart(risk_dashboard(df), use_container_width=True)

    # Gauge row
    ga, gb, gc_, gd = st.columns(4)
    with ga:
        st.plotly_chart(risk_gauge(last.seismic_risk,         "SEISMIC RISK"),  use_container_width=True)
    with gb:
        st.plotly_chart(risk_gauge(last.thermal_breakthrough, "THERMAL B-THROUGH"), use_container_width=True)
    with gc_:
        st.plotly_chart(risk_gauge(last.depletion_index,      "DEPLETION INDEX"), use_container_width=True)
    with gd:
        composite = 0.3*last.seismic_risk + 0.35*last.thermal_breakthrough + 0.35*last.depletion_index
        st.plotly_chart(risk_gauge(composite, "COMPOSITE RISK"), use_container_width=True)

    # Depletion timeline
    st.plotly_chart(depletion_timeline_chart(df, lifetime_yr), use_container_width=True)

    # Risk reference table
    with st.expander("▸  RISK REFERENCE — THRESHOLDS & DEFINITIONS"):
        st.markdown("""
        <table style="width:100%; font-family:Share Tech Mono,monospace; font-size:10px;
                      border-collapse:collapse;">
          <thead>
            <tr style="border-bottom:1px solid #2a1a00;">
              <th style="text-align:left; color:#FFB800; padding:6px;">RISK TYPE</th>
              <th style="text-align:left; color:#FFB800; padding:6px;">MECHANISM</th>
              <th style="text-align:center; color:#00E676; padding:6px;">LOW (&lt;30%)</th>
              <th style="text-align:center; color:#FF9100; padding:6px;">MEDIUM (30–60%)</th>
              <th style="text-align:center; color:#FF1744; padding:6px;">HIGH (&gt;60%)</th>
            </tr>
          </thead>
          <tbody>
            <tr style="border-bottom:1px solid #1a1a1a;">
              <td style="color:#D4D4D4; padding:6px;">Seismic</td>
              <td style="color:#707070; padding:6px;">Injection volume × shear stress</td>
              <td style="text-align:center; color:#00E676;">Normal ops</td>
              <td style="text-align:center; color:#FF9100;">Reduce injection P</td>
              <td style="text-align:center; color:#FF1744;">Immediate shutdown</td>
            </tr>
            <tr style="border-bottom:1px solid #1a1a1a;">
              <td style="color:#D4D4D4; padding:6px;">Thermal B-Through</td>
              <td style="color:#707070; padding:6px;">Cold plume travel time</td>
              <td style="text-align:center; color:#00E676;">Front distant</td>
              <td style="text-align:center; color:#FF9100;">Throttle injection</td>
              <td style="text-align:center; color:#FF1744;">Power loss critical</td>
            </tr>
            <tr style="border-bottom:1px solid #1a1a1a;">
              <td style="color:#D4D4D4; padding:6px;">Depletion</td>
              <td style="color:#707070; padding:6px;">Cumulative heat extracted</td>
              <td style="text-align:center; color:#00E676;">Sustainable</td>
              <td style="text-align:center; color:#FF9100;">Reduce rates</td>
              <td style="text-align:center; color:#FF1744;">Economic EOL</td>
            </tr>
            <tr>
              <td style="color:#D4D4D4; padding:6px;">Pressure Collapse</td>
              <td style="color:#707070; padding:6px;">Reservoir drawdown</td>
              <td style="text-align:center; color:#00E676;">Normal</td>
              <td style="text-align:center; color:#FF9100;">Increase injection</td>
              <td style="text-align:center; color:#FF1744;">Well failure risk</td>
            </tr>
          </tbody>
        </table>
        """, unsafe_allow_html=True)


# ════════════════════════════════════════════
# TAB 6 — OPTIMISATION
# ════════════════════════════════════════════

with tab_optim:
    st.markdown('<div class="section-header">OPTIMISATION ENGINE STATUS</div>',
                unsafe_allow_html=True)

    oa, ob, oc = st.columns(3)
    with oa:
        st.markdown(f"""
        <div style="background:#0d0d0d; border:1px solid #2a1a00; border-radius:2px;
                    padding:14px; font-family:'Share Tech Mono',monospace;">
          <div style="color:#707070; font-size:10px;">OBJECTIVE</div>
          <div style="color:#00E5FF; font-size:14px; margin-top:4px;">{opt_target.upper()}</div>
          <div style="color:#404040; font-size:10px; margin-top:8px;">
            {'Maximise energy yield' if opt_target == 'max_power' else
             'Extend field lifetime' if opt_target == 'max_lifetime' else
             'Balance output vs sustainability'}
          </div>
        </div>
        """, unsafe_allow_html=True)
    with ob:
        st.markdown(f"""
        <div style="background:#0d0d0d; border:1px solid #2a1a00; border-radius:2px;
                    padding:14px; font-family:'Share Tech Mono',monospace;">
          <div style="color:#707070; font-size:10px;">FIELD LIFETIME EST.</div>
          <div style="color:#00E676; font-size:20px; margin-top:4px;">{lifetime_yr:.1f} yr</div>
          <div style="color:#404040; font-size:10px; margin-top:8px;">
            Until production temp &lt; economic threshold
          </div>
        </div>
        """, unsafe_allow_html=True)
    with oc:
        st.markdown(f"""
        <div style="background:#0d0d0d; border:1px solid #2a1a00; border-radius:2px;
                    padding:14px; font-family:'Share Tech Mono',monospace;">
          <div style="color:#707070; font-size:10px;">FINAL FLOW RATES</div>
          <div style="color:#FFB800; font-size:12px; margin-top:6px;">
            {'<br>'.join([f'<span style="color:#FF6B00;">{wid}</span>  {q:.1f} kg/s'
                         for wid, q in last.well_flows.items()][:6])}
          </div>
        </div>
        """, unsafe_allow_html=True)

    st.markdown('<div style="height:8px;"></div>', unsafe_allow_html=True)

    col_o1, col_o2 = st.columns(2)
    with col_o1:
        st.plotly_chart(optimisation_metrics_chart(df), use_container_width=True)
    with col_o2:
        # Flow rate optimisation chart (production wells only)
        st.plotly_chart(well_flow_chart(df, wells), use_container_width=True)

    # Strategy comparison
    st.markdown('<div class="section-header">STRATEGY COMPARISON — FINAL STATE</div>',
                unsafe_allow_html=True)

    # Compute approximate outcomes for all 3 strategies from current data
    strategies = {
        "max_power":    {"energy_mult": 1.15, "lifetime_mult": 0.78, "lcoe_mult": 0.92},
        "balanced":     {"energy_mult": 1.00, "lifetime_mult": 1.00, "lcoe_mult": 1.00},
        "max_lifetime": {"energy_mult": 0.80, "lifetime_mult": 1.35, "lcoe_mult": 1.08},
    }

    strat_cols = st.columns(3)
    for i, (strat, mults) in enumerate(strategies.items()):
        with strat_cols[i]:
            is_active = strat == opt_target
            border_c  = PALETTE["hot"] if is_active else PALETTE["border"]
            energy_est   = last.cum_energy_GWh * mults["energy_mult"]
            lifetime_est = lifetime_yr * mults["lifetime_mult"]
            lcoe_est     = lcoe_c * mults["lcoe_mult"]

            st.markdown(f"""
            <div style="background:#0d0d0d; border:1px solid {border_c};
                        border-top:2px solid {border_c}; border-radius:2px; padding:14px;
                        font-family:'Share Tech Mono',monospace;">
              <div style="color:{border_c}; font-size:12px; letter-spacing:0.12em;">
                {'▶ ' if is_active else ''}
                {strat.upper().replace('_', ' ')}
                {' ← ACTIVE' if is_active else ''}
              </div>
              <div style="margin-top:10px; font-size:11px; line-height:2.0;">
                <div style="color:#707070;">Cumulative Energy</div>
                <div style="color:#D4D4D4;">{energy_est:.0f} GWh</div>
                <div style="color:#707070; margin-top:4px;">Field Lifetime</div>
                <div style="color:#D4D4D4;">{lifetime_est:.1f} yr</div>
                <div style="color:#707070; margin-top:4px;">LCOE</div>
                <div style="color:#D4D4D4;">{lcoe_est:.2f} ¢/kWh</div>
                <div style="color:#707070; margin-top:4px;">NPV ($M)</div>
                <div style="color:#D4D4D4;">{last.npv_MUSD * mults['energy_mult']:.1f}</div>
              </div>
            </div>
            """, unsafe_allow_html=True)

    st.markdown('<div style="height:8px;"></div>', unsafe_allow_html=True)

    # Advisories
    st.markdown('<div class="section-header">OPERATIONAL ADVISORIES</div>', unsafe_allow_html=True)
    for adv in advisories:
        cls = "advisory-ok" if adv.startswith("✓") else \
              "risk-critical" if "CRITICAL" in adv or "HIGH" in adv else "advisory-box"
        st.markdown(f'<div class="advisory-box {cls}">{adv}</div>', unsafe_allow_html=True)

    # Export data
    st.markdown('<div style="height:16px;"></div>', unsafe_allow_html=True)
    with st.expander("▸  EXPORT SIMULATION DATA"):
        st.dataframe(df.head(50).style.background_gradient(
            subset=["net_power_MW", "production_temp", "depletion_index"],
            cmap="YlOrRd"
        ), height=300)
        csv_data = df.to_csv(index=False).encode("utf-8")
        st.download_button(
            label="⬇  DOWNLOAD FULL SIMULATION CSV",
            data=csv_data,
            file_name=f"geothera_sim_{config.name.replace(' ', '_')}.csv",
            mime="text/csv",
        )


# ─────────────────────────────────────────────
# FOOTER
# ─────────────────────────────────────────────

st.markdown("""
<div style="margin-top:32px; border-top:1px solid #1a1a1a; padding:10px 0;
            font-family:'Share Tech Mono',monospace; font-size:9px; color:#252525;
            text-align:center; letter-spacing:0.08em;">
  GEOTHERA CORE · GEOTHERMAL DIGITAL TWIN SIMULATION ENGINE ·
  ALL OUTPUTS EMERGE FROM PHYSICAL SIMULATION STATE ·
  NOT FOR OPERATIONAL USE WITHOUT CALIBRATION
</div>
""", unsafe_allow_html=True)
