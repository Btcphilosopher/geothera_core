"""
GEOTHERMAL NEXUS — Simulation Engine
Timestep loop, economics, risk assessment, optimisation.
"""

import numpy as np
import pandas as pd
from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Optional
import warnings
warnings.filterwarnings("ignore")

from physics import (
    GeothermalField, SystemConfig, WellConfig, PlantConfig,
    water_density, water_enthalpy, plant_efficiency,
    ROCK_PROPERTIES, RockType
)


# ─────────────────────────────────────────────
# TIMESTEP STATE RECORD
# ─────────────────────────────────────────────

@dataclass
class TimestepState:
    """All logged quantities for one simulation timestep."""
    time_years:           float
    reservoir_mean_temp:  float   # °C
    production_temp:      float   # °C — mean over all prod wells
    injection_temp:       float   # °C
    gross_power_MW:       float   # MW electric
    net_power_MW:         float   # MW after parasitic loads
    thermal_power_MW:     float   # MW thermal extracted
    plant_efficiency:     float   # fraction (0–1)
    depletion_index:      float   # 0 = fresh, 1 = depleted
    well_flows:           Dict[str, float] = field(default_factory=dict)   # kg/s per well
    well_temps:           Dict[str, float] = field(default_factory=dict)   # °C per well
    seismic_risk:         float   = 0.0  # 0–1 normalised index
    thermal_breakthrough: float   = 0.0  # fraction of cold water returned
    pressure_mean:        float   = 0.0  # MPa
    # Cumulative
    cum_energy_GWh:       float   = 0.0
    cum_revenue_MUSD:     float   = 0.0
    # Economics
    cost_per_kWh:         float   = 0.0
    capex_MUSD:           float   = 0.0
    npv_MUSD:             float   = 0.0
    # Reservoir snapshot (serialised for later retrieval)
    T_snapshot:           Optional[np.ndarray] = None   # °C grid
    P_snapshot:           Optional[np.ndarray] = None   # MPa grid


# ─────────────────────────────────────────────
# CAPEX / OPEX ECONOMICS
# ─────────────────────────────────────────────

def compute_capex(config: SystemConfig, wells: List[WellConfig],
                  design_capacity_MW: float) -> Dict:
    ec = config.economics

    # Drilling costs: depth-dependent ($M per well)
    drill_cost = 0.0
    for w in wells:
        depth_km = w.depth_m / 1000.0
        # Empirical: ~$2M base + $1.5M/km (gets exponentially expensive > 3km)
        cost = 2.0 + 1.5 * depth_km + 0.8 * max(0, depth_km - 3.0)**2
        w.drill_cost_MUSD = round(cost, 2)
        drill_cost += cost

    surface_cost   = design_capacity_MW * ec.plant_cost_MUSD_per_MW
    exploration    = ec.exploration_cost_MUSD
    pipeline_cost  = len([w for w in wells if w.is_active]) * 0.3  # $0.3M/well surface piping
    contingency    = (drill_cost + surface_cost) * 0.12  # 12% contingency

    total = drill_cost + surface_cost + exploration + pipeline_cost + contingency

    return {
        "drilling":    round(drill_cost, 2),
        "surface_plant": round(surface_cost, 2),
        "exploration": round(exploration, 2),
        "pipeline":    round(pipeline_cost, 2),
        "contingency": round(contingency, 2),
        "total":       round(total, 2),
    }


def compute_annual_opex(config: SystemConfig, net_power_MW: float,
                        capex_total: float, n_wells: int) -> float:
    ec    = config.economics
    maint = capex_total * ec.opex_fraction_of_capex   # $M/yr maintenance
    labor = 0.8 + n_wells * 0.05                       # $M/yr staffing
    pump  = net_power_MW * 0.12 * 8760 * 0.0001        # Pumping energy cost ($M)
    return round(maint + labor + pump, 3)


# ─────────────────────────────────────────────
# RISK MODEL
# ─────────────────────────────────────────────

class RiskModel:
    """
    Track and compute physical risk indices over simulation lifetime.
    Outputs normalised risk scores [0, 1].
    """

    def __init__(self, config: SystemConfig, field: GeothermalField):
        self.config = config
        self.field  = field
        self.cum_seismic_moment = 0.0
        self.max_inject_pressure_MPa = 0.0
        self.thermal_front_progress  = 0.0  # 0=no breakthrough, 1=full breakthrough
        self._bt_timescale_s = self._estimate_breakthrough_timescale()

    def _estimate_breakthrough_timescale(self) -> float:
        """Estimate pore-volume travel time between injection and production wells."""
        config = self.config
        wells  = config.wells
        prod   = [w for w in wells if w.well_type == "production" and w.is_active]
        inj    = [w for w in wells if w.well_type == "injection"  and w.is_active]
        if not prod or not inj:
            return 1e15  # No breakthrough possible

        # Average well spacing
        spacings = []
        for p in prod:
            for i in inj:
                spacings.append(abs(p.x_pos_m - i.x_pos_m))
        L = np.mean(spacings) if spacings else 500.0

        gc      = config.geology
        phi_avg = 0.10
        # Q_total injection volumetric flow
        Q_inj   = sum(w.target_flow_kgs for w in inj) / water_density(60.0)  # m³/s
        area    = self.field.dz * L  # cross-sectional area
        v_darcy = Q_inj / area  # m/s
        v_pore  = v_darcy / phi_avg  # pore velocity m/s

        t_breakthrough = L / v_pore  # seconds
        return max(t_breakthrough, 3.15e6)  # minimum 0.1 year

    def update(self, dt_s: float, inject_flow_kgs: float,
               inject_pressure_MPa: float, T_prod_C: float, T_inject_C: float,
               cum_inject_vol_m3: float) -> Dict[str, float]:
        """
        Update risk state and return current risk indices.
        """
        # 1. SEISMIC RISK
        # Based on Gutenberg-Richter + induced seismicity correlation with injection volume
        # McGarr (2014): M_max ~ log10(G * V) where G = shear modulus, V = volume
        G       = 30e9   # Pa shear modulus (granite)
        V       = cum_inject_vol_m3
        if V > 0:
            delta_P = max(0, inject_pressure_MPa - 20.0)   # excess above hydrostatic
            seismic_moment_contribution = G * V * 1e-6 * (1 + delta_P * 0.05)
            self.cum_seismic_moment += seismic_moment_contribution * dt_s * 1e-9
        # Normalise to 0-1 (saturation at ~1e12 N·m cumulative)
        seismic_risk = float(np.clip(self.cum_seismic_moment / 1e12, 0, 1))

        # 2. THERMAL BREAKTHROUGH
        # Cold fluid arrives when enough pore volumes have been flushed
        self.thermal_front_progress = min(1.0,
            self.thermal_front_progress + dt_s / (self._bt_timescale_s + 1e-10))
        # Once breakthrough starts, cold water fraction increases
        bt_fraction = max(0.0, self.thermal_front_progress - 0.7) / 0.3  # ramps 0→1 at 70-100%
        bt_fraction = float(np.clip(bt_fraction, 0, 1))

        # Effective production temperature after breakthrough
        T_effective = T_prod_C * (1 - bt_fraction) + T_inject_C * bt_fraction

        # 3. PRESSURE COLLAPSE RISK
        # If reservoir pressure drops too much, productivity collapses
        mean_P      = float(np.mean(self.field.P))
        P_initial   = float(np.mean(self.field.P))  # approximate
        P_collapse_risk = float(np.clip(1.0 - mean_P / 25.0, 0, 1))

        # 4. RESERVOIR DEPLETION RISK
        depl = self.field.thermal_depletion_index()
        depl_risk = float(np.clip(depl * 2.5, 0, 1))

        return {
            "seismic_risk":         seismic_risk,
            "thermal_breakthrough": bt_fraction,
            "thermal_front_progress": self.thermal_front_progress,
            "pressure_collapse":    P_collapse_risk,
            "depletion_risk":       depl_risk,
            "composite_risk":       float(np.clip(
                0.3 * seismic_risk + 0.35 * bt_fraction + 0.2 * depl_risk + 0.15 * P_collapse_risk,
                0, 1
            )),
            "T_effective_C":        T_effective,
        }


# ─────────────────────────────────────────────
# OPTIMISATION ENGINE
# ─────────────────────────────────────────────

class Optimiser:
    """
    Operational parameter optimiser.
    Adjusts flow rates, injection temperature, well operation schedule
    to balance energy output vs. reservoir sustainability.
    """

    def __init__(self, config: SystemConfig):
        self.config = config
        self._step  = 0
        self._prev_power = None
        self._prev_depl  = None

    def optimise(self, field: GeothermalField, risk: Dict[str, float],
                 current_flows: Dict[str, float],
                 target: str = "balanced") -> Dict[str, float]:
        """
        Compute optimal flow rate adjustments.
        target: 'max_power' | 'max_lifetime' | 'balanced'
        Returns dict: well_id -> recommended_flow_kgs
        """
        self._step += 1
        optimised_flows = dict(current_flows)

        seismic  = risk["seismic_risk"]
        bt       = risk["thermal_breakthrough"]
        depl     = risk["depletion_risk"]
        T_prod   = field.production_zone_temp([w for w in self.config.wells
                                               if w.well_type == "production"])

        for well in self.config.wells:
            if not well.is_active:
                continue

            q = current_flows.get(well.well_id, well.target_flow_kgs)

            if target == "max_power":
                # Aggressive extraction — increase flow if temperature allows
                if T_prod > 120 and depl < 0.5:
                    q = min(q * 1.05, well.target_flow_kgs * 1.3)
                elif depl > 0.7:
                    q = q * 0.85

            elif target == "max_lifetime":
                # Conservative — throttle back under any risk
                if depl > 0.3:
                    q = q * 0.90
                if seismic > 0.3:
                    q = q * 0.85
                if bt > 0.5:
                    q = q * 0.80

            else:  # balanced
                # Throttle if risk triggers, boost if healthy
                if seismic > 0.5:
                    q = q * 0.92
                if bt > 0.6:
                    q = q * 0.88
                if depl > 0.5:
                    q = q * 0.93
                if T_prod > 130 and depl < 0.3 and seismic < 0.2:
                    q = min(q * 1.02, well.target_flow_kgs * 1.15)

            # Hard floor — don't let wells stall
            q = max(q, well.target_flow_kgs * 0.25)
            optimised_flows[well.well_id] = round(float(q), 2)

        return optimised_flows

    def recommend_well_schedule(self, risk: Dict[str, float],
                                wells: List[WellConfig]) -> List[str]:
        """Return list of operational advisories."""
        adv = []
        if risk["seismic_risk"] > 0.6:
            adv.append("⚠ HIGH SEISMIC RISK — Reduce injection pressure immediately")
        if risk["thermal_breakthrough"] > 0.5:
            adv.append("⚠ THERMAL BREAKTHROUGH — Cold plume approaching production zone")
        if risk["depletion_risk"] > 0.6:
            adv.append("⚠ RESERVOIR DEPLETION — Reduce extraction rates or add injection wells")
        if risk["composite_risk"] > 0.7:
            adv.append("🔴 COMPOSITE RISK CRITICAL — Consider production curtailment")
        if not adv:
            adv.append("✓ All risk indices within acceptable operational limits")
        return adv


# ─────────────────────────────────────────────
# MAIN SIMULATION ENGINE
# ─────────────────────────────────────────────

class SimulationEngine:
    """
    Master simulation loop.
    Orchestrates reservoir physics, plant conversion, economics, risk and optimisation.
    """

    def __init__(self, config: SystemConfig):
        self.config    = config
        self.field     = GeothermalField(config)
        self.risk_mdl  = RiskModel(config, self.field)
        self.optimiser = Optimiser(config)

        self.prod_wells = [w for w in config.wells if w.well_type == "production" and w.is_active]
        self.inj_wells  = [w for w in config.wells if w.well_type == "injection"  and w.is_active]

        self.dt_s = config.dt_years * 365.25 * 24 * 3600  # seconds per timestep
        self.n_steps = int(config.total_years / config.dt_years)

        # Flow rates initialised to target
        self.current_flows: Dict[str, float] = {
            w.well_id: w.target_flow_kgs for w in config.wells
        }

        # Compute CAPEX upfront
        # Estimate design capacity from initial conditions
        T_prod_init = self.field.production_zone_temp(self.prod_wells) if self.prod_wells else 100.0
        pc          = config.plant
        eta         = plant_efficiency(pc.plant_type, T_prod_init, pc.cooling_temp)
        cp_w        = 4186.0
        total_mass  = sum(w.target_flow_kgs for w in self.prod_wells)
        Q_therm_est = total_mass * cp_w * max(T_prod_init - pc.injection_temp, 0) / 1e6
        self.design_MW = Q_therm_est * eta * (1 - pc.parasitic_fraction)

        self.capex_breakdown = compute_capex(config, config.wells, max(self.design_MW, 1.0))
        self.capex_total     = self.capex_breakdown["total"]
        self.annual_opex     = compute_annual_opex(config, self.design_MW,
                                                    self.capex_total, len(config.wells))

        self.history: List[TimestepState] = []
        self._cum_energy_GWh  = 0.0
        self._cum_revenue_MUSD = 0.0
        self._cum_npv_MUSD    = -self.capex_total   # Start negative (investment)

        # Snapshot interval: save T and P grids every N steps
        self._snapshot_interval = max(1, self.n_steps // 5)

    def run(self, optimisation_target: str = "balanced",
            progress_callback=None) -> List[TimestepState]:
        """
        Execute full simulation. Returns list of TimestepState records.
        """
        self.history.clear()
        self._cum_energy_GWh   = 0.0
        self._cum_revenue_MUSD = 0.0
        self._cum_npv_MUSD     = -self.capex_total

        ec   = self.config.economics
        pc   = self.config.plant
        cp_w = 4186.0

        for step in range(self.n_steps):
            t_years = step * self.config.dt_years

            if progress_callback:
                progress_callback(step / self.n_steps)

            # ── 1. Compute achievable flow rates ──────────────────
            for well in self.prod_wells + self.inj_wells:
                achievable = self.field.achievable_flow_rate(well)
                target     = self.current_flows.get(well.well_id, well.target_flow_kgs)
                self.current_flows[well.well_id] = min(target, achievable)

            # ── 2. Extract heat at production wells ───────────────
            well_flows: Dict[str, float] = {}
            well_temps: Dict[str, float] = {}
            total_thermal_MW = 0.0
            T_inject_C       = pc.injection_temp

            for well in self.prod_wells:
                Q  = self.current_flows[well.well_id]
                T_prod, Q_therm_MW = self.field.extract_heat(well, Q, self.dt_s, T_inject_C)
                well_flows[well.well_id] = Q
                well_temps[well.well_id] = T_prod
                total_thermal_MW += Q_therm_MW

            # ── 3. Inject at injection wells ──────────────────────
            total_inject_flow = 0.0
            for well in self.inj_wells:
                Q = self.current_flows[well.well_id]
                self.field.inject_fluid(well, Q, self.dt_s, T_inject_C)
                well_flows[well.well_id] = Q
                well_temps[well.well_id] = T_inject_C
                total_inject_flow += Q

            # ── 4. Apply thermal diffusion ────────────────────────
            self.field.apply_thermal_diffusion(self.dt_s)

            # ── 5. Update pressure field ──────────────────────────
            self.field.update_pressure(
                self.prod_wells, self.inj_wells, self.current_flows, self.dt_s)

            # ── 6. Power conversion ───────────────────────────────
            T_prod_mean = np.mean(list(well_temps[w.well_id] for w in self.prod_wells)) \
                          if self.prod_wells else 0.0
            eta     = plant_efficiency(pc.plant_type, T_prod_mean, pc.cooling_temp)
            gross_MW = total_thermal_MW * eta
            net_MW   = gross_MW * (1 - pc.parasitic_fraction)
            net_MW   = max(0.0, net_MW)

            # ── 7. Risk assessment ────────────────────────────────
            inject_P_MPa = float(np.mean(self.field.P))
            risk = self.risk_mdl.update(
                self.dt_s,
                total_inject_flow, inject_P_MPa,
                T_prod_mean, T_inject_C,
                self.field.cum_inject_vol_m3
            )

            # Effective production temperature after breakthrough
            T_effective = risk["T_effective_C"]
            if T_effective < T_prod_mean * 0.95:
                # Recalculate power with effective temperature
                Q_therm_eff  = sum(self.current_flows[w.well_id] for w in self.prod_wells) \
                               * cp_w * max(T_effective - T_inject_C, 0) / 1e6
                eta_eff      = plant_efficiency(pc.plant_type, T_effective, pc.cooling_temp)
                gross_MW     = Q_therm_eff * eta_eff
                net_MW       = max(0.0, gross_MW * (1 - pc.parasitic_fraction))
                total_thermal_MW = Q_therm_eff

            # ── 8. Economics ──────────────────────────────────────
            dt_hrs   = self.config.dt_years * 8760
            energy_GWh = net_MW * dt_hrs / 1000.0
            self._cum_energy_GWh  += energy_GWh

            revenue_MUSD  = energy_GWh * ec.electricity_price_USD_kWh * 1000  # GWh→kWh→$
            revenue_MUSD /= 1e6  # → $M
            opex_MUSD     = self.annual_opex * self.config.dt_years

            # NPV discounting
            discount_factor = 1.0 / (1 + ec.discount_rate) ** t_years
            npv_delta       = (revenue_MUSD - opex_MUSD) * discount_factor
            self._cum_npv_MUSD    += npv_delta
            self._cum_revenue_MUSD += revenue_MUSD

            # Cost per kWh
            total_spent = self.capex_total + self.annual_opex * t_years
            if self._cum_energy_GWh > 0:
                cost_kWh = (total_spent * 1e6) / (self._cum_energy_GWh * 1e6)   # $/kWh
            else:
                cost_kWh = 999.0

            # ── 9. Optimise flow rates ────────────────────────────
            self.current_flows = self.optimiser.optimise(
                self.field, risk, self.current_flows, optimisation_target)

            # ── 10. Log state ─────────────────────────────────────
            save_snapshot = (step % self._snapshot_interval == 0) or (step == self.n_steps - 1)
            state = TimestepState(
                time_years           = round(t_years, 3),
                reservoir_mean_temp  = round(self.field.reservoir_mean_temp(), 2),
                production_temp      = round(T_effective, 2),
                injection_temp       = T_inject_C,
                gross_power_MW       = round(gross_MW, 3),
                net_power_MW         = round(net_MW, 3),
                thermal_power_MW     = round(total_thermal_MW, 3),
                plant_efficiency     = round(eta * 100, 2),
                depletion_index      = round(self.field.thermal_depletion_index(), 4),
                well_flows           = dict(self.current_flows),
                well_temps           = dict(well_temps),
                seismic_risk         = round(risk["seismic_risk"], 4),
                thermal_breakthrough = round(risk["thermal_breakthrough"], 4),
                pressure_mean        = round(float(np.mean(self.field.P)), 3),
                cum_energy_GWh       = round(self._cum_energy_GWh, 4),
                cum_revenue_MUSD     = round(self._cum_revenue_MUSD, 3),
                cost_per_kWh         = round(cost_kWh, 5),
                capex_MUSD           = round(self.capex_total, 2),
                npv_MUSD             = round(self._cum_npv_MUSD, 3),
                T_snapshot           = self.field.T.copy() if save_snapshot else None,
                P_snapshot           = self.field.P.copy() if save_snapshot else None,
            )
            self.history.append(state)

        if progress_callback:
            progress_callback(1.0)

        return self.history

    def to_dataframe(self) -> pd.DataFrame:
        """Convert history to a flat DataFrame."""
        rows = []
        for s in self.history:
            row = {
                "time_years":          s.time_years,
                "reservoir_mean_temp": s.reservoir_mean_temp,
                "production_temp":     s.production_temp,
                "gross_power_MW":      s.gross_power_MW,
                "net_power_MW":        s.net_power_MW,
                "thermal_power_MW":    s.thermal_power_MW,
                "plant_efficiency":    s.plant_efficiency,
                "depletion_index":     s.depletion_index,
                "seismic_risk":        s.seismic_risk,
                "thermal_breakthrough": s.thermal_breakthrough,
                "pressure_mean":       s.pressure_mean,
                "cum_energy_GWh":      s.cum_energy_GWh,
                "cum_revenue_MUSD":    s.cum_revenue_MUSD,
                "cost_per_kWh":        s.cost_per_kWh,
                "npv_MUSD":            s.npv_MUSD,
            }
            # Flatten per-well data
            for wid, q in s.well_flows.items():
                row[f"flow_{wid}"] = q
            for wid, t in s.well_temps.items():
                row[f"temp_{wid}"] = t
            rows.append(row)
        return pd.DataFrame(rows)

    def reservoir_lifetime_estimate_years(self) -> float:
        """
        Estimate field lifetime: years until production temp drops below
        economic threshold (typically 80°C for ORC).
        """
        min_economic_T = {"ORC": 80.0, "FLASH": 150.0, "DRY_STEAM": 180.0}
        threshold = min_economic_T.get(self.config.plant.plant_type, 80.0)

        for s in self.history:
            if s.production_temp < threshold:
                return s.time_years

        # Extrapolate from depletion rate
        if len(self.history) >= 2:
            last     = self.history[-1]
            first    = self.history[0]
            if last.production_temp >= threshold:
                dT_per_yr = (first.production_temp - last.production_temp) / \
                            max(last.time_years - first.time_years, 0.01)
                if dT_per_yr > 0:
                    years_remaining = (last.production_temp - threshold) / dT_per_yr
                    return round(last.time_years + years_remaining, 1)

        return self.config.total_years  # Still viable at end of simulation

    def get_snapshots(self) -> List[Tuple[float, np.ndarray, np.ndarray]]:
        """Return list of (time_years, T_grid, P_grid) from saved snapshots."""
        out = []
        for s in self.history:
            if s.T_snapshot is not None:
                out.append((s.time_years, s.T_snapshot, s.P_snapshot))
        return out

    def peak_power_record(self) -> Tuple[float, float]:
        """Return (peak_net_MW, time_at_peak_years)."""
        if not self.history:
            return 0.0, 0.0
        best = max(self.history, key=lambda s: s.net_power_MW)
        return best.net_power_MW, best.time_years

    def get_risk_advisories(self) -> List[str]:
        if not self.history:
            return []
        last_risk = {
            "seismic_risk":        self.history[-1].seismic_risk,
            "thermal_breakthrough": self.history[-1].thermal_breakthrough,
            "depletion_risk":      self.history[-1].depletion_index,
            "composite_risk":      (self.history[-1].seismic_risk * 0.3 +
                                    self.history[-1].thermal_breakthrough * 0.35 +
                                    self.history[-1].depletion_index * 0.35),
        }
        return self.optimiser.recommend_well_schedule(last_risk, self.config.wells)


# ─────────────────────────────────────────────
# PRESET FIELD CONFIGURATIONS
# ─────────────────────────────────────────────

def build_default_wells(field_width_m: float = 9600.0,
                         n_prod: int = 4, n_inj: int = 2,
                         depth_m: float = 2500.0,
                         flow_kgs: float = 55.0) -> List[WellConfig]:
    """Generate a balanced production/injection well layout."""
    wells = []
    spacing = field_width_m / (n_prod + 1)
    inj_spacing = field_width_m / (n_inj + 1)

    for i in range(n_prod):
        wells.append(WellConfig(
            well_id        = f"P{i+1:02d}",
            well_type      = "production",
            x_pos_m        = spacing * (i + 1),
            depth_m        = depth_m,
            target_flow_kgs = flow_kgs,
        ))

    for i in range(n_inj):
        x = inj_spacing * (i + 1)
        wells.append(WellConfig(
            well_id        = f"I{i+1:02d}",
            well_type      = "injection",
            x_pos_m        = x,
            depth_m        = depth_m - 200.0,   # Inject slightly shallower
            target_flow_kgs = flow_kgs * 0.85,  # Injection slightly less than production
        ))

    return wells


PRESET_CONFIGS = {
    "High-Temperature Flash Field": {
        "description": "Deep high-enthalpy volcanic system. Flash plant. High power, elevated risk.",
        "geology": {
            "geothermal_gradient": 60.0,
            "surface_temp": 15.0,
            "has_heat_anomaly": True,
            "heat_anomaly_depth_m": 2500.0,
            "heat_anomaly_temp_C": 90.0,
            "layers": [(0, "SHALE"), (400, "RHYOLITE"), (1200, "BASALT"), (2500, "GRANITE")],
        },
        "plant_type": "FLASH",
        "well_depth_m": 2800.0,
        "n_prod": 6,
        "n_inj": 3,
        "flow_kgs": 70.0,
    },
    "Medium-Enthalpy ORC Field": {
        "description": "Sedimentary basin. ORC plant. Moderate temperatures, lower risk.",
        "geology": {
            "geothermal_gradient": 35.0,
            "surface_temp": 10.0,
            "has_heat_anomaly": False,
            "heat_anomaly_temp_C": 0.0,
            "layers": [(0, "SHALE"), (600, "SANDSTONE"), (1800, "LIMESTONE"), (3000, "GRANITE")],
        },
        "plant_type": "ORC",
        "well_depth_m": 3200.0,
        "n_prod": 4,
        "n_inj": 2,
        "flow_kgs": 50.0,
    },
    "Deep EGS (Enhanced Geothermal)": {
        "description": "Engineered reservoir in basement granite. Ultra-deep, stimulated fractures.",
        "geology": {
            "geothermal_gradient": 28.0,
            "surface_temp": 12.0,
            "has_heat_anomaly": True,
            "heat_anomaly_depth_m": 4500.0,
            "heat_anomaly_temp_C": 45.0,
            "fracture_multiplier": 500.0,
            "n_fracture_zones": 15,
            "layers": [(0, "SHALE"), (300, "LIMESTONE"), (1000, "GRANITE")],
        },
        "plant_type": "ORC",
        "well_depth_m": 4500.0,
        "n_prod": 3,
        "n_inj": 3,
        "flow_kgs": 35.0,
    },
}
