"""
GEOTHERMAL NEXUS — Chart Library
All Plotly figure generators for the operational dashboard.
"""

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
from typing import List, Tuple, Dict, Optional

from physics import GeothermalField, SystemConfig, WellConfig, ROCK_PROPERTIES, RockType
from simulation import TimestepState, SimulationEngine

# ── DESIGN TOKENS ────────────────────────────────────────────────────────────

PALETTE = {
    "bg":        "#0a0a0a",
    "surface":   "#111111",
    "panel":     "#161616",
    "border":    "#2a1a00",
    "hot":       "#FF6B00",
    "hot_bright":"#FF9900",
    "warm":      "#FFB347",
    "cold":      "#00A8FF",
    "cold_dark": "#005B8E",
    "power":     "#00E676",
    "power_dim": "#007A3D",
    "risk_hi":   "#FF1744",
    "risk_mid":  "#FF9100",
    "risk_lo":   "#69F0AE",
    "text":      "#D4D4D4",
    "text_dim":  "#707070",
    "amber":     "#FFB800",
    "cyan":      "#00E5FF",
    "grid":      "#1E1E1E",
}

LAYOUT_BASE = dict(
    plot_bgcolor  = PALETTE["bg"],
    paper_bgcolor = PALETTE["bg"],
    font          = dict(family="Share Tech Mono, monospace", color=PALETTE["text"], size=11),
    margin        = dict(l=50, r=20, t=40, b=40),
    legend        = dict(bgcolor="rgba(0,0,0,0)", bordercolor=PALETTE["border"],
                         borderwidth=1, font=dict(size=10)),
)

AXIS_STYLE = dict(
    gridcolor     = PALETTE["grid"],
    zerolinecolor = PALETTE["grid"],
    linecolor     = PALETTE["border"],
    tickfont      = dict(family="Share Tech Mono, monospace", size=10, color=PALETTE["text_dim"]),
)


def _apply_layout(fig, title: str = "", height: int = 380):
    fig.update_layout(
        **LAYOUT_BASE,
        title=dict(text=title, font=dict(size=13, color=PALETTE["amber"],
                                          family="Share Tech Mono, monospace"),
                   x=0.01, y=0.98),
        height=height,
    )
    fig.update_xaxes(**AXIS_STYLE)
    fig.update_yaxes(**AXIS_STYLE)
    return fig


# ── THERMAL HEATMAP ──────────────────────────────────────────────────────────

def thermal_heatmap(field: GeothermalField, config: SystemConfig,
                     wells: List[WellConfig], title: str = "RESERVOIR TEMPERATURE FIELD") -> go.Figure:
    """2D subsurface thermal map with well positions overlaid."""
    T  = field.T
    nz, nx = T.shape
    x_km = field.x_centres / 1000
    z_km = field.z_centres / 1000

    # Custom thermal colorscale: cold-blue → rock-brown → magma-orange → white-hot
    colorscale = [
        [0.00, "#05050F"],
        [0.15, "#0A1B4A"],
        [0.30, "#2E5A8A"],
        [0.45, "#7B4F2E"],
        [0.60, "#C44A00"],
        [0.75, "#FF6B00"],
        [0.88, "#FFA500"],
        [1.00, "#FFEECC"],
    ]

    fig = go.Figure()

    fig.add_trace(go.Heatmap(
        z          = T,
        x          = x_km,
        y          = z_km,
        colorscale = colorscale,
        colorbar   = dict(
            title      = dict(text="°C", font=dict(color=PALETTE["amber"], size=11)),
            tickfont   = dict(color=PALETTE["text_dim"], size=9),
            thickness  = 12,
            len        = 0.8,
            bgcolor    = "rgba(0,0,0,0)",
            bordercolor = PALETTE["border"],
        ),
        hovertemplate = "Depth: %{y:.2f} km<br>X: %{x:.2f} km<br>Temp: %{z:.1f}°C<extra></extra>",
    ))

    # Fracture zones
    frac_iz, frac_ix = np.where(field.fracture_mask)
    if len(frac_iz):
        fig.add_trace(go.Scatter(
            x    = field.x_centres[frac_ix] / 1000,
            y    = field.z_centres[frac_iz] / 1000,
            mode = "markers",
            marker = dict(symbol="line-ns", size=8, color=PALETTE["cyan"],
                          opacity=0.4, line=dict(width=1, color=PALETTE["cyan"])),
            name = "Fracture Zones",
            hoverinfo = "skip",
        ))

    # Wells
    for w in wells:
        x_km_w = w.x_pos_m / 1000
        colour = PALETTE["hot_bright"] if w.well_type == "production" else PALETTE["cold"]
        symbol = "triangle-up" if w.well_type == "production" else "triangle-down"

        # Well trace (vertical line)
        fig.add_trace(go.Scatter(
            x    = [x_km_w, x_km_w],
            y    = [0, w.depth_m / 1000],
            mode = "lines",
            line = dict(color=colour, width=1.5, dash="dot"),
            showlegend = False,
            hoverinfo  = "skip",
        ))

        # Well head marker
        fig.add_trace(go.Scatter(
            x    = [x_km_w],
            y    = [w.depth_m / 1000],
            mode = "markers+text",
            marker = dict(symbol=symbol, size=12, color=colour,
                          line=dict(width=1, color="white")),
            text = [w.well_id],
            textposition = "top center",
            textfont     = dict(size=9, color=colour),
            name = f"{w.well_type.capitalize()} Well {w.well_id}",
            hovertemplate = f"Well: {w.well_id}<br>Type: {w.well_type}<br>"
                            f"Depth: {w.depth_m:.0f}m<extra></extra>",
        ))

    fig.update_layout(
        **LAYOUT_BASE,
        title  = dict(text=title, font=dict(size=13, color=PALETTE["amber"],
                                             family="Share Tech Mono, monospace"), x=0.01),
        height = 480,
        xaxis  = dict(**AXIS_STYLE, title="Distance (km)"),
        yaxis  = dict(**AXIS_STYLE, title="Depth (km)", autorange="reversed",
                      tickformat=".2f"),
    )
    return fig


def temperature_profile_chart(field: GeothermalField, config: SystemConfig) -> go.Figure:
    """Vertical temperature profile: initial vs current."""
    z_km   = field.z_centres / 1000
    T_now  = np.mean(field.T, axis=1)
    T_init = np.mean(field.T0, axis=1)

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=T_init, y=z_km,
        mode="lines", name="Initial",
        line=dict(color=PALETTE["border"], width=1.5, dash="dash"),
    ))
    fig.add_trace(go.Scatter(
        x=T_now, y=z_km,
        mode="lines", name="Current",
        line=dict(color=PALETTE["hot"], width=2.5),
        fill="tonexty", fillcolor="rgba(255,107,0,0.08)",
    ))

    fig.update_layout(
        **LAYOUT_BASE,
        title  = dict(text="GEOTHERMAL GRADIENT PROFILE", font=dict(size=12, color=PALETTE["amber"]), x=0.01),
        height = 380,
        xaxis  = dict(**AXIS_STYLE, title="Temperature (°C)"),
        yaxis  = dict(**AXIS_STYLE, title="Depth (km)", autorange="reversed"),
    )
    return fig


# ── POWER OUTPUT CHARTS ──────────────────────────────────────────────────────

def power_output_chart(df: pd.DataFrame) -> go.Figure:
    """Net and gross power over simulation lifetime."""
    fig = go.Figure()

    fig.add_trace(go.Scatter(
        x=df["time_years"], y=df["gross_power_MW"],
        name="Gross Power",
        line=dict(color=PALETTE["warm"], width=1.5, dash="dot"),
        fill="tozeroy", fillcolor="rgba(255,179,71,0.06)",
    ))
    fig.add_trace(go.Scatter(
        x=df["time_years"], y=df["net_power_MW"],
        name="Net Power",
        line=dict(color=PALETTE["power"], width=2.5),
        fill="tozeroy", fillcolor="rgba(0,230,118,0.10)",
    ))
    fig.add_trace(go.Scatter(
        x=df["time_years"], y=df["thermal_power_MW"],
        name="Thermal Input",
        line=dict(color=PALETTE["hot"], width=1.5, dash="dash"),
    ))

    return _apply_layout(fig, "POWER OUTPUT — NET / GROSS / THERMAL  [MW]")


def cumulative_energy_chart(df: pd.DataFrame) -> go.Figure:
    """Cumulative energy generation and revenue."""
    fig = make_subplots(specs=[[{"secondary_y": True}]])

    fig.add_trace(go.Scatter(
        x=df["time_years"], y=df["cum_energy_GWh"],
        name="Cumulative Energy (GWh)",
        line=dict(color=PALETTE["power"], width=2),
        fill="tozeroy", fillcolor="rgba(0,230,118,0.08)",
    ), secondary_y=False)

    fig.add_trace(go.Scatter(
        x=df["time_years"], y=df["cum_revenue_MUSD"],
        name="Cumulative Revenue ($M)",
        line=dict(color=PALETTE["amber"], width=2),
    ), secondary_y=True)

    fig.update_layout(
        **LAYOUT_BASE,
        title  = dict(text="CUMULATIVE ENERGY OUTPUT & REVENUE", font=dict(size=12, color=PALETTE["amber"]), x=0.01),
        height = 360,
    )
    fig.update_xaxes(**AXIS_STYLE, title="Years")
    fig.update_yaxes(**AXIS_STYLE, title="Energy (GWh)", secondary_y=False)
    fig.update_yaxes(**AXIS_STYLE, title="Revenue ($M)", secondary_y=True)
    return fig


def plant_efficiency_chart(df: pd.DataFrame) -> go.Figure:
    """Plant efficiency and production temperature over time."""
    fig = make_subplots(specs=[[{"secondary_y": True}]])

    fig.add_trace(go.Scatter(
        x=df["time_years"], y=df["production_temp"],
        name="Production Temp (°C)",
        line=dict(color=PALETTE["hot"], width=2.5),
    ), secondary_y=False)

    fig.add_trace(go.Scatter(
        x=df["time_years"], y=df["plant_efficiency"],
        name="Plant Efficiency (%)",
        line=dict(color=PALETTE["cyan"], width=2),
    ), secondary_y=True)

    fig.update_layout(
        **LAYOUT_BASE,
        title  = dict(text="PRODUCTION TEMPERATURE & PLANT EFFICIENCY", font=dict(size=12, color=PALETTE["amber"]), x=0.01),
        height = 360,
    )
    fig.update_xaxes(**AXIS_STYLE, title="Years")
    fig.update_yaxes(**AXIS_STYLE, title="Temperature (°C)", secondary_y=False)
    fig.update_yaxes(**AXIS_STYLE, title="Efficiency (%)", secondary_y=True)
    return fig


# ── WELL PERFORMANCE CHARTS ──────────────────────────────────────────────────

def well_flow_chart(df: pd.DataFrame, wells: List[WellConfig]) -> go.Figure:
    """Per-well flow rates over time."""
    fig = go.Figure()
    prod_wells = [w for w in wells if w.well_type == "production" and w.is_active]
    colours    = [PALETTE["hot"], PALETTE["warm"], PALETTE["hot_bright"], "#FF4400",
                  "#FFD700", "#FF6633", "#FFAA00", "#CC3300"]

    for i, well in enumerate(prod_wells):
        col_name = f"flow_{well.well_id}"
        if col_name in df.columns:
            fig.add_trace(go.Scatter(
                x    = df["time_years"],
                y    = df[col_name],
                name = well.well_id,
                line = dict(color=colours[i % len(colours)], width=2),
                mode = "lines",
            ))

    return _apply_layout(fig, "PRODUCTION WELL FLOW RATES  [kg/s]")


def well_temperature_chart(df: pd.DataFrame, wells: List[WellConfig]) -> go.Figure:
    """Per-well production temperature over time."""
    fig = go.Figure()
    prod_wells = [w for w in wells if w.well_type == "production" and w.is_active]
    colours    = [PALETTE["hot"], PALETTE["warm"], PALETTE["hot_bright"], "#FF4400",
                  "#FFD700", "#FF6633", "#FFAA00", "#CC3300"]

    for i, well in enumerate(prod_wells):
        col_name = f"temp_{well.well_id}"
        if col_name in df.columns:
            fig.add_trace(go.Scatter(
                x    = df["time_years"],
                y    = df[col_name],
                name = well.well_id,
                line = dict(color=colours[i % len(colours)], width=2),
            ))

    return _apply_layout(fig, "PRODUCTION WELL TEMPERATURES  [°C]")


# ── RESERVOIR DEPLETION CHARTS ───────────────────────────────────────────────

def depletion_timeline_chart(df: pd.DataFrame, lifetime_years: float) -> go.Figure:
    """Reservoir thermal depletion index over time + lifetime indicator."""
    fig = go.Figure()

    depl_pct = df["depletion_index"] * 100

    # Colour band zones
    fig.add_hrect(y0=0,  y1=30,  fillcolor="rgba(0,230,118,0.06)", line_width=0)
    fig.add_hrect(y0=30, y1=60,  fillcolor="rgba(255,145,0,0.06)",  line_width=0)
    fig.add_hrect(y0=60, y1=100, fillcolor="rgba(255,23,68,0.06)",  line_width=0)

    fig.add_trace(go.Scatter(
        x=df["time_years"], y=depl_pct,
        name="Thermal Depletion %",
        line=dict(color=PALETTE["hot"], width=2.5),
        fill="tozeroy", fillcolor="rgba(255,107,0,0.10)",
    ))

    # Economic lifetime marker
    if lifetime_years <= df["time_years"].max():
        fig.add_vline(x=lifetime_years, line=dict(color=PALETTE["risk_hi"], width=1.5, dash="dash"))
        fig.add_annotation(x=lifetime_years, y=85,
                           text=f"⚡ Economic EOL<br>{lifetime_years:.1f} yr",
                           showarrow=False,
                           font=dict(color=PALETTE["risk_hi"], size=10, family="Share Tech Mono"),
                           bgcolor="rgba(0,0,0,0.6)",
                           bordercolor=PALETTE["risk_hi"], borderwidth=1)

    return _apply_layout(fig, "RESERVOIR THERMAL DEPLETION TIMELINE  [%]")


def reservoir_temp_evolution(snapshots: List[Tuple], config: SystemConfig,
                              wells: List[WellConfig]) -> go.Figure:
    """Multi-panel temperature snapshots at t=0, mid, end."""
    if not snapshots:
        return go.Figure()

    n_snaps = min(3, len(snapshots))
    indices = [0, len(snapshots)//2, len(snapshots)-1][:n_snaps]
    selected = [snapshots[i] for i in indices]

    fig = make_subplots(
        rows=1, cols=n_snaps,
        subplot_titles=[f"t = {s[0]:.1f} yr" for s in selected],
        horizontal_spacing=0.06,
    )

    colorscale = [
        [0.0, "#070712"], [0.25, "#1A3A6A"], [0.5, "#8B4A20"],
        [0.75, "#FF6B00"], [1.0, "#FFE4AA"],
    ]

    all_T = np.concatenate([s[1].flatten() for s in selected])
    t_min, t_max = all_T.min(), all_T.max()

    gc = config.geology
    x_km = (np.arange(gc.nx) + 0.5) * gc.dx / 1000
    z_km = (np.arange(gc.nz) + 0.5) * gc.dz / 1000

    for col, (t_yr, T_snap, P_snap) in enumerate(selected, 1):
        show_scale = (col == n_snaps)
        fig.add_trace(
            go.Heatmap(
                z=T_snap, x=x_km, y=z_km,
                colorscale=colorscale,
                zmin=t_min, zmax=t_max,
                showscale=show_scale,
                colorbar=dict(
                    thickness=10,
                    title=dict(text="°C", font=dict(color=PALETTE["amber"], size=10)),
                    tickfont=dict(color=PALETTE["text_dim"], size=9),
                    bgcolor="rgba(0,0,0,0)",
                ) if show_scale else {},
                hovertemplate="Depth: %{y:.2f} km<br>T: %{z:.1f}°C<extra></extra>",
            ),
            row=1, col=col
        )
        # Well positions
        for w in wells:
            colour = PALETTE["hot_bright"] if w.well_type == "production" else PALETTE["cold"]
            fig.add_trace(go.Scatter(
                x=[w.x_pos_m / 1000], y=[w.depth_m / 1000],
                mode="markers",
                marker=dict(symbol="circle-open", size=7, color=colour, line=dict(width=1.5)),
                showlegend=False, hoverinfo="skip",
            ), row=1, col=col)

    fig.update_layout(
        **LAYOUT_BASE,
        title=dict(text="RESERVOIR TEMPERATURE EVOLUTION — SNAPSHOTS",
                   font=dict(size=13, color=PALETTE["amber"], family="Share Tech Mono"), x=0.01),
        height=380,
    )
    for i in range(1, n_snaps + 1):
        fig.update_xaxes(**AXIS_STYLE, title="km", row=1, col=i)
        fig.update_yaxes(**AXIS_STYLE, autorange="reversed",
                         title="km" if i == 1 else "", row=1, col=i)
    return fig


# ── RISK CHARTS ──────────────────────────────────────────────────────────────

def risk_dashboard(df: pd.DataFrame) -> go.Figure:
    """Multi-panel risk indices over time."""
    fig = make_subplots(
        rows=2, cols=2,
        subplot_titles=[
            "SEISMIC RISK INDEX",
            "THERMAL BREAKTHROUGH",
            "RESERVOIR DEPLETION",
            "COMPOSITE RISK",
        ],
        vertical_spacing=0.14,
        horizontal_spacing=0.08,
    )

    configs = [
        ("seismic_risk",         PALETTE["risk_hi"],  "rgba(255,23,68,0.10)",   1, 1),
        ("thermal_breakthrough", PALETTE["cold"],      "rgba(0,168,255,0.10)",   1, 2),
        ("depletion_index",      PALETTE["warm"],      "rgba(255,179,71,0.10)",  2, 1),
    ]

    for col_name, colour, fill_col, row, col in configs:
        if col_name not in df.columns:
            continue
        fig.add_trace(go.Scatter(
            x=df["time_years"], y=df[col_name],
            name=col_name.replace("_", " ").title(),
            line=dict(color=colour, width=2),
            fill="tozeroy", fillcolor=fill_col,
        ), row=row, col=col)

        # Threshold line at 0.5
        fig.add_hline(y=0.5, line=dict(color=PALETTE["risk_mid"], width=1, dash="dash"),
                      row=row, col=col)

    # Composite risk
    if all(c in df.columns for c in ["seismic_risk", "thermal_breakthrough", "depletion_index"]):
        composite = (0.3 * df["seismic_risk"] + 0.35 * df["thermal_breakthrough"] +
                     0.35 * df["depletion_index"])
        # Colour changes by zone
        fig.add_trace(go.Scatter(
            x=df["time_years"], y=composite,
            name="Composite Risk",
            line=dict(color=PALETTE["risk_hi"], width=2.5),
            fill="tozeroy", fillcolor="rgba(255,23,68,0.12)",
        ), row=2, col=2)
        fig.add_hline(y=0.7, line=dict(color=PALETTE["risk_hi"], width=1, dash="dash"),
                      row=2, col=2)

    fig.update_layout(
        **LAYOUT_BASE,
        title=dict(text="RISK MONITORING PANEL", font=dict(size=13, color=PALETTE["risk_hi"],
                   family="Share Tech Mono"), x=0.01),
        height=500,
        showlegend=False,
    )
    fig.update_xaxes(**AXIS_STYLE, title="Years")
    fig.update_yaxes(**AXIS_STYLE, range=[0, 1.05])
    return fig


def risk_gauge(value: float, label: str, risk_level: str = "auto") -> go.Figure:
    """Single gauge chart for a risk index."""
    if risk_level == "auto":
        if value < 0.3:
            color = PALETTE["risk_lo"]
        elif value < 0.6:
            color = PALETTE["risk_mid"]
        else:
            color = PALETTE["risk_hi"]
    else:
        color = {"low": PALETTE["risk_lo"], "mid": PALETTE["risk_mid"],
                 "high": PALETTE["risk_hi"]}.get(risk_level, PALETTE["amber"])

    fig = go.Figure(go.Indicator(
        mode  = "gauge+number",
        value = value * 100,
        title = dict(text=label, font=dict(color=PALETTE["text_dim"], size=10,
                                            family="Share Tech Mono")),
        number = dict(suffix="%", font=dict(color=color, size=18,
                                             family="Share Tech Mono")),
        gauge = dict(
            axis  = dict(range=[0, 100], tickfont=dict(color=PALETTE["text_dim"], size=8)),
            bar   = dict(color=color, thickness=0.25),
            bgcolor = PALETTE["panel"],
            borderwidth = 1,
            bordercolor = PALETTE["border"],
            steps = [
                dict(range=[0,  30],  color="rgba(0,230,118,0.15)"),
                dict(range=[30, 60],  color="rgba(255,145,0,0.15)"),
                dict(range=[60, 100], color="rgba(255,23,68,0.15)"),
            ],
            threshold = dict(
                line=dict(color=PALETTE["risk_hi"], width=2),
                thickness=0.75, value=70
            ),
        ),
    ))
    fig.update_layout(
        plot_bgcolor  = "rgba(0,0,0,0)",
        paper_bgcolor = "rgba(0,0,0,0)",
        height = 200,
        margin = dict(l=20, r=20, t=40, b=20),
        font   = dict(family="Share Tech Mono", color=PALETTE["text"]),
    )
    return fig


# ── ECONOMICS CHARTS ─────────────────────────────────────────────────────────

def economics_overview_chart(df: pd.DataFrame, capex: Dict, annual_opex: float) -> go.Figure:
    """NPV and cost-per-kWh over simulation lifetime."""
    fig = make_subplots(specs=[[{"secondary_y": True}]])

    fig.add_trace(go.Scatter(
        x=df["time_years"], y=df["npv_MUSD"],
        name="NPV ($M)",
        line=dict(color=PALETTE["power"], width=2.5),
        fill="tozeroy",
        fillcolor="rgba(0,230,118,0.08)",
    ), secondary_y=False)

    # Mark NPV breakeven
    bt_idx = df[df["npv_MUSD"] >= 0].index
    if len(bt_idx):
        bt_yr = df.loc[bt_idx[0], "time_years"]
        fig.add_vline(x=bt_yr, line=dict(color=PALETTE["power"], width=1.5, dash="dash"))
        fig.add_annotation(x=bt_yr, y=df["npv_MUSD"].max() * 0.7,
                           text=f"Breakeven<br>{bt_yr:.1f} yr",
                           showarrow=False,
                           font=dict(color=PALETTE["power"], size=10, family="Share Tech Mono"),
                           bgcolor="rgba(0,0,0,0.7)", bordercolor=PALETTE["power"], borderwidth=1)

    fig.add_trace(go.Scatter(
        x=df["time_years"], y=df["cost_per_kWh"] * 100,  # $/kWh → ¢/kWh
        name="Cost (¢/kWh)",
        line=dict(color=PALETTE["amber"], width=2, dash="dot"),
    ), secondary_y=True)

    fig.update_layout(
        **LAYOUT_BASE,
        title=dict(text="ECONOMICS — NPV & LEVELISED COST OF ENERGY",
                   font=dict(size=12, color=PALETTE["amber"], family="Share Tech Mono"), x=0.01),
        height=380,
    )
    fig.update_xaxes(**AXIS_STYLE, title="Years")
    fig.update_yaxes(**AXIS_STYLE, title="NPV ($M)", secondary_y=False)
    fig.update_yaxes(**AXIS_STYLE, title="LCOE (¢/kWh)", secondary_y=True)
    return fig


def capex_breakdown_chart(capex: Dict) -> go.Figure:
    """CAPEX breakdown donut chart."""
    labels  = [k.replace("_", " ").title() for k in capex if k != "total"]
    values  = [v for k, v in capex.items() if k != "total"]
    colours = [PALETTE["hot"], PALETTE["warm"], PALETTE["cold"], PALETTE["cyan"],
               PALETTE["power"], PALETTE["amber"]]

    fig = go.Figure(go.Pie(
        labels    = labels,
        values    = values,
        hole      = 0.55,
        textinfo  = "label+percent",
        textfont  = dict(size=10, family="Share Tech Mono, monospace",
                         color=PALETTE["text"]),
        marker    = dict(colors=colours[:len(labels)],
                         line=dict(color=PALETTE["bg"], width=2)),
        hovertemplate = "%{label}: $%{value:.1f}M<extra></extra>",
    ))

    fig.add_annotation(
        text=f"TOTAL<br><b>${capex['total']:.1f}M</b>",
        x=0.5, y=0.5, showarrow=False,
        font=dict(size=13, color=PALETTE["amber"], family="Share Tech Mono"),
    )

    fig.update_layout(
        **LAYOUT_BASE,
        title=dict(text="CAPEX BREAKDOWN",
                   font=dict(size=12, color=PALETTE["amber"], family="Share Tech Mono"), x=0.01),
        height=360,
        showlegend=True,
    )
    return fig


def well_economics_table(wells: List[WellConfig]) -> go.Figure:
    """Per-well cost summary table."""
    wids   = [w.well_id for w in wells]
    types  = [w.well_type.upper() for w in wells]
    depths = [f"{w.depth_m:.0f} m" for w in wells]
    costs  = [f"${w.drill_cost_MUSD:.1f}M" for w in wells]
    flows  = [f"{w.target_flow_kgs:.0f} kg/s" for w in wells]

    colours_header = [PALETTE["border"]] * 5
    fill_odd       = "rgba(22,22,22,0.8)"
    fill_even      = "rgba(16,16,16,0.8)"

    cell_fills = []
    for i in range(len(wids)):
        cell_fills.append(fill_odd if i % 2 == 0 else fill_even)

    fig = go.Figure(go.Table(
        header=dict(
            values=["WELL ID", "TYPE", "DEPTH", "DRILL COST", "TARGET FLOW"],
            fill_color=PALETTE["border"],
            font=dict(color=PALETTE["amber"], size=11, family="Share Tech Mono"),
            align="center", height=30,
        ),
        cells=dict(
            values=[wids, types, depths, costs, flows],
            fill_color=[cell_fills] * 5,
            font=dict(color=[
                [PALETTE["hot"] if t == "PRODUCTION" else PALETTE["cold"] for t in types],
                [PALETTE["hot"] if t == "PRODUCTION" else PALETTE["cold"] for t in types],
                [PALETTE["text"]] * len(wids),
                [PALETTE["amber"]] * len(wids),
                [PALETTE["text"]] * len(wids),
            ], size=10, family="Share Tech Mono"),
            align="center", height=26,
        ),
    ))

    fig.update_layout(
        **LAYOUT_BASE,
        title=dict(text="WELL INVENTORY & COSTS",
                   font=dict(size=12, color=PALETTE["amber"], family="Share Tech Mono"), x=0.01),
        height=max(220, 80 + len(wids) * 28),
    )
    return fig


# ── OPTIMISATION CHARTS ──────────────────────────────────────────────────────

def optimisation_metrics_chart(df: pd.DataFrame) -> go.Figure:
    """Energy efficiency ratio and cost per kWh over time."""
    fig = make_subplots(rows=1, cols=2, subplot_titles=["COST PER kWh", "SYSTEM EFFICIENCY"])

    fig.add_trace(go.Scatter(
        x=df["time_years"], y=df["cost_per_kWh"] * 100,
        name="LCOE (¢/kWh)", line=dict(color=PALETTE["amber"], width=2),
    ), row=1, col=1)

    # Efficiency: net / thermal
    if "thermal_power_MW" in df.columns:
        mask = df["thermal_power_MW"] > 0.01
        eff  = np.where(mask, df["net_power_MW"] / df["thermal_power_MW"] * 100, np.nan)
        fig.add_trace(go.Scatter(
            x=df["time_years"], y=eff,
            name="Net/Thermal Ratio (%)", line=dict(color=PALETTE["power"], width=2),
        ), row=1, col=2)

    fig.update_layout(
        **LAYOUT_BASE,
        title=dict(text="OPTIMISATION METRICS", font=dict(size=12, color=PALETTE["cyan"],
                   family="Share Tech Mono"), x=0.01),
        height=340, showlegend=False,
    )
    fig.update_xaxes(**AXIS_STYLE, title="Years")
    fig.update_yaxes(**AXIS_STYLE)
    return fig


def pressure_evolution_chart(df: pd.DataFrame) -> go.Figure:
    """Mean reservoir pressure over time."""
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=df["time_years"], y=df["pressure_mean"],
        name="Mean Pressure",
        line=dict(color=PALETTE["cyan"], width=2),
        fill="tozeroy", fillcolor="rgba(0,229,255,0.06)",
    ))

    return _apply_layout(fig, "RESERVOIR PRESSURE EVOLUTION  [MPa]")
