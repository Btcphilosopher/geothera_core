import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import { join } from 'node:path';
import { GoogleGenAI } from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
const angularApp = new AngularNodeAppEngine();

app.use(express.json());

// Initialize Gemini API if key is present
const apiKey = process.env['GEMINI_API_KEY'];
const ai = apiKey ? new GoogleGenAI({ apiKey }) : null;

// ============================================================================
// CORNWALL LITHIUM DIGITAL TWIN REST API v1
// ============================================================================

app.get('/api/v1/geology', (_req, res) => {
  res.json({
    location: 'Cornwall Granitic Subsurface, UK',
    geologicalSetting: 'Carnmenellis Granite Massif & Hydrothermal Fault Networks',
    rockTypes: ['granite', 'pegmatite', 'country_rock', 'fault_zone', 'aquifer', 'geothermal_reservoir'],
    averageGradePpm: 808,
    provenanceNotice: 'DEMONSTRATION MODEL - NOT SITE DATA'
  });
});

app.get('/api/v1/resources', (_req, res) => {
  res.json({
    resourceClasses: {
      measured: { tonnageMt: 14.2, averageGradePpm: 880, containedLithiumTonnes: 12496 },
      indicated: { tonnageMt: 28.5, averageGradePpm: 810, containedLithiumTonnes: 23085 },
      inferred: { tonnageMt: 42.0, averageGradePpm: 760, containedLithiumTonnes: 31920 }
    },
    p10Tonnes: 74200,
    p50Tonnes: 67500,
    p90Tonnes: 58900
  });
});

app.get('/api/v1/process', (_req, res) => {
  res.json({
    architectures: ['HARD_ROCK', 'GEOTHERMAL_BRINE'],
    units: ['CRUSHER', 'SAG_MILL', 'BALL_MILL', 'FLOTATION', 'DLE_CONTACTOR', 'EVAPORATOR', 'CHEMICAL_REACTOR'],
    targetProducts: ['LITHIUM_CARBONATE', 'LITHIUM_HYDROXIDE', 'LITHIUM_CHLORIDE']
  });
});

app.post('/api/v1/ai-analysis', async (req, res) => {
  const body = req.body || {};
  if (!ai) {
    return res.json({
      summary: `Cornwall Lithium Twin running in ${body.mode || 'GEOTHERMAL_BRINE'} mode. System output is ${body.lithiumProductionKgH || 79.2} kg Li/h.`,
      bottlenecks: ['Brine production well head pressure gradient', 'DLE sorbent regeneration kinetics'],
      recommendations: ['Optimize DLE eluate concentration ratio', 'Deploy geothermal thermal heat recovery for crystallizer pre-heating'],
      massBalanceAssessment: `Mass balance error is ${(body.massBalanceImbalancePct || 0).toFixed(4)}% (< 0.01% limit).`,
      decarbonizationAdvice: 'Incorporate solar PV + BESS array to eliminate residual Scope 2 grid emissions.'
    });
  }

  try {
    const prompt = `You are a senior metallurgist and chemical process engineer evaluating a digital twin simulation for a Cornwall Lithium operation in the UK.
Given the current digital twin state:
- Extraction Mode: ${body.mode}
- Target Product: ${body.product}
- Active Lithium Production: ${body.lithiumProductionKgH} kg Li/h (${body.productOutputTonnesDay} t/day product)
- Mass Balance Imbalance: ${body.massBalanceImbalancePct}%
- Total Power Demand: ${body.totalPowerMW} MW
- Freshwater Intake: ${body.freshwaterM3H} m³/h
- Carbon Intensity: ${body.carbonIntensityKgCO2PerKgLi} kg CO2/kg Li
- Active Asset Failures: ${JSON.stringify(body.failures)}

Provide a concise technical JSON assessment with fields:
- summary: 2-3 sentence industrial summary
- bottlenecks: array of 2 bullet points
- recommendations: array of 2 actionable engineering improvements
- massBalanceAssessment: 1 sentence mass balance check statement
- decarbonizationAdvice: 1 sentence decarbonization note
Format exclusively as valid JSON without markdown formatting code blocks.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt
    });

    const text = response.text || '';
    const cleanText = text.replace(/```json/g, '').replace(/```/g, '').trim();
    const parsed = JSON.parse(cleanText);
    return res.json(parsed);
  } catch (err: unknown) {
    const errorMessage = err instanceof Error ? err.message : String(err);
    console.error('Gemini API execution error:', errorMessage);
    return res.json({
      summary: `Cornwall Digital Twin simulation state evaluated for ${body.mode || 'GEOTHERMAL'} extraction.`,
      bottlenecks: ['Thermal energy transfer efficiency across brine heat exchangers', 'Reagent dosing rate in crystallization tank'],
      recommendations: ['Increase water recycling ratio to 90%', 'Optimize DLE desorption cycle duration'],
      massBalanceAssessment: 'Mass balance check satisfies physical input/output conservation laws.',
      decarbonizationAdvice: 'Utilize geothermal process heat for chemical reactor thermal requirement.'
    });
  }
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }
    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

export const reqHandler = createNodeRequestHandler(app);
