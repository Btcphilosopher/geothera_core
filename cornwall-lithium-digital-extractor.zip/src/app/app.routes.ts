import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: 'dashboard', loadComponent: () => import('./views/dashboard/dashboard').then(m => m.Dashboard) },
  { path: 'geology', loadComponent: () => import('./views/geology/geology').then(m => m.Geology) },
  { path: 'mine-designer', loadComponent: () => import('./views/mine-designer/mine-designer').then(m => m.MineDesigner) },
  { path: 'process-plant', loadComponent: () => import('./views/process-plant/process-plant').then(m => m.ProcessPlant) },
  { path: 'flowsheet', loadComponent: () => import('./views/flowsheet/flowsheet').then(m => m.Flowsheet) },
  { path: 'twin-3d', loadComponent: () => import('./views/twin-3d/twin-3d').then(m => m.Twin3D) },
  { path: 'water-energy', loadComponent: () => import('./views/water-energy/water-energy').then(m => m.WaterEnergy) },
  { path: 'maintenance', loadComponent: () => import('./views/maintenance/maintenance').then(m => m.Maintenance) },
  { path: 'scenarios', loadComponent: () => import('./views/scenarios/scenarios').then(m => m.Scenarios) },
  { path: 'report', loadComponent: () => import('./views/report/report').then(m => m.Report) },
  { path: '**', redirectTo: 'dashboard' }
];
