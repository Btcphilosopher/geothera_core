import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwin } from '../../core/services/digital-twin';
import { ProvenanceBadge } from '../../components/provenance-badge/provenance-badge';

@Component({
  selector: 'app-mine-designer',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule, ProvenanceBadge],
  template: `
    <div class="p-4 md:p-6 space-y-6 max-w-[1600px] mx-auto text-slate-100 font-sans">
      <!-- Header -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <h1 class="text-xl font-mono font-bold uppercase tracking-wide text-slate-100 flex items-center gap-2">
            <mat-icon class="text-amber-400">precision_manufacturing</mat-icon>
            Mine & Geothermal Well Engineering Designer
          </h1>
          <p class="text-xs font-mono text-slate-400 mt-0.5">
            Hard-Rock Underground Development / Open Pit Layout · Deep Geothermal Well Simulator
          </p>
        </div>
        <div class="flex items-center gap-2 font-mono text-xs">
          <app-provenance-badge type="ENGINEERING_ASSUMPTION"></app-provenance-badge>
          <span class="text-slate-400">ACTIVE ARCHITECTURE: {{ twin.extractionMode() }}</span>
        </div>
      </div>

      <!-- Tab Switcher -->
      <div class="flex items-center gap-2 p-1 bg-slate-900 border border-slate-800 rounded-lg w-fit font-mono text-xs">
        <button 
          (click)="activeTab.set('GEOTHERMAL')"
          [class]="activeTab() === 'GEOTHERMAL' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'"
          class="px-3 py-1.5 rounded transition-colors flex items-center gap-1">
          <mat-icon class="text-sm">hot_tub</mat-icon>
          Geothermal Well & Reservoir
        </button>
        <button 
          (click)="activeTab.set('HARD_ROCK')"
          [class]="activeTab() === 'HARD_ROCK' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'"
          class="px-3 py-1.5 rounded transition-colors flex items-center gap-1">
          <mat-icon class="text-sm">landscape</mat-icon>
          Hard-Rock Mine Layout & Fleet
        </button>
      </div>

      @if (activeTab() === 'GEOTHERMAL') {
        <!-- GEOTHERMAL BRINE WELL SECTION -->
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 font-mono">
          <!-- Left: Geothermal Reservoir Parameters -->
          <div class="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-4">
            <div class="flex items-center justify-between pb-2 border-b border-slate-800">
              <h2 class="text-xs font-bold tracking-wider text-slate-300 uppercase flex items-center gap-1.5">
                <mat-icon class="text-amber-400 text-sm">thermostat</mat-icon>
                Deep Geothermal Reservoir Model
              </h2>
              <span class="text-[10px] text-emerald-400 font-bold">CNL-GT-01</span>
            </div>

            @if (twin.geothermalReservoir(); as res) {
              <div class="space-y-3 text-xs">
                <div class="flex justify-between items-center p-2 bg-slate-950 rounded border border-slate-800">
                  <span class="text-slate-400">Target Well Depth</span>
                  <span class="font-bold text-slate-200 tabular-nums">{{ res.depthM.value }} m OD</span>
                </div>

                <div class="flex justify-between items-center p-2 bg-slate-950 rounded border border-slate-800">
                  <span class="text-slate-400">Bottom-Hole Temperature</span>
                  <span class="font-bold text-red-400 tabular-nums">{{ res.reservoirTemperatureC.value }}°C</span>
                </div>

                <div class="flex justify-between items-center p-2 bg-slate-950 rounded border border-slate-800">
                  <span class="text-slate-400">Reservoir Hydrostatic Pressure</span>
                  <span class="font-bold text-amber-400 tabular-nums">{{ res.reservoirPressureBar.value }} bar</span>
                </div>

                <div class="flex justify-between items-center p-2 bg-slate-950 rounded border border-slate-800">
                  <span class="text-slate-400">Brine Lithium Grade</span>
                  <span class="font-bold text-emerald-400 tabular-nums">{{ res.brineLithiumMgL.value }} mg/L</span>
                </div>

                <div class="space-y-1 pt-2">
                  <div class="flex justify-between text-xs">
                    <span class="text-slate-300">Production Flow Rate</span>
                    <span class="text-amber-400 font-bold tabular-nums">{{ res.designFlowRateLs.value }} L/s</span>
                  </div>
                  <input 
                    type="range" min="30" max="250" step="5" 
                    [value]="res.designFlowRateLs.value"
                    (input)="onFlowChange($event)"
                    class="w-full h-1.5 bg-slate-800 rounded appearance-none cursor-pointer accent-amber-500" />
                </div>
              </div>
            }

            <!-- Brine Chemistry Molar Profile -->
            <div class="pt-2 border-t border-slate-800 space-y-2">
              <span class="text-[10px] text-slate-400 uppercase tracking-wider block font-bold">Molar Brine Chemistry Profile</span>
              <div class="grid grid-cols-2 gap-2 text-[11px]">
                <div class="p-1.5 bg-slate-950 rounded border border-slate-800 flex justify-between">
                  <span class="text-slate-400">Lithium (Li+)</span>
                  <span class="font-bold text-emerald-400">31.7 mmol/L</span>
                </div>
                <div class="p-1.5 bg-slate-950 rounded border border-slate-800 flex justify-between">
                  <span class="text-slate-400">Sodium (Na+)</span>
                  <span class="font-bold text-slate-200">630.7 mmol/L</span>
                </div>
                <div class="p-1.5 bg-slate-950 rounded border border-slate-800 flex justify-between">
                  <span class="text-slate-400">Calcium (Ca2+)</span>
                  <span class="font-bold text-slate-200">94.8 mmol/L</span>
                </div>
                <div class="p-1.5 bg-slate-950 rounded border border-slate-800 flex justify-between">
                  <span class="text-slate-400">Magnesium (Mg2+)</span>
                  <span class="font-bold text-slate-200">7.4 mmol/L</span>
                </div>
              </div>
            </div>
          </div>

          <!-- Right: Synthetic Well Decline Curve & Pumping Power Simulator -->
          <div class="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-4">
            <div class="flex items-center justify-between pb-2 border-b border-slate-800">
              <h2 class="text-xs font-bold tracking-wider text-slate-300 uppercase flex items-center gap-1.5">
                <mat-icon class="text-amber-400 text-sm">show_chart</mat-icon>
                Production Well Decline & Pumping Power Simulator
              </h2>
              <span class="text-[10px] text-slate-400">20-YEAR FORECAST</span>
            </div>

            <!-- Schematic Well Diagram & Decline Curve -->
            <div class="h-60 bg-slate-950 border border-slate-800 rounded-lg p-4 flex flex-col justify-between relative overflow-hidden">
              <div class="flex justify-between items-center text-xs text-slate-400">
                <span>Synthetic Flow Decline Curve (-1.8%/yr)</span>
                <span class="text-amber-400 font-bold">Year 1: 100 L/s → Year 20: 71 L/s</span>
              </div>

              <!-- SVG Line Graph -->
              <svg class="w-full h-36" viewBox="0 0 500 120">
                <path d="M 10 20 Q 250 45 490 85" fill="none" stroke="#f59e0b" stroke-width="3" />
                <path d="M 10 20 Q 250 45 490 85 L 490 110 L 10 110 Z" fill="rgba(245, 158, 11, 0.1)" />
                <line x1="10" y1="110" x2="490" y2="110" stroke="#334155" stroke-width="1" />
                <text x="10" y="118" fill="#64748b" font-size="9">Yr 0</text>
                <text x="240" y="118" fill="#64748b" font-size="9">Yr 10</text>
                <text x="470" y="118" fill="#64748b" font-size="9">Yr 20</text>
              </svg>

              <div class="flex justify-between text-[11px] text-slate-400 pt-2 border-t border-slate-800">
                <span>ESP Well Pump Power: <strong class="text-amber-400">{{ (twin.geothermalReservoir().designFlowRateLs.value * 0.0068).toFixed(2) }} MW</strong></span>
                <span>Reinjection Pressure: <strong class="text-sky-400">14.2 bar</strong></span>
              </div>
            </div>
          </div>
        </div>
      } @else {
        <!-- HARD ROCK MINE SECTION -->
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 font-mono">
          <!-- Hard-Rock Mine Design Parameters -->
          <div class="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-4">
            <div class="flex items-center justify-between pb-2 border-b border-slate-800">
              <h2 class="text-xs font-bold tracking-wider text-slate-300 uppercase flex items-center gap-1.5">
                <mat-icon class="text-amber-400 text-sm">engineering</mat-icon>
                Underground Mine Development Specs
              </h2>
              <span class="text-[10px] text-amber-400 font-bold">SUB-LEVEL STOPING</span>
            </div>

            @if (twin.hardRockMine(); as mine) {
              <div class="space-y-3 text-xs">
                <div class="flex justify-between items-center p-2 bg-slate-950 rounded border border-slate-800">
                  <span class="text-slate-400">Decline Length</span>
                  <span class="font-bold text-slate-200 tabular-nums">{{ mine.declineLengthM }} m ({{ mine.declineGradientPct }}% gradient)</span>
                </div>

                <div class="flex justify-between items-center p-2 bg-slate-950 rounded border border-slate-800">
                  <span class="text-slate-400">Production Levels</span>
                  <span class="font-bold text-amber-400 tabular-nums">{{ mine.numberOfLevels }} Levels @ {{ mine.levelSpacingM }}m spacing</span>
                </div>

                <div class="flex justify-between items-center p-2 bg-slate-950 rounded border border-slate-800">
                  <span class="text-slate-400">Shaft Depth</span>
                  <span class="font-bold text-slate-200 tabular-nums">{{ mine.shaftDepthM }} m</span>
                </div>

                <div class="flex justify-between items-center p-2 bg-slate-950 rounded border border-slate-800">
                  <span class="text-slate-400">Ventilation Flow</span>
                  <span class="font-bold text-sky-400 tabular-nums">{{ mine.ventilationCapacityM3s }} m³/s</span>
                </div>

                <div class="space-y-1 pt-2">
                  <div class="flex justify-between text-xs">
                    <span class="text-slate-300">Ore Mining Throughput</span>
                    <span class="text-amber-400 font-bold tabular-nums">{{ mine.targetOreThroughputTonnesDay }} t/day</span>
                  </div>
                  <input 
                    type="range" min="500" max="6000" step="250" 
                    [value]="mine.targetOreThroughputTonnesDay"
                    (input)="onOreChange($event)"
                    class="w-full h-1.5 bg-slate-800 rounded appearance-none cursor-pointer accent-amber-500" />
                </div>
              </div>
            }
          </div>

          <!-- Mining Equipment Fleet -->
          <div class="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-4">
            <div class="flex items-center justify-between pb-2 border-b border-slate-800">
              <h2 class="text-xs font-bold tracking-wider text-slate-300 uppercase flex items-center gap-1.5">
                <mat-icon class="text-amber-400 text-sm">directions_car</mat-icon>
                Mining Equipment Fleet Manager
              </h2>
              <span class="text-[10px] text-emerald-400 font-bold">ELECTRIC FLEET AVAILABLE</span>
            </div>

            <div class="space-y-2 text-xs">
              @for (eq of twin.miningFleet(); track eq.id) {
                <div class="p-3 bg-slate-950 border border-slate-800 rounded flex items-center justify-between">
                  <div class="space-y-0.5">
                    <div class="flex items-center gap-2">
                      <span class="font-bold text-slate-200">{{ eq.name }}</span>
                      @if (eq.isElectric) {
                        <span class="px-1.5 py-0.5 bg-emerald-950 text-emerald-400 border border-emerald-800 text-[9px] rounded font-bold">
                          BATTERY ELECTRIC
                        </span>
                      }
                    </div>
                    <div class="text-[11px] text-slate-400">
                      Capacity: {{ eq.capacityTonnes }}t · Power: {{ eq.powerkW }} kW · Availability: {{ eq.availabilityPct }}%
                    </div>
                  </div>

                  <div class="text-right space-y-0.5">
                    <span class="px-2 py-0.5 rounded text-[10px] font-bold"
                          [class]="eq.status === 'OPERATIONAL' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-rose-950 text-rose-400 border border-rose-800'">
                      ● {{ eq.status }}
                    </span>
                    @if (eq.batteryCapacitykWh) {
                      <div class="text-[10px] text-amber-400">SOC: {{ eq.currentSocPct }}% (Regen: {{ eq.regenBrakingEfficiencyPct }}%)</div>
                    }
                  </div>
                </div>
              }
            </div>
          </div>
        </div>
      }
    </div>
  `
})
export class MineDesigner {
  twin = inject(DigitalTwin);
  activeTab = signal<'GEOTHERMAL' | 'HARD_ROCK'>('GEOTHERMAL');

  onFlowChange(event: Event) {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.twin.setGeothermalFlowRate(val);
  }

  onOreChange(event: Event) {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.twin.setHardRockOreThroughput(val);
  }
}
