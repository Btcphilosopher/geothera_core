import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwin } from '../../core/services/digital-twin';
import { ProvenanceBadge } from '../../components/provenance-badge/provenance-badge';

@Component({
  selector: 'app-water-energy',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule, ProvenanceBadge],
  template: `
    <div class="p-4 md:p-6 space-y-6 max-w-[1600px] mx-auto text-slate-100 font-sans">
      <!-- Title -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <h1 class="text-xl font-mono font-bold uppercase tracking-wide text-slate-100 flex items-center gap-2">
            <mat-icon class="text-sky-400">water_drop</mat-icon>
            Water & Energy Digital Twin
          </h1>
          <p class="text-xs font-mono text-slate-400 mt-0.5">
            Closed-Loop Water Network · Electrical Load & Renewable BESS Integration · Carbon Footprint Model
          </p>
        </div>
        <div class="flex items-center gap-2 font-mono text-xs">
          <app-provenance-badge type="SIMULATION_OUTPUT"></app-provenance-badge>
          <span class="text-slate-400">SCOPES 1, 2 & 3 CARBON MODEL</span>
        </div>
      </div>

      <!-- Water Network Section -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 font-mono">
        <div class="lg:col-span-6 bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-4">
          <div class="flex items-center justify-between pb-2 border-b border-slate-800">
            <h2 class="text-xs font-bold tracking-wider text-slate-300 uppercase flex items-center gap-1.5">
              <mat-icon class="text-sky-400 text-sm">water_drop</mat-icon>
              Water Network & Recycling Loop
            </h2>
            <span class="text-[10px] text-sky-400 font-bold">RECYCLE: {{ twin.waterRecycleRatio() }}%</span>
          </div>

          @if (twin.waterNetwork(); as w) {
            <div class="space-y-3 text-xs">
              <div class="grid grid-cols-2 gap-3">
                <div class="p-3 bg-slate-950 rounded border border-slate-800">
                  <span class="text-[10px] text-slate-500 uppercase block">FRESHWATER INTAKE</span>
                  <span class="text-xl font-bold text-sky-400 tabular-nums">{{ w.freshwaterIntakeM3H.toFixed(1) }} m³/h</span>
                </div>
                <div class="p-3 bg-slate-950 rounded border border-slate-800">
                  <span class="text-[10px] text-slate-500 uppercase block">PROCESS DEMAND</span>
                  <span class="text-xl font-bold text-slate-100 tabular-nums">{{ w.processWaterDemandM3H.toFixed(1) }} m³/h</span>
                </div>
              </div>

              <!-- Recycling Efficiency Slider -->
              <div class="space-y-1.5 p-3 bg-slate-950 rounded border border-slate-800">
                <div class="flex justify-between">
                  <span class="text-slate-300">Closed-Loop Water Recycling</span>
                  <span class="text-sky-400 font-bold tabular-nums">{{ w.waterRecycleRatioPct }}%</span>
                </div>
                <input 
                  type="range" min="20" max="98" step="1"
                  [value]="w.waterRecycleRatioPct"
                  (input)="onRecycleChange($event)"
                  class="w-full h-1.5 bg-slate-800 rounded appearance-none cursor-pointer accent-sky-500" />
                <div class="text-[10px] text-slate-500 flex justify-between">
                  <span>Recycled: {{ w.recycledWaterM3H.toFixed(1) }} m³/h</span>
                  <span>Wastewater: {{ w.wastewaterOutputM3H.toFixed(1) }} m³/h</span>
                </div>
              </div>

              <div class="flex justify-between p-2 bg-slate-950 rounded border border-slate-800">
                <span class="text-slate-400">Water Consumption per Tonne Product</span>
                <span class="font-bold text-amber-400 tabular-nums">{{ w.waterConsumptionPerTonProductM3.toFixed(2) }} m³/t</span>
              </div>
            </div>
          }
        </div>

        <!-- Industrial Power System & Renewable BESS -->
        <div class="lg:col-span-6 bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-4">
          <div class="flex items-center justify-between pb-2 border-b border-slate-800">
            <h2 class="text-xs font-bold tracking-wider text-slate-300 uppercase flex items-center gap-1.5">
              <mat-icon class="text-amber-400 text-sm">bolt</mat-icon>
              Industrial Energy & Battery Storage (BESS)
            </h2>
            <span class="text-[10px] text-amber-400 font-bold">12.0 MWh BESS</span>
          </div>

          @if (twin.energyNetwork(); as e) {
            <div class="space-y-3 text-xs">
              <div class="grid grid-cols-2 gap-3">
                <div class="p-3 bg-slate-950 rounded border border-slate-800">
                  <span class="text-[10px] text-slate-500 uppercase block">TOTAL POWER DEMAND</span>
                  <span class="text-xl font-bold text-amber-400 tabular-nums">{{ e.totalPowerDemandMW.toFixed(2) }} MW</span>
                </div>
                <div class="p-3 bg-slate-950 rounded border border-slate-800">
                  <span class="text-[10px] text-slate-500 uppercase block">GRID IMPORT</span>
                  <span class="text-xl font-bold text-slate-100 tabular-nums">{{ e.gridImportMW.toFixed(2) }} MW</span>
                </div>
              </div>

              <!-- Supply Mix Breakdown -->
              <div class="p-3 bg-slate-950 rounded border border-slate-800 space-y-2">
                <span class="text-[10px] text-slate-400 uppercase font-bold block">Renewable Generation Mix</span>
                <div class="grid grid-cols-3 gap-2 text-[11px]">
                  <div>Solar PV: <strong class="text-amber-400">{{ e.solarGenerationMW }} MW</strong></div>
                  <div>Wind Turbines: <strong class="text-sky-400">{{ e.windGenerationMW }} MW</strong></div>
                  <div>Geothermal Power: <strong class="text-red-400">{{ e.geothermalThermalPowerMW }} MW</strong></div>
                </div>
              </div>

              <!-- BESS Battery Status -->
              <div class="p-3 bg-slate-950 rounded border border-slate-800 space-y-1">
                <div class="flex justify-between text-slate-300">
                  <span>Battery Storage SOC</span>
                  <span class="text-emerald-400 font-bold tabular-nums">{{ e.bessSocPct }}%</span>
                </div>
                <div class="w-full bg-slate-800 h-2 rounded overflow-hidden">
                  <div class="bg-emerald-500 h-full" [style.width.%]="e.bessSocPct"></div>
                </div>
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Carbon Footprint Model (Scope 1, 2, 3) -->
      @if (twin.energyNetwork(); as e) {
        <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3 font-mono text-xs">
          <div class="flex items-center justify-between pb-2 border-b border-slate-800">
            <h3 class="font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <mat-icon class="text-emerald-400 text-sm">eco</mat-icon>
              Emissions & Decarbonization Model
            </h3>
            <span class="text-emerald-400 font-bold">
              INTENSITY: {{ e.carbonIntensityKgCO2ePerKgProduct.toFixed(2) }} kg CO2e / kg Product
            </span>
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div class="p-3 bg-slate-950 rounded border border-slate-800 space-y-1">
              <span class="text-[10px] text-slate-500 uppercase block">SCOPE 1 (DIRECT)</span>
              <span class="text-lg font-bold text-slate-200 tabular-nums">{{ e.scope1CO2eKgH.toFixed(0) }} kg CO2e/h</span>
              <span class="text-[10px] text-slate-400 block">Fuel & Process Heating</span>
            </div>

            <div class="p-3 bg-slate-950 rounded border border-slate-800 space-y-1">
              <span class="text-[10px] text-slate-500 uppercase block">SCOPE 2 (GRID ELEC)</span>
              <span class="text-lg font-bold text-amber-400 tabular-nums">{{ e.scope2CO2eKgH.toFixed(0) }} kg CO2e/h</span>
              <span class="text-[10px] text-slate-400 block">UK Grid Factor (210 g/kWh)</span>
            </div>

            <div class="p-3 bg-slate-950 rounded border border-slate-800 space-y-1">
              <span class="text-[10px] text-slate-500 uppercase block">SCOPE 3 (REAGENTS)</span>
              <span class="text-lg font-bold text-slate-200 tabular-nums">{{ e.scope3CO2eKgH.toFixed(0) }} kg CO2e/h</span>
              <span class="text-[10px] text-slate-400 block">Chemical Reagent Embodied Carbon</span>
            </div>
          </div>
        </div>
      }
    </div>
  `
})
export class WaterEnergy {
  twin = inject(DigitalTwin);

  onRecycleChange(event: Event) {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.twin.setWaterRecycleRatio(val);
  }
}
