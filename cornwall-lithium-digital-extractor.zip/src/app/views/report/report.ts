import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwin } from '../../core/services/digital-twin';

@Component({
  selector: 'app-report',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="p-4 md:p-6 space-y-6 max-w-[1200px] mx-auto text-slate-100 font-sans">
      <!-- Actions Bar -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-4 font-mono text-xs">
        <div class="flex items-center gap-2">
          <mat-icon class="text-amber-400">description</mat-icon>
          <span class="font-bold uppercase text-slate-200">Engineering Design Study Report</span>
        </div>
        <div class="flex items-center gap-2">
          <button (click)="printReport()" class="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded border border-slate-700 flex items-center gap-1 font-bold">
            <mat-icon class="text-xs">print</mat-icon>
            Print / Save PDF
          </button>
          <button (click)="exportJson()" class="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded font-bold flex items-center gap-1">
            <mat-icon class="text-xs">download</mat-icon>
            Export JSON Data
          </button>
        </div>
      </div>

      <!-- Printable Report Document Shell -->
      <div id="printableReport" class="bg-slate-900 border border-slate-800 rounded-xl p-8 space-y-6 font-mono text-xs text-slate-200 leading-relaxed shadow-2xl">
        
        <!-- Document Header Block -->
        <div class="border-b-2 border-amber-500/80 pb-4 space-y-2">
          <div class="flex justify-between items-start">
            <div>
              <h1 class="text-lg font-bold uppercase text-slate-100 tracking-wider">
                CORNWALL LITHIUM PLANT — ENGINEERING DESIGN STUDY
              </h1>
              <p class="text-slate-400 text-[11px] mt-0.5">
                COMPUTATIONAL DIGITAL TWIN SIMULATION & FEASIBILITY REPORT
              </p>
            </div>
            <div class="text-right text-[10px] text-slate-400 space-y-0.5">
              <div>REPORT ID: CNL-DS-2026-001</div>
              <div>DATE: 01 OCTOBER 2026</div>
              <div class="text-amber-400 font-bold">MODE: {{ twin.extractionMode() }}</div>
            </div>
          </div>
        </div>

        <!-- 1. Executive Summary -->
        <div class="space-y-2">
          <h2 class="text-sm font-bold text-amber-400 uppercase tracking-wide border-b border-slate-800 pb-1">
            1. Executive Summary & Design Scope
          </h2>
          <p class="text-slate-300">
            This study evaluates the complete industrial production chain for a modern Cornwall lithium operation utilizing 
            <strong>{{ twin.extractionMode() === 'HARD_ROCK' ? 'Hard-Rock Mining (Spodumene Granite / Pegmatite)' : 'Deep Geothermal Brine (Direct Lithium Extraction - DLE)' }}</strong> 
            architecure targeting <strong>{{ twin.targetProduct().replace('_', ' ') }}</strong> product output.
          </p>
        </div>

        <!-- 2. Physical Production & Mass Balance -->
        <div class="space-y-2">
          <h2 class="text-sm font-bold text-amber-400 uppercase tracking-wide border-b border-slate-800 pb-1">
            2. Mass Balance & Production Rates
          </h2>
          <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-950 p-3 rounded border border-slate-800">
            <div>
              <span class="text-[10px] text-slate-500 block">LITHIUM RATE</span>
              <strong class="text-emerald-400 text-sm">{{ twin.activeLithiumProductionKgH().toFixed(1) }} kg Li/h</strong>
            </div>
            <div>
              <span class="text-[10px] text-slate-500 block">PRODUCT RATE</span>
              <strong class="text-slate-100 text-sm">{{ twin.activeProductOutputTonnesDay().toFixed(2) }} t/day</strong>
            </div>
            <div>
              <span class="text-[10px] text-slate-500 block">MASS IMBALANCE</span>
              <strong class="text-emerald-400 text-sm">{{ twin.massBalance().imbalancePercent.toFixed(4) }}%</strong>
            </div>
            <div>
              <span class="text-[10px] text-slate-500 block">ANNUAL OUTPUT</span>
              <strong class="text-slate-100 text-sm">{{ (twin.activeProductOutputTonnesDay() * 350).toFixed(0) }} t/yr</strong>
            </div>
          </div>
        </div>

        <!-- 3. Water & Energy Utilities -->
        <div class="space-y-2">
          <h2 class="text-sm font-bold text-amber-400 uppercase tracking-wide border-b border-slate-800 pb-1">
            3. Utilities, Water Network & Carbon Intensity
          </h2>
          <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-950 p-3 rounded border border-slate-800">
            <div>
              <span class="text-[10px] text-slate-500 block">POWER DEMAND</span>
              <strong class="text-amber-400 text-sm">{{ twin.energyNetwork().totalPowerDemandMW.toFixed(2) }} MW</strong>
            </div>
            <div>
              <span class="text-[10px] text-slate-500 block">FRESHWATER INTAKE</span>
              <strong class="text-sky-400 text-sm">{{ twin.waterNetwork().freshwaterIntakeM3H.toFixed(1) }} m³/h</strong>
            </div>
            <div>
              <span class="text-[10px] text-slate-500 block">WATER RECYCLING</span>
              <strong class="text-sky-300 text-sm">{{ twin.waterNetwork().waterRecycleRatioPct }}%</strong>
            </div>
            <div>
              <span class="text-[10px] text-slate-500 block">CARBON INTENSITY</span>
              <strong class="text-emerald-400 text-sm">{{ twin.energyNetwork().carbonIntensityKgCO2ePerKgProduct.toFixed(2) }} kg/kg</strong>
            </div>
          </div>
        </div>

        <!-- 4. Project Economics -->
        @if (twin.economics(); as econ) {
          <div class="space-y-2">
            <h2 class="text-sm font-bold text-amber-400 uppercase tracking-wide border-b border-slate-800 pb-1">
              4. Project Financial Metrics
            </h2>
            <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-950 p-3 rounded border border-slate-800">
              <div>
                <span class="text-[10px] text-slate-500 block">ESTIMATED CAPEX</span>
                <strong class="text-slate-100 text-sm">£{{ econ.capexGbpMillions }}M</strong>
              </div>
              <div>
                <span class="text-[10px] text-slate-500 block">UNIT OPEX</span>
                <strong class="text-amber-400 text-sm">£{{ econ.opexGbpPerTonProduct }} / t</strong>
              </div>
              <div>
                <span class="text-[10px] text-slate-500 block">PROJECT NPV (8%)</span>
                <strong class="text-emerald-400 text-sm">£{{ econ.npv8PctGbpMillions.toFixed(1) }}M</strong>
              </div>
              <div>
                <span class="text-[10px] text-slate-500 block">PROJECT IRR</span>
                <strong class="text-indigo-300 text-sm">{{ econ.irrPercent.toFixed(1) }}%</strong>
              </div>
            </div>
          </div>
        }

        <!-- Provenance & Disclaimer Notice -->
        <div class="pt-4 border-t border-slate-800 text-[10px] text-slate-500 space-y-1">
          <div>PROVENANCE: ALL PARAMETERS ARE DEMONSTRATION SYNTHETIC ENGINEERING ASSUMPTIONS.</div>
          <div>NOT INTENDED TO REPRESENT ACTUAL COMMERCIAL SPECIFICATIONS OF ANY CORNWALL SITE.</div>
        </div>
      </div>
    </div>
  `
})
export class Report {
  twin = inject(DigitalTwin);

  printReport() {
    if (typeof window !== 'undefined') {
      window.print();
    }
  }

  exportJson() {
    const data = {
      mode: this.twin.extractionMode(),
      product: this.twin.targetProduct(),
      lithiumProductionKgH: this.twin.activeLithiumProductionKgH(),
      productOutputTonnesDay: this.twin.activeProductOutputTonnesDay(),
      massBalance: this.twin.massBalance(),
      energyBalance: this.twin.energyBalance(),
      waterNetwork: this.twin.waterNetwork(),
      economics: this.twin.economics()
    };
    const jsonStr = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cornwall-lithium-twin-export.json`;
    a.click();
    URL.revokeObjectURL(url);
  }
}
