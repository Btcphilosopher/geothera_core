import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwin } from '../../core/services/digital-twin';
import { ProvenanceBadge } from '../../components/provenance-badge/provenance-badge';

@Component({
  selector: 'app-process-plant',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule, ProvenanceBadge],
  template: `
    <div class="p-4 md:p-6 space-y-6 max-w-[1600px] mx-auto text-slate-100 font-sans">
      <!-- Title -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <h1 class="text-xl font-mono font-bold uppercase tracking-wide text-slate-100 flex items-center gap-2">
            <mat-icon class="text-amber-400">valve</mat-icon>
            Lithium Process Plant & DLE Simulator
          </h1>
          <p class="text-xs font-mono text-slate-400 mt-0.5">
            Direct Lithium Extraction (DLE) Cyclic Kinetics · Mineral Comminution & Flotation · Chemical Refining
          </p>
        </div>
        <div class="flex items-center gap-2 font-mono text-xs">
          <app-provenance-badge type="ENGINEERING_ASSUMPTION"></app-provenance-badge>
          <span class="text-slate-400">PLANT MODE: {{ twin.extractionMode() }}</span>
        </div>
      </div>

      <!-- DLE Live Cyclic Stage Simulator (Geothermal Mode) -->
      @if (twin.extractionMode() === 'GEOTHERMAL_BRINE') {
        <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-4 font-mono">
          <div class="flex items-center justify-between pb-2 border-b border-slate-800">
            <h2 class="text-xs font-bold tracking-wider text-slate-300 uppercase flex items-center gap-1.5">
              <mat-icon class="text-amber-400 text-sm">published_with_changes</mat-icon>
              Direct Lithium Extraction (DLE) Cyclic Contactor
            </h2>
            <div class="flex items-center gap-2">
              <span class="text-[10px] text-amber-400 font-bold bg-amber-950/60 px-2 py-0.5 rounded border border-amber-800">
                SORBENT: INORGANIC TITANATE
              </span>
            </div>
          </div>

          <!-- 5-Stage Cyclic Process Animation Ribbon -->
          @if (twin.dleProcess(); as dle) {
            <div class="space-y-4">
              <div class="grid grid-cols-5 gap-2 text-center text-xs">
                <div [class]="cycleClass('LOAD')" class="p-3 rounded border flex flex-col items-center justify-center space-y-1">
                  <span class="text-[10px] text-slate-400">STAGE 1</span>
                  <span class="font-bold">1. LOAD (BRINE)</span>
                  <span class="text-[9px] text-slate-400">Hot Brine Feed</span>
                </div>
                <div [class]="cycleClass('ADSORB')" class="p-3 rounded border flex flex-col items-center justify-center space-y-1">
                  <span class="text-[10px] text-slate-400">STAGE 2</span>
                  <span class="font-bold">2. ADSORB</span>
                  <span class="text-[9px] text-amber-300">Li+ Exchange</span>
                </div>
                <div [class]="cycleClass('RINSE')" class="p-3 rounded border flex flex-col items-center justify-center space-y-1">
                  <span class="text-[10px] text-slate-400">STAGE 3</span>
                  <span class="font-bold">3. RINSE</span>
                  <span class="text-[9px] text-slate-400">Wash Impurities</span>
                </div>
                <div [class]="cycleClass('ELUTE')" class="p-3 rounded border flex flex-col items-center justify-center space-y-1">
                  <span class="text-[10px] text-slate-400">STAGE 4</span>
                  <span class="font-bold">4. ELUTE</span>
                  <span class="text-[9px] text-emerald-300">Acid Desorption</span>
                </div>
                <div [class]="cycleClass('REGENERATE')" class="p-3 rounded border flex flex-col items-center justify-center space-y-1">
                  <span class="text-[10px] text-slate-400">STAGE 5</span>
                  <span class="font-bold">5. REGENERATE</span>
                  <span class="text-[9px] text-slate-400">Reset Sorbent</span>
                </div>
              </div>

              <!-- DLE Live Performance Metrics -->
              <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-2 border-t border-slate-800 text-xs">
                <div class="p-2 bg-slate-950 rounded border border-slate-800">
                  <span class="text-[10px] text-slate-500 block">DLE Li RECOVERY</span>
                  <span class="text-lg font-bold text-emerald-400 tabular-nums">{{ dle.recoveryPct.value }}%</span>
                </div>

                <div class="p-2 bg-slate-950 rounded border border-slate-800">
                  <span class="text-[10px] text-slate-500 block">Li vs Na SELECTIVITY</span>
                  <span class="text-lg font-bold text-amber-400 tabular-nums">{{ dle.selectivityLiVsMultivalents.value }} : 1</span>
                </div>

                <div class="p-2 bg-slate-950 rounded border border-slate-800">
                  <span class="text-[10px] text-slate-500 block">ELUATE Li CONCENTRATION</span>
                  <span class="text-lg font-bold text-slate-100 tabular-nums">{{ dle.eluateLithiumMgL }} mg/L</span>
                </div>

                <div class="p-2 bg-slate-950 rounded border border-slate-800">
                  <span class="text-[10px] text-slate-500 block">SPECIFIC ENERGY</span>
                  <span class="text-lg font-bold text-sky-400 tabular-nums">{{ dle.energyConsumptionkWhPerKgLi }} kWh/kg Li</span>
                </div>
              </div>
            </div>
          }
        </div>
      } @else {
        <!-- HARD ROCK COMMINUTION & SEPARATION SECTION -->
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 font-mono">
          <!-- Crusher & Grinding Mill Digital Twin -->
          <div class="lg:col-span-6 bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-4">
            <div class="flex items-center justify-between pb-2 border-b border-slate-800">
              <h2 class="text-xs font-bold tracking-wider text-slate-300 uppercase flex items-center gap-1.5">
                <mat-icon class="text-amber-400 text-sm">settings</mat-icon>
                Crushing & Ball Mill Comminution
              </h2>
              <span class="text-[10px] text-amber-400 font-bold">P80 TARGET: 150 µm</span>
            </div>

            <div class="space-y-3 text-xs">
              <div class="p-3 bg-slate-950 border border-slate-800 rounded space-y-2">
                <div class="flex justify-between font-bold text-slate-200">
                  <span>Primary Jaw Crusher</span>
                  <span class="text-amber-400">{{ twin.crusher().throughputTonnesHour.toFixed(1) }} t/h</span>
                </div>
                <div class="grid grid-cols-2 gap-2 text-[11px] text-slate-400">
                  <div>Feed Size: <strong class="text-slate-200">{{ twin.crusher().feedSizeMm }} mm</strong></div>
                  <div>Product P80: <strong class="text-slate-200">{{ twin.crusher().productSizeP80Mm }} mm</strong></div>
                  <div>Power: <strong class="text-amber-400">{{ twin.crusher().installedPowerkW }} kW</strong></div>
                  <div>Specific Energy: <strong class="text-slate-200">{{ twin.crusher().specificEnergykWhPerTon }} kWh/t</strong></div>
                </div>
              </div>

              <div class="p-3 bg-slate-950 border border-slate-800 rounded space-y-2">
                <div class="flex justify-between font-bold text-slate-200">
                  <span>Ball Grinding Mill & Hydrocyclone</span>
                  <span class="text-amber-400">{{ twin.mill().throughputTonnesHour.toFixed(1) }} t/h</span>
                </div>
                <div class="grid grid-cols-2 gap-2 text-[11px] text-slate-400">
                  <div>Target Grind P80: <strong class="text-slate-200">{{ twin.mill().targetGrindP80Microns }} µm</strong></div>
                  <div>Recirculation Ratio: <strong class="text-slate-200">{{ twin.mill().recirculationRatioPct }}%</strong></div>
                  <div>Power: <strong class="text-amber-400">{{ twin.mill().installedPowerkW }} kW</strong></div>
                  <div>Specific Energy: <strong class="text-slate-200">{{ twin.mill().specificEnergykWhPerTon }} kWh/t</strong></div>
                </div>
              </div>
            </div>
          </div>

          <!-- Spodumene Mineral Separation Flotation -->
          <div class="lg:col-span-6 bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-4">
            <div class="flex items-center justify-between pb-2 border-b border-slate-800">
              <h2 class="text-xs font-bold tracking-wider text-slate-300 uppercase flex items-center gap-1.5">
                <mat-icon class="text-amber-400 text-sm">filter_alt</mat-icon>
                Flotation & Mineral Separation Circuit
              </h2>
              <span class="text-[10px] text-emerald-400 font-bold">SPODUMENE CONCENTRATE</span>
            </div>

            @if (twin.mineralSeparation(); as sep) {
              <div class="space-y-3 text-xs">
                <div class="flex justify-between p-2 bg-slate-950 rounded border border-slate-800">
                  <span class="text-slate-400">Concentrate Grade Target</span>
                  <span class="font-bold text-amber-400 tabular-nums">{{ sep.concentrateGradeLi2OPct }}% Li2O</span>
                </div>

                <div class="flex justify-between p-2 bg-slate-950 rounded border border-slate-800">
                  <span class="text-slate-400">Flotation Recovery</span>
                  <span class="font-bold text-emerald-400 tabular-nums">{{ sep.recoveryPct }}%</span>
                </div>

                <div class="flex justify-between p-2 bg-slate-950 rounded border border-slate-800">
                  <span class="text-slate-400">Water Demand</span>
                  <span class="font-bold text-sky-400 tabular-nums">{{ sep.waterDemandM3PerTon }} m³/t ore</span>
                </div>

                <div class="flex justify-between p-2 bg-slate-950 rounded border border-slate-800">
                  <span class="text-slate-400">Flotation Power Demand</span>
                  <span class="font-bold text-slate-200 tabular-nums">{{ sep.energyDemandkWhPerTon }} kWh/t ore</span>
                </div>
              </div>
            }
          </div>
        </div>
      }

      <!-- Chemical Refining & Conversion Plant Section -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-4 font-mono">
        <div class="flex items-center justify-between pb-2 border-b border-slate-800">
          <h2 class="text-xs font-bold tracking-wider text-slate-300 uppercase flex items-center gap-1.5">
            <mat-icon class="text-amber-400 text-sm">science</mat-icon>
            Chemical Conversion & Refining Plant (Carbonate / Hydroxide)
          </h2>
          <span class="text-[10px] text-emerald-400 font-bold">
            PRODUCT: {{ twin.targetProduct().replace('_', ' ') }}
          </span>
        </div>

        @if (twin.chemicalPlant(); as chem) {
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
            <div class="p-3 bg-slate-950 rounded border border-slate-800 space-y-1">
              <span class="text-[10px] text-slate-500 uppercase block">CONVERSION YIELD</span>
              <span class="text-xl font-bold text-emerald-400 tabular-nums">{{ chem.conversionYieldPct }}%</span>
              <span class="text-[10px] text-slate-400 block">Reactor Efficiency</span>
            </div>

            <div class="p-3 bg-slate-950 rounded border border-slate-800 space-y-1">
              <span class="text-[10px] text-slate-500 uppercase block">PRODUCT PURITY</span>
              <span class="text-xl font-bold text-slate-100 tabular-nums">{{ chem.targetPurityPct }}%</span>
              <span class="text-[10px] text-amber-400 block">Battery-Grade Spec</span>
            </div>

            <div class="p-3 bg-slate-950 rounded border border-slate-800 space-y-1">
              <span class="text-[10px] text-slate-500 uppercase block">REAGENT SODA ASH</span>
              <span class="text-xl font-bold text-slate-200 tabular-nums">{{ chem.reagentSodiumCarbonateKgPerKgLi }} kg/kg Li</span>
              <span class="text-[10px] text-slate-400 block">Na2CO3 Requirement</span>
            </div>

            <div class="p-3 bg-slate-950 rounded border border-slate-800 space-y-1">
              <span class="text-[10px] text-slate-500 uppercase block">THERMAL ENERGY</span>
              <span class="text-xl font-bold text-amber-400 tabular-nums">{{ chem.thermalEnergykWhPerKgProduct }} kWh/kg</span>
              <span class="text-[10px] text-slate-400 block">Crystallizer Steam</span>
            </div>
          </div>

          <!-- Product Impurity Tolerance Table -->
          <div class="pt-2 border-t border-slate-800 space-y-2">
            <span class="text-[10px] text-slate-400 uppercase tracking-wider block font-bold">Product Impurity Limits (Max Thresholds)</span>
            <div class="grid grid-cols-4 gap-2 text-[11px]">
              <div class="p-2 bg-slate-950 rounded border border-slate-800 flex justify-between">
                <span class="text-slate-400">Sodium (Na)</span>
                <span class="font-bold text-slate-200">{{ chem.maxImpurityNaPpm }} ppm</span>
              </div>
              <div class="p-2 bg-slate-950 rounded border border-slate-800 flex justify-between">
                <span class="text-slate-400">Potassium (K)</span>
                <span class="font-bold text-slate-200">{{ chem.maxImpurityKPpm }} ppm</span>
              </div>
              <div class="p-2 bg-slate-950 rounded border border-slate-800 flex justify-between">
                <span class="text-slate-400">Calcium (Ca)</span>
                <span class="font-bold text-slate-200">{{ chem.maxImpurityCaPpm }} ppm</span>
              </div>
              <div class="p-2 bg-slate-950 rounded border border-slate-800 flex justify-between">
                <span class="text-slate-400">Iron (Fe)</span>
                <span class="font-bold text-slate-200">{{ chem.maxImpurityFePpm }} ppm</span>
              </div>
            </div>
          </div>
        }
      </div>
    </div>
  `
})
export class ProcessPlant {
  twin = inject(DigitalTwin);

  cycleClass(stage: string) {
    if (stage === 'ADSORB' || stage === 'ELUTE') {
      return 'bg-amber-950/80 border-amber-500 text-amber-300 font-bold';
    }
    return 'bg-slate-950 border-slate-800 text-slate-300';
  }
}
