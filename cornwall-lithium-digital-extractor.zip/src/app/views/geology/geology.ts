import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwin } from '../../core/services/digital-twin';
import { ProvenanceBadge } from '../../components/provenance-badge/provenance-badge';
import { VoxelBlock } from '../../core/models/geology';

@Component({
  selector: 'app-geology',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule, ProvenanceBadge],
  template: `
    <div class="p-4 md:p-6 space-y-6 max-w-[1600px] mx-auto text-slate-100 font-sans">
      <!-- Section Title & Provenance -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <h1 class="text-xl font-mono font-bold uppercase tracking-wide text-slate-100 flex items-center gap-2">
            <mat-icon class="text-amber-400">terrain</mat-icon>
            Geological Digital Twin & Resource Model
          </h1>
          <p class="text-xs font-mono text-slate-400 mt-0.5">
            Carnmenellis Granite Massif Subsurface Block Model · Core Drilling Simulator · Reserve Estimation
          </p>
        </div>
        <div class="flex items-center gap-2">
          <app-provenance-badge type="SYNTHETIC"></app-provenance-badge>
          <span class="text-xs font-mono text-slate-400">DEMONSTRATION RESOURCE MODEL</span>
        </div>
      </div>

      <!-- Resource Reserve Estimation Summary Cards -->
      @if (twin.resourceEstimate(); as res) {
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 font-mono">
          <div class="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
            <span class="text-[10px] text-slate-500 uppercase tracking-wider">MEASURED RESOURCE</span>
            <div class="text-xl font-bold text-slate-100 tabular-nums">{{ res.measured.tonnageMt }} Mt</div>
            <div class="text-xs text-amber-400">@ {{ res.measured.averageGradePpm }} ppm Li</div>
            <div class="text-[10px] text-slate-400">Contained: {{ res.measured.containedLithiumTonnes }} t Li</div>
          </div>

          <div class="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
            <span class="text-[10px] text-slate-500 uppercase tracking-wider">INDICATED RESOURCE</span>
            <div class="text-xl font-bold text-slate-100 tabular-nums">{{ res.indicated.tonnageMt }} Mt</div>
            <div class="text-xs text-amber-400">@ {{ res.indicated.averageGradePpm }} ppm Li</div>
            <div class="text-[10px] text-slate-400">Contained: {{ res.indicated.containedLithiumTonnes }} t Li</div>
          </div>

          <div class="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
            <span class="text-[10px] text-slate-500 uppercase tracking-wider">INFERRED RESOURCE</span>
            <div class="text-xl font-bold text-slate-100 tabular-nums">{{ res.inferred.tonnageMt }} Mt</div>
            <div class="text-xs text-amber-400">@ {{ res.inferred.averageGradePpm }} ppm Li</div>
            <div class="text-[10px] text-slate-400">Contained: {{ res.inferred.containedLithiumTonnes }} t Li</div>
          </div>

          <div class="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
            <span class="text-[10px] text-slate-500 uppercase tracking-wider">TOTAL CONTAINED Li2O</span>
            <div class="text-xl font-bold text-emerald-400 tabular-nums">{{ (res.total.containedLi2OTonnes / 1000).toFixed(1) }} kt</div>
            <div class="text-xs text-slate-400">Cutoff: {{ res.cutoffGradePpm }} ppm Li</div>
            <div class="text-[10px] text-emerald-300">Recoverable: {{ (res.total.recoverableLithiumTonnes / 1000).toFixed(1) }} kt Li</div>
          </div>

          <div class="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
            <span class="text-[10px] text-slate-500 uppercase tracking-wider">GEOLOGICAL RISK (P10/P50/P90)</span>
            <div class="text-xs text-slate-300 space-y-0.5 pt-1">
              <div class="flex justify-between"><span>P10 (High):</span><span class="font-bold text-emerald-400">{{ res.confidenceDistribution.p10Tonnes }} t</span></div>
              <div class="flex justify-between"><span>P50 (Base):</span><span class="font-bold text-amber-400">{{ res.confidenceDistribution.p50Tonnes }} t</span></div>
              <div class="flex justify-between"><span>P90 (Low):</span><span class="font-bold text-slate-400">{{ res.confidenceDistribution.p90Tonnes }} t</span></div>
            </div>
          </div>
        </div>
      }

      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 font-mono">
        <!-- Left: Subsurface Voxel Inspector & Table -->
        <div class="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-4">
          <div class="flex items-center justify-between pb-2 border-b border-slate-800">
            <h2 class="text-xs font-bold tracking-wider text-slate-300 uppercase flex items-center gap-1.5">
              <mat-icon class="text-amber-400 text-sm">grid_view</mat-icon>
              3D Voxel Subsurface Grid Browser
            </h2>
            <span class="text-[10px] text-slate-400">Total Voxels: {{ twin.voxels().length }}</span>
          </div>

          <!-- Voxel Table -->
          <div class="overflow-x-auto max-h-[360px] overflow-y-auto border border-slate-800 rounded">
            <table class="w-full text-left text-xs text-slate-300">
              <thead class="bg-slate-950 text-slate-400 text-[10px] uppercase sticky top-0 border-b border-slate-800">
                <tr>
                  <th class="p-2">Voxel (X,Y,Z)</th>
                  <th class="p-2">Rock Lithology</th>
                  <th class="p-2">Grade (ppm)</th>
                  <th class="p-2">Density</th>
                  <th class="p-2">Temp (°C)</th>
                  <th class="p-2">Confidence</th>
                  <th class="p-2 text-right">Action</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-800/60">
                @for (v of twin.voxels(); track $index) {
                  <tr 
                    [class.bg-amber-950/20]="selectedVoxel() === v"
                    class="hover:bg-slate-800/50 transition-colors cursor-pointer"
                    (click)="selectedVoxel.set(v)">
                    <td class="p-2 font-bold text-slate-200">({{ v.x }}, {{ v.y }}, {{ v.z }})</td>
                    <td class="p-2">
                      <span class="px-1.5 py-0.5 rounded text-[10px] uppercase font-bold"
                            [class]="rockClass(v.rock_type)">
                        {{ v.rock_type.replace('_', ' ') }}
                      </span>
                    </td>
                    <td class="p-2 font-bold text-amber-400 tabular-nums">{{ v.lithium_grade_ppm }} ppm</td>
                    <td class="p-2 tabular-nums">{{ v.density_kg_m3 }} kg/m³</td>
                    <td class="p-2 tabular-nums text-red-300">{{ v.temperature_C }}°C</td>
                    <td class="p-2 tabular-nums text-slate-400">{{ (v.confidence * 100).toFixed(0) }}%</td>
                    <td class="p-2 text-right">
                      <button class="text-amber-400 hover:text-amber-300 text-[10px] font-bold">Inspect</button>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>

          <!-- Selected Voxel Inspector Panel -->
          @if (selectedVoxel(); as v) {
            <div class="bg-slate-950 border border-slate-800 p-3 rounded-lg space-y-2 text-xs">
              <div class="flex justify-between items-center text-amber-300 font-bold">
                <span>Selected Voxel Block (X: {{ v.x }}, Y: {{ v.y }}, Z: {{ v.z }})</span>
                <span class="text-[10px] text-slate-400">Depth Zone: {{ v.z * 500 }}m OD</span>
              </div>
              <div class="grid grid-cols-3 gap-2 text-slate-300 text-[11px]">
                <div>Porosity: <span class="text-amber-400 font-bold">{{ (v.porosity * 100).toFixed(2) }}%</span></div>
                <div>Permeability: <span class="text-amber-400 font-bold">{{ v.permeability_mD }} mD</span></div>
                <div>Moisture: <span class="text-amber-400 font-bold">{{ v.moisture_pct }}%</span></div>
              </div>
            </div>
          }
        </div>

        <!-- Right: Exploration Drilling Simulator & Drilling Designer -->
        <div class="lg:col-span-5 space-y-4">
          <!-- Exploration Core Drilling Simulator -->
          <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
            <div class="flex items-center justify-between pb-2 border-b border-slate-800">
              <h2 class="text-xs font-bold tracking-wider text-slate-300 uppercase flex items-center gap-1.5">
                <mat-icon class="text-amber-400 text-sm">design_services</mat-icon>
                Virtual Core Hole Log
              </h2>
              <span class="text-[10px] text-emerald-400 font-bold">CNL-014 LOG</span>
            </div>

            <div class="space-y-2 text-xs">
              @for (hole of twin.drillholes(); track hole.holeId) {
                <div class="bg-slate-950 border border-slate-800 rounded p-3 space-y-2">
                  <div class="flex justify-between font-bold text-amber-300">
                    <span>DRILLHOLE {{ hole.holeId }}</span>
                    <span>Depth: {{ hole.totalDepthM }}m (Dip: {{ hole.dipDeg }}°)</span>
                  </div>

                  <div class="space-y-1">
                    @for (interval of hole.intervals; track interval.fromDepthM) {
                      <div class="flex items-center justify-between text-[11px] p-1.5 bg-slate-900 rounded border border-slate-800">
                        <span class="text-slate-400 w-24">{{ interval.fromDepthM }}m - {{ interval.toDepthM }}m</span>
                        <span class="font-bold text-slate-200 capitalize">{{ interval.rockType.replace('_', ' ') }}</span>
                        <span class="text-amber-400 font-bold tabular-nums">{{ interval.gradePpm }} ppm</span>
                      </div>
                    }
                  </div>
                </div>
              }
            </div>
          </div>

          <!-- Exploration Drilling Program Designer -->
          <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3 text-xs">
            <div class="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 class="font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <mat-icon class="text-amber-400 text-sm">hardware</mat-icon>
                Drilling Program Designer
              </h3>
              <span class="text-[10px] text-slate-500">PROGRAM COST MODEL</span>
            </div>

            <div class="space-y-3">
              <div class="flex justify-between items-center">
                <span class="text-slate-400">Hole Grid Spacing</span>
                <span class="font-bold text-amber-400">100 m</span>
              </div>
              <div class="flex justify-between items-center">
                <span class="text-slate-400">Planned Drilling Metres</span>
                <span class="font-bold text-slate-200">12,500 m</span>
              </div>
              <div class="flex justify-between items-center">
                <span class="text-slate-400">Estimated Drilling Cost</span>
                <span class="font-bold text-emerald-400">£2.25M (£180/m)</span>
              </div>
              <div class="flex justify-between items-center">
                <span class="text-slate-400">Reserve Confidence Boost</span>
                <span class="font-bold text-sky-400">Inferred → Indicated (+35%)</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class Geology {
  twin = inject(DigitalTwin);
  selectedVoxel = signal<VoxelBlock | null>(this.twin.voxels()[0] || null);

  rockClass(rock: string) {
    switch (rock) {
      case 'pegmatite': return 'bg-amber-950 text-amber-300 border border-amber-800';
      case 'fault_zone': return 'bg-red-950 text-red-300 border border-red-800';
      case 'geothermal_reservoir': return 'bg-sky-950 text-sky-300 border border-sky-800';
      default: return 'bg-slate-800 text-slate-300 border border-slate-700';
    }
  }
}
