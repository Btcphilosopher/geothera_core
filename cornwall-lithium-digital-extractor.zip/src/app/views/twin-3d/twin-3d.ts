import { 
  Component, ChangeDetectionStrategy, ElementRef, ViewChild, 
  AfterViewInit, OnDestroy, inject, signal 
} from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import * as THREE from 'three';
import { DigitalTwin } from '../../core/services/digital-twin';
import { ProvenanceBadge } from '../../components/provenance-badge/provenance-badge';

@Component({
  selector: 'app-twin-3d',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule, ProvenanceBadge],
  template: `
    <div class="p-4 md:p-6 space-y-6 max-w-[1600px] mx-auto text-slate-100 font-sans">
      <!-- Header -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <h1 class="text-xl font-mono font-bold uppercase tracking-wide text-slate-100 flex items-center gap-2">
            <mat-icon class="text-amber-400">view_in_ar</mat-icon>
            3D Cornish Subsurface & Surface Plant Digital Twin
          </h1>
          <p class="text-xs font-mono text-slate-400 mt-0.5">
            Real-Time Three.js Spatial Rendering · Granite Body Cutaway · Underground Drives & Geothermal Wellbores
          </p>
        </div>
        <div class="flex items-center gap-2 font-mono text-xs">
          <app-provenance-badge type="SYNTHETIC"></app-provenance-badge>
          <span class="text-slate-400">3D ENGINE: THREE.JS</span>
        </div>
      </div>

      <!-- Main 3D Canvas Stage & Controls -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 font-mono">
        <div class="lg:col-span-9 bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-4">
          <div class="flex items-center justify-between pb-2 border-b border-slate-800">
            <div class="flex items-center gap-3">
              <h2 class="text-xs font-bold tracking-wider text-slate-300 uppercase flex items-center gap-1.5">
                <mat-icon class="text-amber-400 text-sm">3d_rotation</mat-icon>
                Subsurface Spatial Canvas
              </h2>
            </div>
            
            <div class="flex items-center gap-2 text-xs">
              <button 
                (click)="toggleCutaway()"
                [class]="showCutaway() ? 'bg-amber-500 text-slate-950 font-bold' : 'bg-slate-800 text-slate-300'"
                class="px-2.5 py-1 rounded transition-colors">
                Cutaway View
              </button>
              <button 
                (click)="toggleWells()"
                [class]="showWells() ? 'bg-sky-500 text-slate-950 font-bold' : 'bg-slate-800 text-slate-300'"
                class="px-2.5 py-1 rounded transition-colors">
                Toggle Wells
              </button>
            </div>
          </div>

          <!-- Three.js Canvas Container -->
          <div #canvasContainer class="relative h-[520px] bg-slate-950 border border-slate-800 rounded-lg overflow-hidden cursor-grab active:cursor-grabbing">
            <canvas #threeCanvas class="w-full h-full block"></canvas>

            <!-- Floating 3D HUD Overlay -->
            <div class="absolute top-3 left-3 bg-slate-900/90 border border-slate-800 p-2.5 rounded text-[11px] space-y-1 backdrop-blur select-none">
              <div class="font-bold text-amber-300">CORNWALL 3D MODEL HUD</div>
              <div class="text-slate-300">Surface Terrain: <span class="text-emerald-400">+120m OD</span></div>
              <div class="text-slate-300">Granite Depth: <span class="text-slate-100">0m to -2,500m</span></div>
              <div class="text-slate-300">Geothermal Reservoir: <span class="text-red-400">-4,000m (180°C)</span></div>
            </div>

            <div class="absolute bottom-3 right-3 bg-slate-900/90 border border-slate-800 px-3 py-1.5 rounded text-[10px] text-slate-400 backdrop-blur">
              Click and drag to rotate · Scroll to zoom
            </div>
          </div>
        </div>

        <!-- 3D Scene Controls & Object Inspector -->
        <div class="lg:col-span-3 bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-4 text-xs">
          <div class="flex items-center justify-between pb-2 border-b border-slate-800">
            <h3 class="font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <mat-icon class="text-amber-400 text-sm">layers</mat-icon>
              3D Layer Selector
            </h3>
          </div>

          <div class="space-y-2">
            <label class="flex items-center gap-2 p-2 bg-slate-950 rounded border border-slate-800 cursor-pointer">
              <input type="checkbox" [checked]="true" (change)="toggleTerrain()" class="accent-amber-500">
              <span>Cornish Surface Topography</span>
            </label>

            <label class="flex items-center gap-2 p-2 bg-slate-950 rounded border border-slate-800 cursor-pointer">
              <input type="checkbox" [checked]="true" (change)="toggleGranite()" class="accent-amber-500">
              <span>Carnmenellis Granite Massif</span>
            </label>

            <label class="flex items-center gap-2 p-2 bg-slate-950 rounded border border-slate-800 cursor-pointer">
              <input type="checkbox" [checked]="true" (change)="toggleFault()" class="accent-amber-500">
              <span>Hydrothermal Fault Network</span>
            </label>

            <label class="flex items-center gap-2 p-2 bg-slate-950 rounded border border-slate-800 cursor-pointer">
              <input type="checkbox" [checked]="true" (change)="togglePlantBuildings()" class="accent-amber-500">
              <span>Surface DLE Process Buildings</span>
            </label>
          </div>

          <div class="p-3 bg-slate-950 border border-slate-800 rounded space-y-2 pt-3">
            <div class="font-bold text-amber-300">Active Architecture</div>
            <p class="text-slate-400">
              Currently simulating <strong class="text-slate-200">{{ twin.extractionMode() }}</strong>.
              Subsurface wells and process piping reflect live parameter updates.
            </p>
          </div>
        </div>
      </div>
    </div>
  `
})
export class Twin3D implements AfterViewInit, OnDestroy {
  @ViewChild('threeCanvas') canvasRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('canvasContainer') containerRef!: ElementRef<HTMLDivElement>;

  twin = inject(DigitalTwin);

  readonly showCutaway = signal<boolean>(true);
  readonly showWells = signal<boolean>(true);

  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private animFrameId = 0;

  // Scene meshes
  private terrainMesh!: THREE.Mesh;
  private graniteMesh!: THREE.Mesh;
  private faultMesh!: THREE.Mesh;
  private wellLine!: THREE.Line;
  private plantGroup!: THREE.Group;

  ngAfterViewInit() {
    this.initThreeScene();
  }

  ngOnDestroy() {
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  toggleCutaway() {
    this.showCutaway.update(v => !v);
    if (this.graniteMesh) {
      (this.graniteMesh.material as THREE.MeshStandardMaterial).wireframe = !this.showCutaway();
    }
  }

  toggleWells() {
    this.showWells.update(v => !v);
    if (this.wellLine) {
      this.wellLine.visible = this.showWells();
    }
  }

  toggleTerrain() {
    if (this.terrainMesh) this.terrainMesh.visible = !this.terrainMesh.visible;
  }

  toggleGranite() {
    if (this.graniteMesh) this.graniteMesh.visible = !this.graniteMesh.visible;
  }

  toggleFault() {
    if (this.faultMesh) this.faultMesh.visible = !this.faultMesh.visible;
  }

  togglePlantBuildings() {
    if (this.plantGroup) this.plantGroup.visible = !this.plantGroup.visible;
  }

  private initThreeScene() {
    const container = this.containerRef.nativeElement;
    const width = container.clientWidth;
    const height = container.clientHeight;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x020617); // Slate-950

    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    this.camera.position.set(60, 45, 80);
    this.camera.lookAt(0, -10, 0);

    this.renderer = new THREE.WebGLRenderer({ canvas: this.canvasRef.nativeElement, antialias: true });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    this.scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xf59e0b, 1.2);
    dirLight.position.set(50, 80, 50);
    this.scene.add(dirLight);

    // 1. Surface Terrain Mesh
    const terrainGeo = new THREE.PlaneGeometry(100, 100, 32, 32);
    terrainGeo.rotateX(-Math.PI / 2);
    const pos = terrainGeo.attributes['position'];
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const z = pos.getZ(i);
      pos.setY(i, Math.sin(x * 0.08) * Math.cos(z * 0.08) * 3 + 10);
    }
    terrainGeo.computeVertexNormals();

    const terrainMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      wireframe: true,
      roughness: 0.8
    });
    this.terrainMesh = new THREE.Mesh(terrainGeo, terrainMat);
    this.scene.add(this.terrainMesh);

    // 2. Granite Massif Block
    const graniteGeo = new THREE.BoxGeometry(70, 30, 70);
    const graniteMat = new THREE.MeshStandardMaterial({
      color: 0x334155,
      transparent: true,
      opacity: 0.5,
      roughness: 0.6
    });
    this.graniteMesh = new THREE.Mesh(graniteGeo, graniteMat);
    this.graniteMesh.position.set(0, -15, 0);
    this.scene.add(this.graniteMesh);

    // 3. Fault Zone (Reddish planar feature)
    const faultGeo = new THREE.BoxGeometry(4, 40, 60);
    const faultMat = new THREE.MeshStandardMaterial({
      color: 0xef4444,
      transparent: true,
      opacity: 0.6
    });
    this.faultMesh = new THREE.Mesh(faultGeo, faultMat);
    this.faultMesh.rotation.z = 0.3;
    this.faultMesh.position.set(5, -20, 0);
    this.scene.add(this.faultMesh);

    // 4. Geothermal Well Line (CNL-GT-01)
    const points = [
      new THREE.Vector3(0, 10, 0),
      new THREE.Vector3(2, -10, 0),
      new THREE.Vector3(5, -35, 0)
    ];
    const wellGeo = new THREE.BufferGeometry().setFromPoints(points);
    const wellMat = new THREE.LineBasicMaterial({ color: 0x38bdf8, linewidth: 3 });
    this.wellLine = new THREE.Line(wellGeo, wellMat);
    this.scene.add(this.wellLine);

    // 5. Surface Plant Group
    this.plantGroup = new THREE.Group();
    const bldg1 = new THREE.Mesh(
      new THREE.BoxGeometry(12, 6, 8),
      new THREE.MeshStandardMaterial({ color: 0x10b981 })
    );
    bldg1.position.set(-15, 13, -10);
    this.plantGroup.add(bldg1);

    const tank1 = new THREE.Mesh(
      new THREE.CylinderGeometry(4, 4, 8, 16),
      new THREE.MeshStandardMaterial({ color: 0xf59e0b })
    );
    tank1.position.set(-25, 14, -10);
    this.plantGroup.add(tank1);

    this.scene.add(this.plantGroup);

    // Animation Loop
    const animate = () => {
      this.animFrameId = requestAnimationFrame(animate);
      this.scene.rotation.y += 0.002; // Slow rotating orbit
      this.renderer.render(this.scene, this.camera);
    };
    animate();
  }
}
