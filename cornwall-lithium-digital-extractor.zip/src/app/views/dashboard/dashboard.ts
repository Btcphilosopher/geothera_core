import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwin } from '../../core/services/digital-twin';
import { AiTwinAdvisor } from '../../core/services/ai-twin-advisor';
import { ProvenanceBadge } from '../../components/provenance-badge/provenance-badge';

@Component({
  selector: 'app-dashboard',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, MatIconModule, ProvenanceBadge],
  template: `
    <div class="p-4 md:p-6 space-y-6 max-w-[1600px] mx-auto text-slate-100 font-sans">
      <!-- Demonstration Notice Banner -->
      <div class="flex items-center justify-between p-3 bg-amber-950/40 border border-amber-500/30 rounded-lg text-amber-300 text-xs font-mono">
        <div class="flex items-center gap-2">
          <mat-icon class="text-amber-400 text-sm">warning</mat-icon>
          <span class="font-bold">DEMONSTRATION MODEL - NOT SITE DATA</span>
          <span class="text-amber-400/80 hidden md:inline">· Cornwall Lithium Digital Extractor Digital Twin Platform</span>
        </div>
        <div class="flex items-center gap-2">
          <app-provenance-badge type="SYNTHETIC"></app-provenance-badge>
          <span class="text-[11px] text-amber-400/80">PROVENANCE: SYNTHETIC ENGINEERING ASSUMPTIONS</span>
        </div>
      </div>

      <!-- Main Workstation Layout -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        <!-- Left Sidebar Column: Flow Chain Navigation & Active Controllers -->
        <div class="lg:col-span-4 space-y-4">
          <!-- Flow Chain Summary Card -->
          <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
            <div class="flex items-center justify-between pb-2 border-b border-slate-800">
              <h2 class="text-xs font-mono font-bold tracking-wider text-slate-400 uppercase flex items-center gap-1.5">
                <mat-icon class="text-amber-400 text-sm">account_tree</mat-icon>
                Physical Process Chain
              </h2>
              <span class="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800">
                {{ twin.extractionMode() === 'HARD_ROCK' ? 'MODE A: HARD-ROCK' : 'MODE B: GEOTHERMAL' }}
              </span>
            </div>

            <!-- Flow Chain Nodes -->
            <div class="space-y-2 text-xs font-mono">
              <div class="p-2 bg-slate-950/80 border border-slate-800 rounded flex items-center justify-between">
                <div class="flex items-center gap-2">
                  <span class="w-2 h-2 rounded-full bg-amber-400"></span>
                  <span class="font-semibold text-slate-200">1. GEOLOGY</span>
                </div>
                <span class="text-slate-400">Carnmenellis Granite / Faults</span>
              </div>

              <div class="p-2 bg-slate-950/80 border border-slate-800 rounded flex items-center justify-between">
                <div class="flex items-center gap-2">
                  <span class="w-2 h-2 rounded-full bg-sky-400"></span>
                  <span class="font-semibold text-slate-200">2. RESOURCE</span>
                </div>
                <span class="text-slate-400">84.7 Mt @ 808 ppm Li</span>
              </div>

              <div class="p-2 bg-slate-950/80 border border-slate-800 rounded flex items-center justify-between">
                <div class="flex items-center gap-2">
                  <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
                  <span class="font-semibold text-slate-200">3. EXTRACTION</span>
                </div>
                <span class="text-slate-300 font-bold tabular-nums">
                  {{ twin.extractionMode() === 'HARD_ROCK' ? twin.hardRockMine().targetOreThroughputTonnesDay + ' t/d' : twin.geothermalReservoir().designFlowRateLs.value + ' L/s' }}
                </span>
              </div>

              <div class="p-2 bg-slate-950/80 border border-slate-800 rounded flex items-center justify-between">
                <div class="flex items-center gap-2">
                  <span class="w-2 h-2 rounded-full bg-indigo-400"></span>
                  <span class="font-semibold text-slate-200">4. SEPARATION / DLE</span>
                </div>
                <span class="text-slate-300 font-bold tabular-nums">
                  {{ twin.extractionMode() === 'HARD_ROCK' ? twin.mineralSeparation().recoveryPct + '% Rec' : twin.dleProcess().recoveryPct.value + '% Rec' }}
                </span>
              </div>

              <div class="p-2 bg-slate-950/80 border border-slate-800 rounded flex items-center justify-between">
                <div class="flex items-center gap-2">
                  <span class="w-2 h-2 rounded-full bg-violet-400"></span>
                  <span class="font-semibold text-slate-200">5. CHEMICAL PLANT</span>
                </div>
                <span class="text-amber-400 font-bold">
                  {{ twin.targetProduct() === 'LITHIUM_CARBONATE' ? 'Li2CO3 (99.5%)' : 'LiOH·H2O' }}
                </span>
              </div>

              <div class="p-2 bg-slate-950/80 border border-slate-800 rounded flex items-center justify-between">
                <div class="flex items-center gap-2">
                  <span class="w-2 h-2 rounded-full bg-emerald-300"></span>
                  <span class="font-semibold text-slate-200">6. PRODUCT DISPATCH</span>
                </div>
                <span class="text-emerald-400 font-bold tabular-nums">
                  {{ twin.activeProductOutputTonnesDay().toFixed(2) }} t/day
                </span>
              </div>
            </div>
          </div>

          <!-- Direct Interactive Simulator Parameter Adjusters -->
          <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-4">
            <div class="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 class="text-xs font-mono font-bold tracking-wider text-slate-400 uppercase flex items-center gap-1.5">
                <mat-icon class="text-amber-400 text-sm">tune</mat-icon>
                Twin Input Parameters
              </h3>
              <span class="text-[10px] text-slate-500 font-mono">LIVE RECALCULATION</span>
            </div>

            <!-- Parameter 1: Geothermal Flow or Hard-Rock Tonnes -->
            @if (twin.extractionMode() === 'GEOTHERMAL_BRINE') {
              <div class="space-y-1.5 font-mono">
                <div class="flex justify-between text-xs">
                  <span class="text-slate-300">Geothermal Well Flow Rate</span>
                  <span class="text-amber-400 font-bold tabular-nums">
                    {{ twin.geothermalReservoir().designFlowRateLs.value }} L/s
                  </span>
                </div>
                <input 
                  type="range" 
                  min="30" 
                  max="250" 
                  step="5" 
                  [value]="twin.geothermalReservoir().designFlowRateLs.value"
                  (input)="onFlowChange($event)"
                  class="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500" />
                <div class="flex justify-between text-[10px] text-slate-500">
                  <span>30 L/s</span>
                  <span>100 L/s</span>
                  <span>250 L/s</span>
                </div>
              </div>
            } @else {
              <div class="space-y-1.5 font-mono">
                <div class="flex justify-between text-xs">
                  <span class="text-slate-300">Ore Mining Throughput</span>
                  <span class="text-amber-400 font-bold tabular-nums">
                    {{ twin.hardRockMine().targetOreThroughputTonnesDay }} t/day
                  </span>
                </div>
                <input 
                  type="range" 
                  min="500" 
                  max="6000" 
                  step="250" 
                  [value]="twin.hardRockMine().targetOreThroughputTonnesDay"
                  (input)="onOreChange($event)"
                  class="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500" />
                <div class="flex justify-between text-[10px] text-slate-500">
                  <span>500 t/d</span>
                  <span>2,500 t/d</span>
                  <span>6,000 t/d</span>
                </div>
              </div>
            }

            <!-- Parameter 2: DLE / Separation Recovery Override -->
            <div class="space-y-1.5 font-mono">
              <div class="flex justify-between text-xs">
                <span class="text-slate-300">DLE / Separation Recovery</span>
                <span class="text-amber-400 font-bold tabular-nums">
                  {{ twin.dleProcess().recoveryPct.value }}%
                </span>
              </div>
              <input 
                type="range" 
                min="60" 
                max="98" 
                step="0.5" 
                [value]="twin.dleProcess().recoveryPct.value"
                (input)="onDleRecoveryChange($event)"
                class="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500" />
            </div>

            <!-- Parameter 3: Water Recycling Ratio -->
            <div class="space-y-1.5 font-mono">
              <div class="flex justify-between text-xs">
                <span class="text-slate-300">Water Recycling Efficiency</span>
                <span class="text-sky-400 font-bold tabular-nums">
                  {{ twin.waterRecycleRatio() }}%
                </span>
              </div>
              <input 
                type="range" 
                min="20" 
                max="98" 
                step="1" 
                [value]="twin.waterRecycleRatio()"
                (input)="onWaterRecycleChange($event)"
                class="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-sky-500" />
            </div>

            <!-- Target Product Selector -->
            <div class="space-y-1.5 font-mono">
              <span class="text-xs text-slate-300">Chemical Target Product</span>
              <div class="grid grid-cols-2 gap-2 text-xs">
                <button 
                  (click)="twin.setTargetProduct('LITHIUM_CARBONATE')"
                  [class]="twin.targetProduct() === 'LITHIUM_CARBONATE' ? 'bg-amber-500/20 text-amber-300 border-amber-500/40' : 'bg-slate-950 text-slate-400 hover:text-slate-200 border-slate-800'"
                  class="px-2 py-1.5 rounded border transition-colors text-center font-semibold">
                  Li2CO3 (Carbonate)
                </button>
                <button 
                  (click)="twin.setTargetProduct('LITHIUM_HYDROXIDE')"
                  [class]="twin.targetProduct() === 'LITHIUM_HYDROXIDE' ? 'bg-amber-500/20 text-amber-300 border-amber-500/40' : 'bg-slate-950 text-slate-400 hover:text-slate-200 border-slate-800'"
                  class="px-2 py-1.5 rounded border transition-colors text-center font-semibold">
                  LiOH·H2O (Hydroxide)
                </button>
              </div>
            </div>
          </div>
        </div>

        <!-- Right Column: 3D Preview Canvas & Key System Visualizers -->
        <div class="lg:col-span-8 space-y-6">
          
          <!-- Key Metrics Cards Ribbon -->
          <div class="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <!-- Metric 1: Lithium Production Rate -->
            <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
              <div class="flex items-center justify-between text-slate-400 text-xs font-mono">
                <span>LITHIUM RATE</span>
                <mat-icon class="text-emerald-400 text-sm">bolt</mat-icon>
              </div>
              <div class="mt-2 flex items-baseline gap-1.5 font-mono">
                <span class="text-2xl font-bold text-slate-100 tabular-nums">
                  {{ twin.activeLithiumProductionKgH().toFixed(1) }}
                </span>
                <span class="text-xs text-slate-400">kg Li/h</span>
              </div>
              <span class="mt-1 text-[10px] text-emerald-400 font-mono">
                {{ twin.activeProductOutputTonnesDay().toFixed(2) }} t/d Product
              </span>
            </div>

            <!-- Metric 2: Power Demand -->
            <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
              <div class="flex items-center justify-between text-slate-400 text-xs font-mono">
                <span>POWER DEMAND</span>
                <mat-icon class="text-amber-400 text-sm">electric_bolt</mat-icon>
              </div>
              <div class="mt-2 flex items-baseline gap-1.5 font-mono">
                <span class="text-2xl font-bold text-amber-400 tabular-nums">
                  {{ twin.energyNetwork().totalPowerDemandMW.toFixed(2) }}
                </span>
                <span class="text-xs text-slate-400">MW</span>
              </div>
              <span class="mt-1 text-[10px] text-slate-400 font-mono">
                Grid: {{ twin.energyNetwork().gridImportMW.toFixed(1) }} MW
              </span>
            </div>

            <!-- Metric 3: Water Demand -->
            <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
              <div class="flex items-center justify-between text-slate-400 text-xs font-mono">
                <span>FRESHWATER</span>
                <mat-icon class="text-sky-400 text-sm">water_drop</mat-icon>
              </div>
              <div class="mt-2 flex items-baseline gap-1.5 font-mono">
                <span class="text-2xl font-bold text-sky-400 tabular-nums">
                  {{ twin.waterNetwork().freshwaterIntakeM3H.toFixed(1) }}
                </span>
                <span class="text-xs text-slate-400">m³/h</span>
              </div>
              <span class="mt-1 text-[10px] text-sky-300 font-mono">
                {{ twin.waterNetwork().waterRecycleRatioPct }}% Recycled
              </span>
            </div>

            <!-- Metric 4: Project NPV -->
            <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
              <div class="flex items-center justify-between text-slate-400 text-xs font-mono">
                <span>PROJECT NPV (8%)</span>
                <mat-icon class="text-indigo-400 text-sm">payments</mat-icon>
              </div>
              <div class="mt-2 flex items-baseline gap-1.5 font-mono">
                <span class="text-2xl font-bold text-indigo-300 tabular-nums">
                  £{{ twin.economics().npv8PctGbpMillions.toFixed(1) }}M
                </span>
              </div>
              <span class="mt-1 text-[10px] text-indigo-400 font-mono">
                IRR: {{ twin.economics().irrPercent.toFixed(1) }}%
              </span>
            </div>
          </div>

          <!-- 3D Subsurface & Plant Twin Teaser Viewport -->
          <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
            <div class="flex items-center justify-between pb-2 border-b border-slate-800">
              <div class="flex items-center gap-2">
                <h3 class="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                  <mat-icon class="text-amber-400 text-sm">view_in_ar</mat-icon>
                  Cornwall Granitic Subsurface & Facility Model
                </h3>
              </div>
              <a routerLink="/twin-3d" class="text-xs font-mono text-amber-400 hover:text-amber-300 flex items-center gap-1">
                Open Full 3D Inspector
                <mat-icon class="text-xs">arrow_forward</mat-icon>
              </a>
            </div>

            <!-- Visual Cross-Section Cutaway Representation -->
            <div class="relative h-[280px] bg-slate-950 border border-slate-800 rounded-lg overflow-hidden flex flex-col justify-between p-4 font-mono text-xs">
              <div class="flex justify-between items-start z-10 text-slate-400">
                <div class="bg-slate-900/90 border border-slate-800 p-2 rounded text-[11px] space-y-1">
                  <div class="text-slate-200 font-bold">Carnmenellis Subsurface Cross-Section</div>
                  <div class="text-slate-400">Elevation: +120m to -4,000m Ordnance Datum</div>
                  <div class="text-amber-400">Granite Temperature Gradient: +38°C / km</div>
                </div>
                <div class="bg-slate-900/90 border border-slate-800 p-2 rounded text-right text-[11px]">
                  <div class="text-emerald-400 font-bold">ACTIVE SIMULATION</div>
                  <div class="text-slate-400">Mass Balance Δ: {{ twin.massBalance().imbalancePercent.toFixed(4) }}%</div>
                </div>
              </div>

              <!-- Schematic Visual Cutaway -->
              <div class="absolute inset-0 flex flex-col justify-between pointer-events-none opacity-80">
                <!-- Surface -->
                <div class="h-12 bg-emerald-950/20 border-b border-emerald-800/40 flex items-center px-4 text-emerald-400 text-[10px]">
                  SURFACE PLANT FACILITIES & SUBSTATION
                </div>
                <!-- Granite Massif -->
                <div class="h-28 bg-slate-900/80 border-b border-slate-800 flex items-center px-4 text-slate-500 text-[10px] justify-between">
                  <span>CARNMENELLIS GRANITE BODY (850 ppm Li)</span>
                  <span class="text-amber-500/60">UNDERGROUND DRIVES & SHAFTS</span>
                </div>
                <!-- Deep Geothermal Reservoir -->
                <div class="h-24 bg-red-950/20 flex items-center px-4 text-amber-400/80 text-[10px] justify-between">
                  <span>DEEP FAULT HYDROTHERMAL RESERVOIR (-4,000m, 180°C, 220 mg/L Li)</span>
                  <span class="text-sky-400/80">CNL-GT-01 PRODUCTION WELL</span>
                </div>
              </div>

              <div class="z-10 flex justify-between items-end text-[11px] text-slate-400">
                <span class="bg-slate-900/90 px-2 py-1 rounded border border-slate-800">
                  Click 3D Subsurface tab to rotate, inspect voxels, and toggle fault layers.
                </span>
                <a routerLink="/twin-3d" class="bg-amber-500 text-slate-950 px-3 py-1 rounded font-bold hover:bg-amber-400 transition-colors">
                  LAUNCH 3D TWIN
                </a>
              </div>
            </div>
          </div>

          <!-- AI Twin Diagnostics & Optimization Recommendations -->
          <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
            <div class="flex items-center justify-between pb-2 border-b border-slate-800">
              <div class="flex items-center gap-2">
                <h3 class="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                  <mat-icon class="text-amber-400 text-sm">psychology</mat-icon>
                  Gemini 3.7 Process Diagnostics & Optimization Engine
                </h3>
              </div>
              <button 
                (click)="aiAdvisor.runAiDiagnostics()"
                [disabled]="aiAdvisor.isLoading()"
                class="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-mono font-bold rounded transition-colors flex items-center gap-1">
                <mat-icon class="text-xs">{{ aiAdvisor.isLoading() ? 'sync' : 'auto_awesome' }}</mat-icon>
                {{ aiAdvisor.isLoading() ? 'Analyzing Twin...' : 'Run AI Process Diagnostics' }}
              </button>
            </div>

            @if (aiAdvisor.analysis(); as res) {
              <div class="space-y-3 text-xs font-mono text-slate-300 bg-slate-950/80 p-3 rounded-lg border border-slate-800">
                <p class="text-amber-300 font-semibold">{{ res.summary }}</p>
                
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-800">
                  <div>
                    <span class="text-[10px] text-slate-500 uppercase tracking-wider block mb-1">Identified Bottlenecks</span>
                    <ul class="list-disc list-inside space-y-1 text-slate-300">
                      @for (b of res.bottlenecks; track b) {
                        <li>{{ b }}</li>
                      }
                    </ul>
                  </div>
                  <div>
                    <span class="text-[10px] text-slate-500 uppercase tracking-wider block mb-1">Engineering Recommendations</span>
                    <ul class="list-disc list-inside space-y-1 text-emerald-300">
                      @for (r of res.recommendations; track r) {
                        <li>{{ r }}</li>
                      }
                    </ul>
                  </div>
                </div>

                <div class="pt-2 border-t border-slate-800 text-[11px] flex justify-between text-slate-400">
                  <span>{{ res.massBalanceAssessment }}</span>
                  <span class="text-sky-300">{{ res.decarbonizationAdvice }}</span>
                </div>
              </div>
            } @else {
              <div class="text-xs font-mono text-slate-500 italic p-3 bg-slate-950/50 rounded border border-slate-800">
                Click 'Run AI Process Diagnostics' to invoke Gemini server-side evaluation of current mass balance, DLE kinetics, power demand, and carbon optimization opportunities.
              </div>
            }
          </div>

        </div>
      </div>
    </div>
  `
})
export class Dashboard {
  twin = inject(DigitalTwin);
  aiAdvisor = inject(AiTwinAdvisor);

  onFlowChange(event: Event) {
    const value = parseFloat((event.target as HTMLInputElement).value);
    this.twin.setGeothermalFlowRate(value);
  }

  onOreChange(event: Event) {
    const value = parseFloat((event.target as HTMLInputElement).value);
    this.twin.setHardRockOreThroughput(value);
  }

  onDleRecoveryChange(event: Event) {
    const value = parseFloat((event.target as HTMLInputElement).value);
    this.twin.setDleRecovery(value);
  }

  onWaterRecycleChange(event: Event) {
    const value = parseFloat((event.target as HTMLInputElement).value);
    this.twin.setWaterRecycleRatio(value);
  }
}
