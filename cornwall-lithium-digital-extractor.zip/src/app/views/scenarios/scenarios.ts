import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwin } from '../../core/services/digital-twin';
import { ProvenanceBadge } from '../../components/provenance-badge/provenance-badge';

@Component({
  selector: 'app-scenarios',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule, ProvenanceBadge],
  template: `
    <div class="p-4 md:p-6 space-y-6 max-w-[1600px] mx-auto text-slate-100 font-sans">
      <!-- Title -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <h1 class="text-xl font-mono font-bold uppercase tracking-wide text-slate-100 flex items-center gap-2">
            <mat-icon class="text-indigo-400">analytics</mat-icon>
            Scenario Engineering, Monte Carlo & Project Economics
          </h1>
          <p class="text-xs font-mono text-slate-400 mt-0.5">
            Compare Production Scenarios · Sensitivity Tornado Analysis · Pareto Optimization Tradeoffs
          </p>
        </div>
        <div class="flex items-center gap-2 font-mono text-xs">
          <app-provenance-badge type="SIMULATION_OUTPUT"></app-provenance-badge>
          <span class="text-slate-400">FINANCIAL ENGINE: DISCOUNTED CASH FLOW (8%)</span>
        </div>
      </div>

      <!-- Financial Metrics Summary Cards -->
      @if (twin.economics(); as econ) {
        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 font-mono text-xs">
          <div class="p-3 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
            <span class="text-[10px] text-slate-500 uppercase block">INITIAL CAPEX</span>
            <span class="text-xl font-bold text-slate-100 tabular-nums">£{{ econ.capexGbpMillions }}M</span>
            <span class="text-[10px] text-slate-400 block">Capital Expenditure</span>
          </div>

          <div class="p-3 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
            <span class="text-[10px] text-slate-500 uppercase block">OPEX / TONNE</span>
            <span class="text-xl font-bold text-amber-400 tabular-nums">£{{ econ.opexGbpPerTonProduct }}</span>
            <span class="text-[10px] text-slate-400 block">per ton Li2CO3 eq</span>
          </div>

          <div class="p-3 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
            <span class="text-[10px] text-slate-500 uppercase block">PRODUCT PRICE</span>
            <span class="text-xl font-bold text-slate-200 tabular-nums">\${{ econ.productPriceUsdPerTonLi2CO3 }}</span>
            <span class="text-[10px] text-slate-400 block">USD/tonne benchmark</span>
          </div>

          <div class="p-3 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
            <span class="text-[10px] text-slate-500 uppercase block">NET PRESENT VALUE (8%)</span>
            <span class="text-xl font-bold text-emerald-400 tabular-nums">£{{ econ.npv8PctGbpMillions.toFixed(1) }}M</span>
            <span class="text-[10px] text-emerald-300 block">20-Year Project Life</span>
          </div>

          <div class="p-3 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
            <span class="text-[10px] text-slate-500 uppercase block">INTERNAL RATE RETURN</span>
            <span class="text-xl font-bold text-indigo-300 tabular-nums">{{ econ.irrPercent.toFixed(1) }}%</span>
            <span class="text-[10px] text-indigo-400 block">IRR</span>
          </div>

          <div class="p-3 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
            <span class="text-[10px] text-slate-500 uppercase block">PAYBACK PERIOD</span>
            <span class="text-xl font-bold text-sky-400 tabular-nums">{{ econ.paybackPeriodYears.toFixed(1) }} yrs</span>
            <span class="text-[10px] text-slate-400 block">Gross Margin: {{ econ.grossMarginPercent.toFixed(1) }}%</span>
          </div>
        </div>
      }

      <!-- Scenario Comparison Table -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-4 font-mono text-xs">
        <div class="flex items-center justify-between pb-2 border-b border-slate-800">
          <h2 class="font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
            <mat-icon class="text-amber-400 text-sm">compare_arrows</mat-icon>
            Engineering Design Scenario Comparison
          </h2>
          <span class="text-[10px] text-slate-400">4 PREDEFINED SCENARIOS</span>
        </div>

        <div class="overflow-x-auto border border-slate-800 rounded">
          <table class="w-full text-left">
            <thead class="bg-slate-950 text-slate-400 text-[10px] uppercase border-b border-slate-800">
              <tr>
                <th class="p-2">Scenario Name</th>
                <th class="p-2">Throughput</th>
                <th class="p-2">Recovery</th>
                <th class="p-2">Li Output</th>
                <th class="p-2">Energy/kg</th>
                <th class="p-2">Water/kg</th>
                <th class="p-2">OPEX (£/t)</th>
                <th class="p-2">Carbon (kg/kg)</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60 text-slate-300">
              @for (scen of twin.predefinedScenarios(); track scen.id) {
                <tr class="hover:bg-slate-800/50">
                  <td class="p-2 font-bold text-slate-100">
                    <div>{{ scen.name }}</div>
                    <div class="text-[10px] text-slate-500 font-normal">{{ scen.description }}</div>
                  </td>
                  <td class="p-2 font-bold text-amber-400 tabular-nums">{{ scen.throughputPct }}%</td>
                  <td class="p-2 font-bold text-emerald-400 tabular-nums">{{ scen.recoveryPct }}%</td>
                  <td class="p-2 font-bold text-slate-100 tabular-nums">{{ scen.lithiumOutputKgH.toFixed(1) }} kg/h</td>
                  <td class="p-2 tabular-nums text-slate-300">{{ scen.energyConsumptionkWhPerKgLi }} kWh</td>
                  <td class="p-2 tabular-nums text-sky-300">{{ scen.waterConsumptionM3PerKgLi }} m³</td>
                  <td class="p-2 tabular-nums text-amber-300">£{{ scen.opexGbpPerTon }}</td>
                  <td class="p-2 tabular-nums text-emerald-400">{{ scen.carbonKgCO2PerKgLi }} kg</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <!-- Sensitivity Analysis Tornado Chart -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-4 font-mono text-xs">
        <div class="flex items-center justify-between pb-2 border-b border-slate-800">
          <h2 class="font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
            <mat-icon class="text-amber-400 text-sm">bar_chart</mat-icon>
            NPV Sensitivity Analysis (Tornado Chart)
          </h2>
          <span class="text-[10px] text-slate-400">PARAMETRIC SWEEP</span>
        </div>

        <div class="space-y-3">
          @for (factor of twin.sensitivityFactors(); track factor.parameterName) {
            <div class="space-y-1">
              <div class="flex justify-between text-slate-300">
                <span>{{ factor.parameterName }} (Base: {{ factor.baseValue }} {{ factor.unit }})</span>
                <span class="text-slate-400">
                  Low: <strong class="text-rose-400">£{{ factor.npvLowGbpM.toFixed(0) }}M</strong> · 
                  High: <strong class="text-emerald-400">£{{ factor.npvHighGbpM.toFixed(0) }}M</strong>
                </span>
              </div>
              <div class="relative w-full bg-slate-950 h-3 rounded overflow-hidden flex items-center">
                <!-- Base mark -->
                <div class="absolute left-1/2 w-0.5 h-full bg-slate-400 z-10"></div>
                <!-- Range bar -->
                <div class="bg-indigo-500/60 h-full rounded" [style.margin-left.%]="20" [style.width.%]="60"></div>
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class Scenarios {
  twin = inject(DigitalTwin);
}
