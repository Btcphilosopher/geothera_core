import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwin } from '../../core/services/digital-twin';
import { ProvenanceBadge } from '../../components/provenance-badge/provenance-badge';

@Component({
  selector: 'app-maintenance',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule, ProvenanceBadge],
  template: `
    <div class="p-4 md:p-6 space-y-6 max-w-[1600px] mx-auto text-slate-100 font-sans">
      <!-- Title -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <h1 class="text-xl font-mono font-bold uppercase tracking-wide text-slate-100 flex items-center gap-2">
            <mat-icon class="text-amber-400">build</mat-icon>
            Asset Reliability & Equipment Failure Simulator
          </h1>
          <p class="text-xs font-mono text-slate-400 mt-0.5">
            Simulate Asset Trips · Observe Real-Time Process Degradation & Downstream Storage Inventory Depletion
          </p>
        </div>
        <div class="flex items-center gap-2 font-mono text-xs">
          <app-provenance-badge type="SIMULATION_OUTPUT"></app-provenance-badge>
          <span class="text-slate-400">PROPAGATION ENGINE ACTIVE</span>
        </div>
      </div>

      <!-- Simulated Failure Injection Command Console -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3 font-mono">
        <div class="flex items-center justify-between pb-2 border-b border-slate-800">
          <h2 class="text-xs font-bold tracking-wider text-slate-300 uppercase flex items-center gap-1.5">
            <mat-icon class="text-rose-400 text-sm">error</mat-icon>
            Failure Scenario Injector Console
          </h2>
          <span class="text-[10px] text-slate-400">TEST PLANT RESILIENCE</span>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          <button 
            (click)="twin.toggleEquipmentFailure('PUMP_CNL_P1')"
            [class]="twin.equipmentFailureState()['PUMP_CNL_P1'] ? 'bg-rose-950 text-rose-300 border-rose-500 font-bold' : 'bg-slate-950 text-slate-300 hover:text-white border-slate-800'"
            class="p-3 rounded border text-left transition-colors flex flex-col justify-between space-y-2">
            <div class="flex justify-between items-center">
              <span>CNL-P1 Well Pump Trip</span>
              <mat-icon class="text-sm text-rose-400">power_settings_new</mat-icon>
            </div>
            <span class="text-[10px] text-slate-400">
              State: <strong class="uppercase">{{ twin.equipmentFailureState()['PUMP_CNL_P1'] ? 'TRIPPED (0 L/s)' : 'NOMINAL' }}</strong>
            </span>
          </button>

          <button 
            (click)="twin.toggleEquipmentFailure('CRUSHER_CR_1')"
            [class]="twin.equipmentFailureState()['CRUSHER_CR_1'] ? 'bg-rose-950 text-rose-300 border-rose-500 font-bold' : 'bg-slate-950 text-slate-300 hover:text-white border-slate-800'"
            class="p-3 rounded border text-left transition-colors flex flex-col justify-between space-y-2">
            <div class="flex justify-between items-center">
              <span>Primary Crusher Jam</span>
              <mat-icon class="text-sm text-rose-400">power_settings_new</mat-icon>
            </div>
            <span class="text-[10px] text-slate-400">
              State: <strong class="uppercase">{{ twin.equipmentFailureState()['CRUSHER_CR_1'] ? 'STALLED (0 t/h)' : 'NOMINAL' }}</strong>
            </span>
          </button>

          <button 
            (click)="twin.toggleEquipmentFailure('DLE_SKID_1')"
            [class]="twin.equipmentFailureState()['DLE_SKID_1'] ? 'bg-rose-950 text-rose-300 border-rose-500 font-bold' : 'bg-slate-950 text-slate-300 hover:text-white border-slate-800'"
            class="p-3 rounded border text-left transition-colors flex flex-col justify-between space-y-2">
            <div class="flex justify-between items-center">
              <span>DLE Contactor Skid A Trip</span>
              <mat-icon class="text-sm text-rose-400">power_settings_new</mat-icon>
            </div>
            <span class="text-[10px] text-slate-400">
              State: <strong class="uppercase">{{ twin.equipmentFailureState()['DLE_SKID_1'] ? 'REDUCED (-75%)' : 'NOMINAL' }}</strong>
            </span>
          </button>

          <button 
            (click)="twin.toggleEquipmentFailure('MILL_SAG_1')"
            [class]="twin.equipmentFailureState()['MILL_SAG_1'] ? 'bg-rose-950 text-rose-300 border-rose-500 font-bold' : 'bg-slate-950 text-slate-300 hover:text-white border-slate-800'"
            class="p-3 rounded border text-left transition-colors flex flex-col justify-between space-y-2">
            <div class="flex justify-between items-center">
              <span>Ball Mill Liner Wear</span>
              <mat-icon class="text-sm text-rose-400">power_settings_new</mat-icon>
            </div>
            <span class="text-[10px] text-slate-400">
              State: <strong class="uppercase">{{ twin.equipmentFailureState()['MILL_SAG_1'] ? 'DEGRADED' : 'NOMINAL' }}</strong>
            </span>
          </button>
        </div>
      </div>

      <!-- Asset Condition & Reliability Table -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3 font-mono text-xs">
        <div class="flex items-center justify-between pb-2 border-b border-slate-800">
          <h2 class="font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
            <mat-icon class="text-amber-400 text-sm">settings_suggest</mat-icon>
            Critical Industrial Assets Telemetry
          </h2>
        </div>

        <div class="overflow-x-auto border border-slate-800 rounded">
          <table class="w-full text-left">
            <thead class="bg-slate-950 text-slate-400 text-[10px] uppercase border-b border-slate-800">
              <tr>
                <th class="p-2">Asset Tag</th>
                <th class="p-2">Equipment Description</th>
                <th class="p-2">Operating Hours</th>
                <th class="p-2">MTBF</th>
                <th class="p-2">Failure Prob</th>
                <th class="p-2 text-right">Status</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60 text-slate-300">
              <tr>
                <td class="p-2 font-bold text-amber-300">PMP-GT-01</td>
                <td class="p-2">Geothermal Submersible Well Pump</td>
                <td class="p-2 tabular-nums">4,210 h</td>
                <td class="p-2 tabular-nums">12,000 h</td>
                <td class="p-2 tabular-nums text-emerald-400">2.1%</td>
                <td class="p-2 text-right">
                  <span [class]="twin.equipmentFailureState()['PUMP_CNL_P1'] ? 'bg-rose-950 text-rose-400 border-rose-800' : 'bg-emerald-950 text-emerald-400 border-emerald-800'" class="px-2 py-0.5 rounded border font-bold">
                    {{ twin.equipmentFailureState()['PUMP_CNL_P1'] ? '● FAILED' : '● NOMINAL' }}
                  </span>
                </td>
              </tr>
              <tr>
                <td class="p-2 font-bold text-amber-300">CR-01</td>
                <td class="p-2">Primary Hard-Rock Jaw Crusher</td>
                <td class="p-2 tabular-nums">1,850 h</td>
                <td class="p-2 tabular-nums">8,500 h</td>
                <td class="p-2 tabular-nums text-emerald-400">1.4%</td>
                <td class="p-2 text-right">
                  <span [class]="twin.equipmentFailureState()['CRUSHER_CR_1'] ? 'bg-rose-950 text-rose-400 border-rose-800' : 'bg-emerald-950 text-emerald-400 border-emerald-800'" class="px-2 py-0.5 rounded border font-bold">
                    {{ twin.equipmentFailureState()['CRUSHER_CR_1'] ? '● FAILED' : '● NOMINAL' }}
                  </span>
                </td>
              </tr>
              <tr>
                <td class="p-2 font-bold text-amber-300">DLE-SKID-A</td>
                <td class="p-2">Direct Lithium Extraction Contactor Skid</td>
                <td class="p-2 tabular-nums">6,400 h</td>
                <td class="p-2 tabular-nums">15,000 h</td>
                <td class="p-2 tabular-nums text-emerald-400">0.8%</td>
                <td class="p-2 text-right">
                  <span [class]="twin.equipmentFailureState()['DLE_SKID_1'] ? 'bg-rose-950 text-rose-400 border-rose-800' : 'bg-emerald-950 text-emerald-400 border-emerald-800'" class="px-2 py-0.5 rounded border font-bold">
                    {{ twin.equipmentFailureState()['DLE_SKID_1'] ? '● DEGRADED' : '● NOMINAL' }}
                  </span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class Maintenance {
  twin = inject(DigitalTwin);
}
