import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwin } from '../../core/services/digital-twin';
import { ProvenanceBadge } from '../../components/provenance-badge/provenance-badge';

@Component({
  selector: 'app-flowsheet',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule, ProvenanceBadge],
  template: `
    <div class="p-4 md:p-6 space-y-6 max-w-[1600px] mx-auto text-slate-100 font-sans">
      <!-- Header -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <h1 class="text-xl font-mono font-bold uppercase tracking-wide text-slate-100 flex items-center gap-2">
            <mat-icon class="text-amber-400">schema</mat-icon>
            Interactive Process Flowsheet & P&ID Diagram
          </h1>
          <p class="text-xs font-mono text-slate-400 mt-0.5">
            Live Stream Mass Balance · Click Any Component Node to Inspect Sensor & Pump Telemetry
          </p>
        </div>
        <div class="flex items-center gap-2 font-mono text-xs">
          <app-provenance-badge type="SIMULATION_OUTPUT"></app-provenance-badge>
          <span class="text-slate-400">MODE: {{ twin.extractionMode() }}</span>
        </div>
      </div>

      <!-- Main Flowsheet Interactive Canvas Stage -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 font-mono">
        <div class="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-4">
          <div class="flex items-center justify-between pb-2 border-b border-slate-800">
            <h2 class="text-xs font-bold tracking-wider text-slate-300 uppercase flex items-center gap-1.5">
              <mat-icon class="text-amber-400 text-sm">account_tree</mat-icon>
              P&ID Piping & Instrumentation Topology
            </h2>
            <div class="flex items-center gap-2 text-[10px] text-slate-400">
              <span class="flex items-center gap-1"><span class="w-2 h-2 rounded-full bg-emerald-400"></span> Flowing Stream</span>
              <span class="flex items-center gap-1"><span class="w-2 h-2 rounded-full bg-amber-400"></span> Sensor Probe</span>
            </div>
          </div>

          <!-- Flowsheet Diagram Canvas -->
          <div class="relative h-[420px] bg-slate-950 border border-slate-800 rounded-lg p-6 overflow-hidden select-none">
            <!-- Connecting Pipes / Streams -->
            <svg class="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 800 400">
              <!-- Stream 1: Well -> Pump -->
              <path d="M 120 100 L 220 100" stroke="#f59e0b" stroke-width="3" stroke-dasharray="6,4" class="animate-pulse" />
              <!-- Stream 2: Pump -> DLE -->
              <path d="M 270 100 L 370 100" stroke="#10b981" stroke-width="3" stroke-dasharray="6,4" class="animate-pulse" />
              <!-- Stream 3: DLE -> Concentrator -->
              <path d="M 420 100 L 520 100" stroke="#10b981" stroke-width="3" stroke-dasharray="6,4" class="animate-pulse" />
              <!-- Stream 4: Concentrator -> Reactor -->
              <path d="M 570 100 L 670 100" stroke="#10b981" stroke-width="3" opacity="0.8" />
              <!-- Stream 5: Depleted Brine -> Reinjection Well -->
              <path d="M 395 130 L 395 280 L 120 280" stroke="#38bdf8" stroke-width="2" stroke-dasharray="4,4" />
            </svg>

            <!-- Flowsheet Nodes as Interactive Buttons -->
            <div class="relative z-10 grid grid-cols-4 gap-6 h-full items-center">
              
              <!-- Node 1: Well / Mine -->
              <button 
                type="button"
                (click)="selectNode('WELL')"
                [class.ring-2]="selectedNode() === 'WELL'"
                class="p-3 bg-slate-900 border border-slate-800 rounded-lg shadow-lg text-left cursor-pointer hover:border-amber-500/80 transition-all space-y-2">
                <div class="flex items-center justify-between text-xs font-bold text-amber-300">
                  <span>1. PRODUCTION WELL</span>
                  <mat-icon class="text-sm text-amber-400">hot_tub</mat-icon>
                </div>
                <div class="text-[10px] text-slate-400">CNL-GT-01 (Depth: 4000m)</div>
                <div class="text-[11px] font-bold text-emerald-400 tabular-nums">
                  {{ twin.extractionMode() === 'HARD_ROCK' ? twin.hardRockMine().targetOreThroughputTonnesDay + ' t/d' : twin.geothermalReservoir().designFlowRateLs.value + ' L/s @ 175°C' }}
                </div>
              </button>

              <!-- Node 2: Wellhead Pump -->
              <button 
                type="button"
                (click)="selectNode('PUMP')"
                [class.ring-2]="selectedNode() === 'PUMP'"
                class="p-3 bg-slate-900 border border-slate-800 rounded-lg shadow-lg text-left cursor-pointer hover:border-amber-500/80 transition-all space-y-2">
                <div class="flex items-center justify-between text-xs font-bold text-slate-200">
                  <span>2. PUMP CNL-P1</span>
                  <mat-icon class="text-sm text-sky-400">mode_fan</mat-icon>
                </div>
                <div class="text-[10px] text-slate-400">Submersible Head: 400m</div>
                <div class="text-[11px] font-bold text-amber-400 tabular-nums">
                  Power: {{ (twin.geothermalReservoir().designFlowRateLs.value * 0.0068).toFixed(2) }} MW
                </div>
              </button>

              <!-- Node 3: DLE Contactor -->
              <button 
                type="button"
                (click)="selectNode('DLE')"
                [class.ring-2]="selectedNode() === 'DLE'"
                class="p-3 bg-slate-900 border border-slate-800 rounded-lg shadow-lg text-left cursor-pointer hover:border-amber-500/80 transition-all space-y-2">
                <div class="flex items-center justify-between text-xs font-bold text-emerald-300">
                  <span>3. DLE CONTACTOR</span>
                  <mat-icon class="text-sm text-emerald-400">published_with_changes</mat-icon>
                </div>
                <div class="text-[10px] text-slate-400">Sorbent: Inorganic Titanate</div>
                <div class="text-[11px] font-bold text-emerald-400 tabular-nums">
                  Rec: {{ twin.dleProcess().recoveryPct.value }}% (Eluate {{ twin.dleProcess().eluateLithiumMgL }} mg/L)
                </div>
              </button>

              <!-- Node 4: Chemical Reactor & Crystallizer -->
              <button 
                type="button"
                (click)="selectNode('REACTOR')"
                [class.ring-2]="selectedNode() === 'REACTOR'"
                class="p-3 bg-slate-900 border border-slate-800 rounded-lg shadow-lg text-left cursor-pointer hover:border-amber-500/80 transition-all space-y-2">
                <div class="flex items-center justify-between text-xs font-bold text-indigo-300">
                  <span>4. CHEMICAL PLANT</span>
                  <mat-icon class="text-sm text-indigo-400">science</mat-icon>
                </div>
                <div class="text-[10px] text-slate-400">Target: {{ twin.targetProduct() }}</div>
                <div class="text-[11px] font-bold text-emerald-300 tabular-nums">
                  Output: {{ twin.activeProductOutputTonnesDay().toFixed(2) }} t/d
                </div>
              </button>

            </div>
          </div>
        </div>

        <!-- Right: Node Inspector Drawer -->
        <div class="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-4">
          <div class="flex items-center justify-between pb-2 border-b border-slate-800">
            <h3 class="text-xs font-bold tracking-wider text-slate-300 uppercase flex items-center gap-1.5">
              <mat-icon class="text-amber-400 text-sm">info</mat-icon>
              P&ID Node Telemetry Inspector
            </h3>
            <span class="text-[10px] text-emerald-400 font-bold">NODE: {{ selectedNode() }}</span>
          </div>

          <div class="space-y-3 text-xs">
            <div class="p-3 bg-slate-950 border border-slate-800 rounded space-y-2">
              <div class="font-bold text-slate-200">Selected Asset Details</div>
              <p class="text-slate-400">
                Inspecting asset telemetry for <strong class="text-amber-300">{{ selectedNode() }}</strong> in the process flowsheet topology.
              </p>
            </div>

            <div class="p-3 bg-slate-950 border border-slate-800 rounded space-y-2">
              <div class="font-bold text-slate-200">Mass Stream Flow Metrics</div>
              <div class="space-y-1 text-slate-300">
                <div class="flex justify-between"><span>Input Lithium Stream:</span><span class="font-bold text-amber-400">{{ twin.massBalance().inputLithiumKgH.toFixed(2) }} kg/h</span></div>
                <div class="flex justify-between"><span>Product Stream:</span><span class="font-bold text-emerald-400">{{ twin.massBalance().outputProductLithiumKgH.toFixed(2) }} kg/h</span></div>
                <div class="flex justify-between"><span>Waste Stream:</span><span class="font-bold text-slate-400">{{ twin.massBalance().outputWasteLithiumKgH.toFixed(2) }} kg/h</span></div>
              </div>
            </div>

            <div class="p-3 bg-slate-950 border border-slate-800 rounded space-y-2">
              <div class="font-bold text-slate-200">Simulated Fault Test</div>
              <button 
                (click)="twin.toggleEquipmentFailure('PUMP_CNL_P1')"
                class="w-full py-2 bg-rose-950/80 hover:bg-rose-900 text-rose-300 border border-rose-800 font-bold rounded transition-colors text-center">
                {{ twin.equipmentFailureState()['PUMP_CNL_P1'] ? 'RESET WELL PUMP TRIP' : 'SIMULATE WELL PUMP TRIP' }}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class Flowsheet {
  twin = inject(DigitalTwin);
  selectedNode = signal<string>('WELL');

  selectNode(nodeId: string) {
    this.selectedNode.set(nodeId);
  }
}
