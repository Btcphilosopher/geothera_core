import { Component, ChangeDetectionStrategy, input } from '@angular/core';
import { ProvenanceType } from '../../core/models/digital-twin-state';

@Component({
  selector: 'app-provenance-badge',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <span 
      class="inline-flex items-center px-1.5 py-0.5 text-[10px] font-mono tracking-wider uppercase border rounded"
      [class]="badgeClass()">
      {{ type() }}
    </span>
  `
})
export class ProvenanceBadge {
  readonly type = input<ProvenanceType>('SYNTHETIC');

  badgeClass() {
    switch (this.type()) {
      case 'PUBLIC':
        return 'bg-emerald-950/60 text-emerald-300 border-emerald-800/60';
      case 'USER_DEFINED':
        return 'bg-amber-950/60 text-amber-300 border-amber-800/60';
      case 'ENGINEERING_ASSUMPTION':
        return 'bg-sky-950/60 text-sky-300 border-sky-800/60';
      case 'SYNTHETIC':
        return 'bg-slate-800 text-slate-300 border-slate-700';
      case 'SIMULATION_OUTPUT':
        return 'bg-violet-950/60 text-violet-300 border-violet-800/60';
      default:
        return 'bg-slate-800 text-slate-400 border-slate-700';
    }
  }
}
