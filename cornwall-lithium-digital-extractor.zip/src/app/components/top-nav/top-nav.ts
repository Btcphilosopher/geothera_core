import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwin } from '../../core/services/digital-twin';
import { SimulationClock } from '../../core/services/simulation-clock';
import { ExtractionMode, SimulationSpeed } from '../../core/models/digital-twin-state';

@Component({
  selector: 'app-top-nav',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, RouterLinkActive, MatIconModule],
  template: `
    <header class="flex flex-col bg-slate-950 border-b border-slate-800 text-slate-200 select-none">
      <!-- Top Zone Bar -->
      <div class="flex items-center justify-between px-4 py-2 border-b border-slate-900">
        <!-- Zone 1: Wordmark -->
        <div class="flex items-center gap-3">
          <div class="w-7 h-7 rounded bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 font-bold font-mono text-xs">
            CL
          </div>
          <div class="flex flex-col">
            <a routerLink="/" class="text-sm font-bold tracking-tight text-slate-100 uppercase font-mono">
              Cornwall Lithium Digital Extractor
            </a>
            <span class="text-[10px] font-mono text-slate-500 tracking-wider">
              INDUSTRIAL DIGITAL TWIN & SIMULATOR · VER 2026.1
            </span>
          </div>
        </div>

        <!-- Zone 2: Navigation Links -->
        <nav class="hidden lg:flex items-center gap-1 text-xs font-mono">
          <a routerLink="/dashboard" routerLinkActive="bg-slate-800 text-amber-400 border-slate-700" class="px-2.5 py-1.5 rounded border border-transparent text-slate-400 hover:text-slate-100 transition-colors flex items-center gap-1.5">
            <mat-icon class="text-sm">dashboard</mat-icon>
            Workstation
          </a>
          <a routerLink="/geology" routerLinkActive="bg-slate-800 text-amber-400 border-slate-700" class="px-2.5 py-1.5 rounded border border-transparent text-slate-400 hover:text-slate-100 transition-colors flex items-center gap-1.5">
            <mat-icon class="text-sm">terrain</mat-icon>
            Geology
          </a>
          <a routerLink="/mine-designer" routerLinkActive="bg-slate-800 text-amber-400 border-slate-700" class="px-2.5 py-1.5 rounded border border-transparent text-slate-400 hover:text-slate-100 transition-colors flex items-center gap-1.5">
            <mat-icon class="text-sm">precision_manufacturing</mat-icon>
            Mine & Wells
          </a>
          <a routerLink="/process-plant" routerLinkActive="bg-slate-800 text-amber-400 border-slate-700" class="px-2.5 py-1.5 rounded border border-transparent text-slate-400 hover:text-slate-100 transition-colors flex items-center gap-1.5">
            <mat-icon class="text-sm">valve</mat-icon>
            Process & DLE
          </a>
          <a routerLink="/flowsheet" routerLinkActive="bg-slate-800 text-amber-400 border-slate-700" class="px-2.5 py-1.5 rounded border border-transparent text-slate-400 hover:text-slate-100 transition-colors flex items-center gap-1.5">
            <mat-icon class="text-sm">schema</mat-icon>
            P&ID Flowsheet
          </a>
          <a routerLink="/twin-3d" routerLinkActive="bg-slate-800 text-amber-400 border-slate-700" class="px-2.5 py-1.5 rounded border border-transparent text-slate-400 hover:text-slate-100 transition-colors flex items-center gap-1.5">
            <mat-icon class="text-sm">view_in_ar</mat-icon>
            3D Subsurface
          </a>
          <a routerLink="/water-energy" routerLinkActive="bg-slate-800 text-amber-400 border-slate-700" class="px-2.5 py-1.5 rounded border border-transparent text-slate-400 hover:text-slate-100 transition-colors flex items-center gap-1.5">
            <mat-icon class="text-sm">water_drop</mat-icon>
            Water & Energy
          </a>
          <a routerLink="/maintenance" routerLinkActive="bg-slate-800 text-amber-400 border-slate-700" class="px-2.5 py-1.5 rounded border border-transparent text-slate-400 hover:text-slate-100 transition-colors flex items-center gap-1.5">
            <mat-icon class="text-sm">build</mat-icon>
            Reliability
          </a>
          <a routerLink="/scenarios" routerLinkActive="bg-slate-800 text-amber-400 border-slate-700" class="px-2.5 py-1.5 rounded border border-transparent text-slate-400 hover:text-slate-100 transition-colors flex items-center gap-1.5">
            <mat-icon class="text-sm">analytics</mat-icon>
            Scenarios & Econ
          </a>
          <a routerLink="/report" routerLinkActive="bg-slate-800 text-amber-400 border-slate-700" class="px-2.5 py-1.5 rounded border border-transparent text-slate-400 hover:text-slate-100 transition-colors flex items-center gap-1.5">
            <mat-icon class="text-sm">description</mat-icon>
            Report
          </a>
        </nav>

        <!-- Zone 3: Architecture Mode & Simulation Time Controls -->
        <div class="flex items-center gap-3">
          <!-- Architecture Switcher -->
          <div class="flex items-center p-0.5 bg-slate-900 rounded border border-slate-800 font-mono text-[11px]">
            <button 
              (click)="setMode('GEOTHERMAL_BRINE')"
              [class]="twin.extractionMode() === 'GEOTHERMAL_BRINE' ? 'bg-amber-500/20 text-amber-300 border-amber-500/40' : 'text-slate-400 hover:text-slate-200'"
              class="px-2.5 py-1 rounded border transition-colors flex items-center gap-1">
              <mat-icon class="text-xs">hot_tub</mat-icon>
              MODE B: GEOTHERMAL
            </button>
            <button 
              (click)="setMode('HARD_ROCK')"
              [class]="twin.extractionMode() === 'HARD_ROCK' ? 'bg-amber-500/20 text-amber-300 border-amber-500/40' : 'text-slate-400 hover:text-slate-200'"
              class="px-2.5 py-1 rounded border transition-colors flex items-center gap-1">
              <mat-icon class="text-xs">landscape</mat-icon>
              MODE A: HARD-ROCK
            </button>
          </div>

          <!-- Simulation Clock Ribbon -->
          <div class="flex items-center gap-2 bg-slate-900 px-2.5 py-1 rounded border border-slate-800 font-mono text-xs">
            <button (click)="clock.toggleRun()" class="text-amber-400 hover:text-amber-300 transition-colors flex items-center">
              <mat-icon class="text-sm">{{ clock.isRunning() ? 'pause' : 'play_arrow' }}</mat-icon>
            </button>
            <span class="text-slate-300 font-bold tabular-nums min-w-[110px]">
              {{ clock.formattedTime() }}
            </span>
            <div class="flex items-center gap-1 text-[10px]">
              @for (spd of speeds; track spd) {
                <button 
                  (click)="clock.setSpeed(spd)"
                  [class]="clock.speed() === spd ? 'bg-slate-700 text-amber-300 font-bold' : 'text-slate-500 hover:text-slate-300'"
                  class="px-1 py-0.5 rounded">
                  {{ spd }}×
                </button>
              }
            </div>
          </div>
        </div>
      </div>
    </header>
  `
})
export class TopNav {
  twin = inject(DigitalTwin);
  clock = inject(SimulationClock);

  speeds: SimulationSpeed[] = [1, 5, 20, 100];

  setMode(mode: ExtractionMode) {
    this.twin.setExtractionMode(mode);
  }
}
