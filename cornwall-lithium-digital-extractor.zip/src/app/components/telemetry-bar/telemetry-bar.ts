import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwin } from '../../core/services/digital-twin';

@Component({
  selector: 'app-telemetry-bar',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <footer class="sticky bottom-0 z-50 bg-slate-950/95 backdrop-blur border-t border-slate-800 text-slate-300 font-mono text-xs select-none shadow-2xl">
      <div class="grid grid-cols-2 md:grid-cols-6 lg:grid-cols-7 divide-x divide-slate-800/80 items-center">
        <!-- KPI 1: Throughput -->
        <div class="px-3 py-2 flex flex-col justify-center">
          <span class="text-[10px] text-slate-500 tracking-wider uppercase">THROUGHPUT</span>
          <div class="flex items-baseline gap-1">
            <span class="text-sm font-bold text-slate-100 tabular-nums">
              {{ twin.extractionMode() === 'HARD_ROCK' ? twin.hardRockMine().targetOreThroughputTonnesDay : twin.geothermalReservoir().designFlowRateLs.value }}
            </span>
            <span class="text-[10px] text-slate-400">
              {{ twin.extractionMode() === 'HARD_ROCK' ? 't/day ore' : 'L/s brine' }}
            </span>
          </div>
        </div>

        <!-- KPI 2: Energy -->
        <div class="px-3 py-2 flex flex-col justify-center">
          <span class="text-[10px] text-slate-500 tracking-wider uppercase">ENERGY DEMAND</span>
          <div class="flex items-baseline gap-1">
            <span class="text-sm font-bold text-amber-400 tabular-nums">
              {{ twin.energyNetwork().totalPowerDemandMW.toFixed(2) }}
            </span>
            <span class="text-[10px] text-slate-400">MW</span>
          </div>
        </div>

        <!-- KPI 3: Water -->
        <div class="px-3 py-2 flex flex-col justify-center">
          <span class="text-[10px] text-slate-500 tracking-wider uppercase">FRESHWATER INTAKE</span>
          <div class="flex items-baseline gap-1">
            <span class="text-sm font-bold text-sky-400 tabular-nums">
              {{ twin.waterNetwork().freshwaterIntakeM3H.toFixed(1) }}
            </span>
            <span class="text-[10px] text-slate-400">m³/h</span>
          </div>
        </div>

        <!-- KPI 4: Lithium Production Rate -->
        <div class="px-3 py-2 flex flex-col justify-center">
          <span class="text-[10px] text-slate-500 tracking-wider uppercase">LITHIUM RATE</span>
          <div class="flex items-baseline gap-1">
            <span class="text-sm font-bold text-emerald-400 tabular-nums">
              {{ twin.activeLithiumProductionKgH().toFixed(1) }}
            </span>
            <span class="text-[10px] text-slate-400">kg Li/h</span>
          </div>
        </div>

        <!-- KPI 5: Product Output -->
        <div class="px-3 py-2 flex flex-col justify-center">
          <span class="text-[10px] text-slate-500 tracking-wider uppercase">PRODUCT OUTPUT</span>
          <div class="flex items-baseline gap-1">
            <span class="text-sm font-bold text-emerald-300 tabular-nums">
              {{ twin.activeProductOutputTonnesDay().toFixed(2) }}
            </span>
            <span class="text-[10px] text-slate-400">t/day {{ twin.targetProduct() === 'LITHIUM_CARBONATE' ? 'Li2CO3' : 'LiOH' }}</span>
          </div>
        </div>

        <!-- KPI 6: Mass Balance Status -->
        <div class="px-3 py-2 flex flex-col justify-center">
          <span class="text-[10px] text-slate-500 tracking-wider uppercase">MASS BALANCE</span>
          <div class="flex items-center gap-1.5">
            <span 
              [class]="twin.massBalance().isSatisfied ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' : 'bg-rose-500/20 text-rose-400 border-rose-500/30'"
              class="px-1.5 py-0.5 text-[10px] rounded border font-semibold">
              {{ twin.massBalance().isSatisfied ? '● BALANCED' : '▲ IMBALANCE' }}
            </span>
            <span class="text-[10px] text-slate-400 tabular-nums">
              Δ {{ twin.massBalance().imbalancePercent.toFixed(4) }}%
            </span>
          </div>
        </div>

        <!-- KPI 7: Latest Telemetry Event -->
        <div class="hidden lg:flex col-span-1 px-3 py-2 items-center gap-2 overflow-hidden">
          <mat-icon class="text-amber-500 text-sm shrink-0">sensors</mat-icon>
          <div class="flex flex-col min-w-0">
            <span class="text-[9px] text-slate-500 truncate">
              {{ twin.telemetryLogs()[0]?.source || 'SYSTEM' }} @ {{ twin.telemetryLogs()[0]?.timestamp || '12:00:00' }}
            </span>
            <span class="text-[11px] text-slate-300 truncate">
              {{ twin.telemetryLogs()[0]?.message || 'Digital twin running.' }}
            </span>
          </div>
        </div>
      </div>
    </footer>
  `
})
export class TelemetryBar {
  twin = inject(DigitalTwin);
}
