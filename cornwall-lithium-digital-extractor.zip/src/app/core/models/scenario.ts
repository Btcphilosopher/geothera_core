import { ExtractionMode, ProductType } from './digital-twin-state';

export interface SystemScenario {
  id: string;
  name: string;
  description: string;
  mode: ExtractionMode;
  targetProduct: ProductType;
  throughputPct: number;
  recoveryPct: number;
  lithiumOutputKgH: number;
  energyConsumptionkWhPerKgLi: number;
  waterConsumptionM3PerKgLi: number;
  opexGbpPerTon: number;
  carbonKgCO2PerKgLi: number;
}

export interface MonteCarloIterationResult {
  runId: number;
  lithiumGrade: number;
  recovery: number;
  wellFlow: number;
  lithiumOutputKgH: number;
  npvGbpM: number;
}

export interface ParetoPoint {
  scenarioName: string;
  productionKgH: number;
  energyKWhPerKg: number;
  waterM3PerKg: number;
  opexGbpPerTon: number;
  carbonKgCO2PerKg: number;
}
