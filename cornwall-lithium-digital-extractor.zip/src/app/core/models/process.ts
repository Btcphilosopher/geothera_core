import { DleCycleStage, DleTechnology, ProductType, ProvenanceValue } from './digital-twin-state';

export interface CrusherTwinConfig {
  feedSizeMm: number;
  productSizeP80Mm: number;
  throughputTonnesHour: number;
  installedPowerkW: number;
  efficiencyPct: number;
  specificEnergykWhPerTon: number;
}

export interface GrindingMillConfig {
  millType: 'SAG' | 'BALL_MILL' | 'ROD_MILL';
  feedSizeP80Mm: number;
  targetGrindP80Microns: number;
  throughputTonnesHour: number;
  installedPowerkW: number;
  recirculationRatioPct: number;
  specificEnergykWhPerTon: number;
}

export interface MineralSeparationConfig {
  technology: 'FLOTATION' | 'DENSE_MEDIA' | 'MAGNETIC' | 'GRAVITY';
  feedMassFlowTH: number;
  feedLithiumGradePpm: number;
  recoveryPct: number;
  concentrateGradeLi2OPct: number;
  waterDemandM3PerTon: number;
  energyDemandkWhPerTon: number;
}

export interface DleProcessConfig {
  technology: DleTechnology;
  recoveryPct: ProvenanceValue<number>;
  selectivityLiVsMultivalents: ProvenanceValue<number>;
  cycleTimeMinutes: number;
  sorbentCapacityMgPerG: number;
  regenerationEfficiencyPct: number;
  brineFeedRateLs: number;
  currentCycleStage: DleCycleStage;
  cycleTimeRemainingSeconds: number;
  eluateLithiumMgL: number;
  waterConsumptionM3PerKgLi: number;
  energyConsumptionkWhPerKgLi: number;
}

export interface ChemicalPlantConfig {
  targetProduct: ProductType;
  conversionYieldPct: number;
  reagentSodiumCarbonateKgPerKgLi: number;
  reagentLimeKgPerKgLi: number;
  reagentAcidKgPerKgLi: number;
  thermalEnergykWhPerKgProduct: number;
  electricalEnergykWhPerKgProduct: number;
  waterM3PerKgProduct: number;
  targetPurityPct: number; // e.g. 99.5%
  maxImpurityNaPpm: number;
  maxImpurityKPpm: number;
  maxImpurityCaPpm: number;
  maxImpurityFePpm: number;
}

export interface PlantStream {
  id: string;
  name: string;
  fromNodeId: string;
  toNodeId: string;
  massFlowKgH: number;
  liquidFlowM3H: number;
  temperatureC: number;
  pressureBar: number;
  lithiumConcentrationPpm: number;
  solidContentPct: number;
}

export interface ProcessNode {
  id: string;
  name: string;
  type: 'MINE' | 'WELL' | 'CRUSHER' | 'MILL' | 'SEPARATOR' | 'DLE_UNIT' | 'EVAPORATOR' | 'REACTOR' | 'TANK' | 'PUMP' | 'FILTER' | 'REINJECTION';
  x: number;
  y: number;
  status: 'OPERATIONAL' | 'WARNING' | 'FAILED' | 'OFFLINE';
  powerkW: number;
  capacityUtilizationPct: number;
}
