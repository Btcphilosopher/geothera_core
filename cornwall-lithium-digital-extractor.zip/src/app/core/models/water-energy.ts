export interface WaterNetworkState {
  freshwaterIntakeM3H: number;
  processWaterDemandM3H: number;
  recycledWaterM3H: number;
  waterRecycleRatioPct: number;
  wastewaterOutputM3H: number;
  waterInTailingsM3H: number;
  reinjectedBrineM3H: number;
  waterConsumptionPerTonProductM3: number;
  waterStorageTankLevelPct: number;
  waterQualityPh: number;
}

export interface EnergyNetworkState {
  totalPowerDemandMW: number;
  miningPowerMW: number;
  crushingGrindingPowerMW: number;
  separationDlePowerMW: number;
  chemicalPlantPowerMW: number;
  pumpingPowerMW: number;
  auxiliaryHvacMW: number;
  // Supply Mix
  gridImportMW: number;
  solarGenerationMW: number;
  windGenerationMW: number;
  geothermalThermalPowerMW: number;
  batteryStorageDischargeMW: number;
  // Battery Energy Storage System (BESS)
  bessCapacityMWh: number;
  bessPowerMW: number;
  bessSocPct: number;
  // Emissions
  scope1CO2eKgH: number;
  scope2CO2eKgH: number;
  scope3CO2eKgH: number;
  carbonIntensityKgCO2ePerKgProduct: number;
}
