import { ProvenanceValue } from './digital-twin-state';

export type RockType = 'granite' | 'pegmatite' | 'country_rock' | 'fault_zone' | 'aquifer' | 'geothermal_reservoir';

export interface VoxelBlock {
  x: number;
  y: number;
  z: number;
  rock_type: RockType;
  lithium_grade_ppm: number;
  density_kg_m3: number;
  porosity: number;
  permeability_mD: number;
  temperature_C: number;
  moisture_pct: number;
  confidence: number;
  mined?: boolean;
}

export interface DrillholeInterval {
  fromDepthM: number;
  toDepthM: number;
  rockType: RockType;
  gradePpm: number;
  temperatureC: number;
  fractureDensity: number; // 0 to 10 scale
}

export interface Drillhole {
  holeId: string;
  xM: number;
  yM: number;
  zM: number;
  azimuthDeg: number;
  dipDeg: number;
  totalDepthM: number;
  intervals: DrillholeInterval[];
}

export interface ResourceClassStats {
  tonnageMt: number;
  averageGradePpm: number;
  containedLithiumTonnes: number;
  containedLi2OTonnes: number;
  recoverableLithiumTonnes: number;
}

export interface ResourceEstimate {
  cutoffGradePpm: number;
  measured: ResourceClassStats;
  indicated: ResourceClassStats;
  inferred: ResourceClassStats;
  total: ResourceClassStats;
  confidenceDistribution: {
    p10Tonnes: number;
    p50Tonnes: number;
    p90Tonnes: number;
  };
}

export interface DrillingPlanConfig {
  holeSpacingM: number;
  targetDepthM: number;
  azimuthDeg: number;
  dipDeg: number;
  numberOfHoles: number;
  costPerMetreGbp: ProvenanceValue<number>;
}
