export interface ProjectEconomics {
  capexGbpMillions: number;
  opexGbpPerTonProduct: number;
  electricityPriceGbpPerMWh: number;
  freshwaterCostGbpPerM3: number;
  reagentCostGbpPerTon: number;
  productPriceUsdPerTonLi2CO3: number;
  gbpToUsdExchangeRate: number;
  annualProductionTonnesLi2CO3Eq: number;
  grossRevenueGbpMillionsPerYear: number;
  annualOpexGbpMillions: number;
  grossMarginPercent: number;
  paybackPeriodYears: number;
  npv8PctGbpMillions: number;
  irrPercent: number;
}

export interface SensitivityFactor {
  parameterName: string;
  baseValue: number;
  lowValue: number;
  highValue: number;
  unit: string;
  npvLowGbpM: number;
  npvHighGbpM: number;
}
