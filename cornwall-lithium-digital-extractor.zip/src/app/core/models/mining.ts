import { ProvenanceValue } from './digital-twin-state';

export type MiningMethod = 'OPEN_PIT' | 'UNDERGROUND' | 'HYBRID';

export interface HardRockMineDesign {
  method: MiningMethod;
  // Open Pit parameters
  benchHeightM: number;
  benchWidthM: number;
  slopeAngleDeg: number;
  rampWidthM: number;
  pitDepthM: number;
  // Underground parameters
  declineLengthM: number;
  declineGradientPct: number;
  shaftDepthM: number;
  numberOfLevels: number;
  levelSpacingM: number;
  crosscutSpacingM: number;
  ventilationCapacityM3s: number;
  dewateringCapacityLs: number;
  // Production rate
  targetOreThroughputTonnesDay: number;
  wasteToOreRatio: number;
}

export interface MiningEquipmentAsset {
  id: string;
  name: string;
  type: 'EXCAVATOR' | 'LOADER' | 'HAUL_TRUCK' | 'DRILL_RIG' | 'CONVEYOR' | 'PUMP';
  isElectric: boolean;
  capacityTonnes: number;
  powerkW: number;
  availabilityPct: number;
  cycleTimeMinutes: number;
  batteryCapacitykWh?: number;
  chargingRatekW?: number;
  regenBrakingEfficiencyPct?: number;
  currentSocPct?: number;
  status: 'OPERATIONAL' | 'WARNING' | 'FAILED' | 'CHARGING' | 'MAINTENANCE';
}

export interface GeothermalReservoirConfig {
  depthM: ProvenanceValue<number>;
  reservoirTemperatureC: ProvenanceValue<number>;
  reservoirPressureBar: ProvenanceValue<number>;
  porosityPct: ProvenanceValue<number>;
  permeabilitymD: ProvenanceValue<number>;
  brineLithiumMgL: ProvenanceValue<number>;
  designFlowRateLs: ProvenanceValue<number>;
  productionWellCount: number;
  reinjectionWellCount: number;
  wellheadPressureBar: number;
  declineRatePctPerYear: number;
}

export interface BrineChemistrySpec {
  lithiumMgL: number;
  sodiumMgL: number;
  potassiumMgL: number;
  calciumMgL: number;
  magnesiumMgL: number;
  chlorideMgL: number;
  silicaMgL: number;
  pH: number;
  densityKgM3: number;
  temperatureC: number;
}
