export type ExtractionMode = 'HARD_ROCK' | 'GEOTHERMAL_BRINE';

export type ProductType = 'LITHIUM_CARBONATE' | 'LITHIUM_HYDROXIDE' | 'LITHIUM_CHLORIDE';

export type ProvenanceType = 
  | 'PUBLIC' 
  | 'USER_DEFINED' 
  | 'ENGINEERING_ASSUMPTION' 
  | 'SYNTHETIC' 
  | 'SIMULATION_OUTPUT';

export interface ProvenanceValue<T> {
  value: T;
  source: string;
  type: ProvenanceType;
  confidence: number; // 0 to 1
  version: string;
}

export type DleTechnology = 'ADSORPTION' | 'ION_EXCHANGE' | 'SOLVENT_EXTRACTION' | 'MEMBRANE';

export type DleCycleStage = 'LOAD' | 'ADSORB' | 'RINSE' | 'ELUTE' | 'REGENERATE';

export type SimulationSpeed = 1 | 5 | 20 | 100;

export type SimulationMode = 'STEADY' | 'TRANSIENT' | 'STARTUP' | 'SHUTDOWN' | 'FAULT';

export interface TelemetryLog {
  id: string;
  timestamp: string;
  simTimeSeconds: number;
  level: 'INFO' | 'WARN' | 'ERROR' | 'CRITICAL';
  source: string;
  message: string;
}

export interface SystemMassBalance {
  inputLithiumKgH: number;
  outputProductLithiumKgH: number;
  outputWasteLithiumKgH: number;
  lossesLithiumKgH: number;
  imbalancePercent: number; // Goal < 0.01%
  isSatisfied: boolean;
}

export interface SystemEnergyBalance {
  inputEnergyMW: number;
  processConsumptionMW: number;
  heatGeneratedMW: number;
  thermalRecoveryMW: number;
  lossesMW: number;
  imbalancePercent: number;
  isSatisfied: boolean;
}
