import { Injectable, signal, computed } from '@angular/core';
import { SimulationSpeed, SimulationMode } from '../models/digital-twin-state';

@Injectable({
  providedIn: 'root'
})
export class SimulationClock {
  readonly isRunning = signal<boolean>(true);
  readonly speed = signal<SimulationSpeed>(1);
  readonly mode = signal<SimulationMode>('STEADY');
  readonly simTimeSeconds = signal<number>(3600 * 12); // Start at 12:00:00

  private intervalId: ReturnType<typeof setInterval> | null = null;

  constructor() {
    this.startClock();
  }

  toggleRun() {
    this.isRunning.update(val => !val);
  }

  setSpeed(newSpeed: SimulationSpeed) {
    this.speed.set(newSpeed);
  }

  setMode(newMode: SimulationMode) {
    this.mode.set(newMode);
  }

  resetTime() {
    this.simTimeSeconds.set(0);
  }

  formattedTime = computed(() => {
    const totalSecs = this.simTimeSeconds();
    const days = Math.floor(totalSecs / 86400);
    const hours = Math.floor((totalSecs % 86400) / 3600);
    const mins = Math.floor((totalSecs % 3600) / 60);
    const secs = totalSecs % 60;
    
    const timeStr = `${hours.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    return days > 0 ? `DAY ${days + 1} - ${timeStr}` : timeStr;
  });

  private startClock() {
    if (typeof window === 'undefined') return;
    this.intervalId = setInterval(() => {
      if (this.isRunning()) {
        const deltaSecs = 1 * this.speed();
        this.simTimeSeconds.update(s => s + deltaSecs);
      }
    }, 1000);
  }
}
