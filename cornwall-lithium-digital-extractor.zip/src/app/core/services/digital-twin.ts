import { Injectable, signal, computed, inject } from '@angular/core';
import { 
  ExtractionMode, ProductType, TelemetryLog, 
  SystemMassBalance, SystemEnergyBalance 
} from '../models/digital-twin-state';
import { VoxelBlock, Drillhole, ResourceEstimate } from '../models/geology';
import { 
  HardRockMineDesign, MiningEquipmentAsset, GeothermalReservoirConfig, BrineChemistrySpec 
} from '../models/mining';
import { 
  CrusherTwinConfig, GrindingMillConfig, MineralSeparationConfig, 
  DleProcessConfig, ChemicalPlantConfig 
} from '../models/process';
import { WaterNetworkState, EnergyNetworkState } from '../models/water-energy';
import { ProjectEconomics, SensitivityFactor } from '../models/economics';
import { SystemScenario, ParetoPoint } from '../models/scenario';
import { SimulationClock } from './simulation-clock';

@Injectable({
  providedIn: 'root'
})
export class DigitalTwin {
  private clock = inject(SimulationClock);

  // 1. GLOBAL MODE
  readonly extractionMode = signal<ExtractionMode>('GEOTHERMAL_BRINE');
  readonly targetProduct = signal<ProductType>('LITHIUM_CARBONATE');

  // 2. GEOLOGY STATE
  readonly voxels = signal<VoxelBlock[]>(this.generateSyntheticVoxels());
  readonly drillholes = signal<Drillhole[]>(this.generateSyntheticDrillholes());

  // 3. HARD-ROCK MINE STATE
  readonly hardRockMine = signal<HardRockMineDesign>({
    method: 'UNDERGROUND',
    benchHeightM: 12,
    benchWidthM: 8,
    slopeAngleDeg: 55,
    rampWidthM: 15,
    pitDepthM: 180,
    declineLengthM: 1800,
    declineGradientPct: 12,
    shaftDepthM: 350,
    numberOfLevels: 4,
    levelSpacingM: 50,
    crosscutSpacingM: 30,
    ventilationCapacityM3s: 220,
    dewateringCapacityLs: 65,
    targetOreThroughputTonnesDay: 2500,
    wasteToOreRatio: 2.5
  });

  readonly miningFleet = signal<MiningEquipmentAsset[]>([
    { id: 'EXC-01', name: 'CAT 6020B Excavator', type: 'EXCAVATOR', isElectric: false, capacityTonnes: 22, powerkW: 778, availabilityPct: 92, cycleTimeMinutes: 2.5, status: 'OPERATIONAL' },
    { id: 'LDR-01', name: 'Sandvik LH517i Underground Loader', type: 'LOADER', isElectric: true, capacityTonnes: 17, powerkW: 350, availabilityPct: 95, cycleTimeMinutes: 4.0, batteryCapacitykWh: 250, chargingRatekW: 150, regenBrakingEfficiencyPct: 22, currentSocPct: 84, status: 'OPERATIONAL' },
    { id: 'TRK-01', name: 'Volvo FMX Electric Truck', type: 'HAUL_TRUCK', isElectric: true, capacityTonnes: 40, powerkW: 490, availabilityPct: 88, cycleTimeMinutes: 18.0, batteryCapacitykWh: 540, chargingRatekW: 250, regenBrakingEfficiencyPct: 28, currentSocPct: 62, status: 'OPERATIONAL' },
    { id: 'DRL-01', name: 'Epiroc Boomer E2 Drill Rig', type: 'DRILL_RIG', isElectric: true, capacityTonnes: 0, powerkW: 180, availabilityPct: 90, cycleTimeMinutes: 15.0, status: 'OPERATIONAL' }
  ]);

  // 4. GEOTHERMAL RESERVOIR & WELL STATE
  readonly geothermalReservoir = signal<GeothermalReservoirConfig>({
    depthM: { value: 4000, source: 'Cornwall Granitic Geothermal Model', type: 'SYNTHETIC', confidence: 0.85, version: '2026.1' },
    reservoirTemperatureC: { value: 180, source: 'United Downs Geothermal Reference', type: 'SYNTHETIC', confidence: 0.90, version: '2026.1' },
    reservoirPressureBar: { value: 380, source: 'Granite Hydrothermal Estimate', type: 'ENGINEERING_ASSUMPTION', confidence: 0.80, version: '2026.1' },
    porosityPct: { value: 3.5, source: 'Carnmenellis Granite Fractures', type: 'ENGINEERING_ASSUMPTION', confidence: 0.75, version: '2026.1' },
    permeabilitymD: { value: 45, source: 'Fault-Assisted Permeability Model', type: 'SYNTHETIC', confidence: 0.70, version: '2026.1' },
    brineLithiumMgL: { value: 220, source: 'Cornwall Deep Geothermal Brine Standard', type: 'SYNTHETIC', confidence: 0.88, version: '2026.1' },
    designFlowRateLs: { value: 100, source: 'Dual-Well Production Target', type: 'USER_DEFINED', confidence: 0.95, version: '2026.1' },
    productionWellCount: 1,
    reinjectionWellCount: 1,
    wellheadPressureBar: 18,
    declineRatePctPerYear: 1.8
  });

  readonly brineChemistry = signal<BrineChemistrySpec>({
    lithiumMgL: 220,
    sodiumMgL: 14500,
    potassiumMgL: 2100,
    calciumMgL: 3800,
    magnesiumMgL: 180,
    chlorideMgL: 29500,
    silicaMgL: 320,
    pH: 5.8,
    densityKgM3: 1085,
    temperatureC: 175
  });

  // 5. HARD-ROCK PROCESS PLANT UNITS
  readonly crusher = signal<CrusherTwinConfig>({
    feedSizeMm: 600,
    productSizeP80Mm: 45,
    throughputTonnesHour: 110,
    installedPowerkW: 450,
    efficiencyPct: 88,
    specificEnergykWhPerTon: 3.2
  });

  readonly mill = signal<GrindingMillConfig>({
    millType: 'BALL_MILL',
    feedSizeP80Mm: 45,
    targetGrindP80Microns: 150,
    throughputTonnesHour: 105,
    installedPowerkW: 1850,
    recirculationRatioPct: 250,
    specificEnergykWhPerTon: 14.8
  });

  readonly mineralSeparation = signal<MineralSeparationConfig>({
    technology: 'FLOTATION',
    feedMassFlowTH: 105,
    feedLithiumGradePpm: 850,
    recoveryPct: 82.5,
    concentrateGradeLi2OPct: 6.0, // Spodumene concentrate ~6% Li2O
    waterDemandM3PerTon: 2.8,
    energyDemandkWhPerTon: 8.5
  });

  // 6. GEOTHERMAL DLE PROCESS
  readonly dleProcess = signal<DleProcessConfig>({
    technology: 'ADSORPTION',
    recoveryPct: { value: 92.0, source: 'Synthetic Lithium Selective Sorbent', type: 'SYNTHETIC', confidence: 0.88, version: '2026.1' },
    selectivityLiVsMultivalents: { value: 140, source: 'Inorganic Lithium Titanate Benchmark', type: 'ENGINEERING_ASSUMPTION', confidence: 0.82, version: '2026.1' },
    cycleTimeMinutes: 45,
    sorbentCapacityMgPerG: 12.5,
    regenerationEfficiencyPct: 96.5,
    brineFeedRateLs: 100,
    currentCycleStage: 'LOAD',
    cycleTimeRemainingSeconds: 1420,
    eluateLithiumMgL: 2450, // Concentrated eluate stream
    waterConsumptionM3PerKgLi: 0.08,
    energyConsumptionkWhPerKgLi: 4.2
  });

  // 7. CHEMICAL CONVERSION PLANT
  readonly chemicalPlant = signal<ChemicalPlantConfig>({
    targetProduct: 'LITHIUM_CARBONATE',
    conversionYieldPct: 91.5,
    reagentSodiumCarbonateKgPerKgLi: 7.8,
    reagentLimeKgPerKgLi: 1.2,
    reagentAcidKgPerKgLi: 0.4,
    thermalEnergykWhPerKgProduct: 3.8,
    electricalEnergykWhPerKgProduct: 1.9,
    waterM3PerKgProduct: 0.045,
    targetPurityPct: 99.5,
    maxImpurityNaPpm: 250,
    maxImpurityKPpm: 120,
    maxImpurityCaPpm: 180,
    maxImpurityFePpm: 15
  });

  // 8. WATER NETWORK CONTROL
  readonly waterRecycleRatio = signal<number>(85.0); // % recycled water

  // 9. RELIABILITY / FAILURE OVERRIDES
  readonly equipmentFailureState = signal<Record<string, boolean>>({
    'PUMP_CNL_P1': false,
    'CRUSHER_CR_1': false,
    'MILL_SAG_1': false,
    'DLE_SKID_1': false
  });

  // 10. TELEMETRY LOGS
  readonly telemetryLogs = signal<TelemetryLog[]>([
    { id: 'LOG-001', timestamp: '12:00:00', simTimeSeconds: 43200, level: 'INFO', source: 'SYSTEM', message: 'Cornwall Lithium Digital Twin initialized in Geothermal DLE mode.' },
    { id: 'LOG-002', timestamp: '12:00:01', simTimeSeconds: 43201, level: 'INFO', source: 'RESERVOIR', message: 'Production Well CNL-GT-01 online. Flow rate: 100 L/s @ 175°C.' },
    { id: 'LOG-003', timestamp: '12:00:05', simTimeSeconds: 43205, level: 'INFO', source: 'DLE_SKID', message: 'DLE Contactor Skid A entered LOAD stage. Sorbent loading active.' }
  ]);

  // =========================================================================
  // COMPUTED ENGINE PROPAGATION (THE COMPUTATIONAL PHYSICAL MODEL)
  // =========================================================================

  // A. HARD ROCK PRODUCTION CALCULATIONS
  readonly hardRockLithiumRateKgH = computed(() => {
    if (this.equipmentFailureState()['CRUSHER_CR_1'] || this.equipmentFailureState()['MILL_SAG_1']) {
      return 0;
    }
    const mine = this.hardRockMine();
    const tonnesPerHour = mine.targetOreThroughputTonnesDay / 24;
    const gradePpm = 850; // Li ppm
    const sepRecovery = this.mineralSeparation().recoveryPct / 100;
    const chemYield = this.chemicalPlant().conversionYieldPct / 100;
    
    // Total Li in ore (kg/h) = tonnes/h * 1000 * (ppm / 1e6)
    const liInOreKgH = tonnesPerHour * 1000 * (gradePpm / 1e6);
    return liInOreKgH * sepRecovery * chemYield;
  });

  // B. GEOTHERMAL BRINE PRODUCTION CALCULATIONS
  readonly geothermalLithiumRateKgH = computed(() => {
    if (this.equipmentFailureState()['PUMP_CNL_P1']) {
      return 0;
    }
    const res = this.geothermalReservoir();
    const flowLs = res.designFlowRateLs.value;
    const lithiumMgL = res.brineLithiumMgL.value;
    const dleRecovery = (this.equipmentFailureState()['DLE_SKID_1'] ? 0.25 : 1.0) * (this.dleProcess().recoveryPct.value / 100);
    const chemYield = this.chemicalPlant().conversionYieldPct / 100;

    // Mass flow of Li = flow (L/s) * 3600 (s/h) * mg/L * 1e-6 (kg/mg) = flow * 3.6 * mg/L * 1e-3
    const liInBrineKgH = flowLs * 3.6 * lithiumMgL * 0.001; // e.g. 100 * 3.6 * 220 / 1000 = 79.2 kg Li/h
    return liInBrineKgH * dleRecovery * chemYield;
  });

  // C. ACTIVE LITHIUM PRODUCTION RATE (kg/h, t/day, Li2CO3 / LiOH t/day)
  readonly activeLithiumProductionKgH = computed(() => {
    return this.extractionMode() === 'HARD_ROCK' 
      ? this.hardRockLithiumRateKgH() 
      : this.geothermalLithiumRateKgH();
  });

  readonly activeProductOutputTonnesDay = computed(() => {
    const liKgH = this.activeLithiumProductionKgH();
    const liKgDay = liKgH * 24;
    const product = this.targetProduct();
    
    let molarFactor = 5.324; // Li -> Li2CO3 conversion factor (73.89 / 13.88)
    if (product === 'LITHIUM_HYDROXIDE') {
      molarFactor = 6.042; // Li -> LiOH.H2O factor (41.96 / 6.94)
    } else if (product === 'LITHIUM_CHLORIDE') {
      molarFactor = 6.107; // Li -> LiCl factor
    }

    return (liKgDay * molarFactor) / 1000; // tonnes/day product
  });

  // D. WATER NETWORK STATE COMPUTATION
  readonly waterNetwork = computed<WaterNetworkState>(() => {
    const mode = this.extractionMode();
    const liKgH = this.activeLithiumProductionKgH();
    const recycleRatio = this.waterRecycleRatio() / 100;

    let grossWaterDemandM3H = 0;
    if (mode === 'HARD_ROCK') {
      const oreTH = this.hardRockMine().targetOreThroughputTonnesDay / 24;
      grossWaterDemandM3H = oreTH * this.mineralSeparation().waterDemandM3PerTon;
    } else {
      grossWaterDemandM3H = liKgH * this.dleProcess().waterConsumptionM3PerKgLi;
    }

    // Add chemical plant water
    grossWaterDemandM3H += (this.activeProductOutputTonnesDay() * 1000 / 24) * this.chemicalPlant().waterM3PerKgProduct;

    const recycledM3H = grossWaterDemandM3H * recycleRatio;
    const freshWaterM3H = grossWaterDemandM3H - recycledM3H;
    const wastewaterM3H = grossWaterDemandM3H * 0.08;
    const tailingsOrReinjectionM3H = mode === 'GEOTHERMAL_BRINE' ? (this.geothermalReservoir().designFlowRateLs.value * 3.6) : (grossWaterDemandM3H * 0.12);

    const productTonnesDay = Math.max(0.01, this.activeProductOutputTonnesDay());
    const waterPerTon = (freshWaterM3H * 24) / productTonnesDay;

    return {
      freshwaterIntakeM3H: freshWaterM3H,
      processWaterDemandM3H: grossWaterDemandM3H,
      recycledWaterM3H: recycledM3H,
      waterRecycleRatioPct: this.waterRecycleRatio(),
      wastewaterOutputM3H: wastewaterM3H,
      waterInTailingsM3H: mode === 'HARD_ROCK' ? tailingsOrReinjectionM3H : 0,
      reinjectedBrineM3H: mode === 'GEOTHERMAL_BRINE' ? tailingsOrReinjectionM3H : 0,
      waterConsumptionPerTonProductM3: waterPerTon,
      waterStorageTankLevelPct: 88.5,
      waterQualityPh: 6.8
    };
  });

  // E. ENERGY NETWORK STATE COMPUTATION
  readonly energyNetwork = computed<EnergyNetworkState>(() => {
    const mode = this.extractionMode();
    const liKgH = this.activeLithiumProductionKgH();
    
    let miningPower = 0;
    let crushingGrindingPower = 0;
    let separationDlePower = 0;
    let pumpingPower = 0;

    if (mode === 'HARD_ROCK') {
      const oreTH = this.hardRockMine().targetOreThroughputTonnesDay / 24;
      miningPower = (oreTH * 12) / 1000; // MW
      crushingGrindingPower = (oreTH * (this.crusher().specificEnergykWhPerTon + this.mill().specificEnergykWhPerTon)) / 1000;
      separationDlePower = (oreTH * this.mineralSeparation().energyDemandkWhPerTon) / 1000;
      pumpingPower = 0.4;
    } else {
      const flowLs = this.geothermalReservoir().designFlowRateLs.value;
      pumpingPower = (flowLs * 9.81 * 400 * 1085) / (1e6 * 0.78); // Pumping head 400m MW
      separationDlePower = (liKgH * this.dleProcess().energyConsumptionkWhPerKgLi) / 1000; // MW
      miningPower = 0.1;
      crushingGrindingPower = 0.0;
    }

    const chemProdKgH = (this.activeProductOutputTonnesDay() * 1000) / 24;
    const chemicalPlantPower = (chemProdKgH * this.chemicalPlant().electricalEnergykWhPerKgProduct) / 1000;
    const hvacAuxMW = 0.35;

    const totalMW = miningPower + crushingGrindingPower + separationDlePower + chemicalPlantPower + pumpingPower + hvacAuxMW;

    // Renewable Supply Mix
    const solarMW = 1.2;
    const windMW = 2.4;
    const geothermalThermalMW = mode === 'GEOTHERMAL_BRINE' ? 3.8 : 0.0;
    const bessDischargeMW = 0.5;

    const renewableSum = solarMW + windMW + geothermalThermalMW + bessDischargeMW;
    const gridMW = Math.max(0, totalMW - renewableSum);

    // Carbon
    const scope1 = (miningPower * 180) + (mode === 'HARD_ROCK' ? 120 : 20); // kg CO2e / h
    const scope2 = gridMW * 210; // 210 g CO2 / kWh UK grid factor
    const scope3 = chemProdKgH * 0.8;
    const productKgH = Math.max(0.1, chemProdKgH);
    const carbonIntensity = (scope1 + scope2 + scope3) / productKgH;

    return {
      totalPowerDemandMW: totalMW,
      miningPowerMW: miningPower,
      crushingGrindingPowerMW: crushingGrindingPower,
      separationDlePowerMW: separationDlePower,
      chemicalPlantPowerMW: chemicalPlantPower,
      pumpingPowerMW: pumpingPower,
      auxiliaryHvacMW: hvacAuxMW,
      gridImportMW: gridMW,
      solarGenerationMW: solarMW,
      windGenerationMW: windMW,
      geothermalThermalPowerMW: geothermalThermalMW,
      batteryStorageDischargeMW: bessDischargeMW,
      bessCapacityMWh: 12.0,
      bessPowerMW: 4.0,
      bessSocPct: 76.5,
      scope1CO2eKgH: scope1,
      scope2CO2eKgH: scope2,
      scope3CO2eKgH: scope3,
      carbonIntensityKgCO2ePerKgProduct: carbonIntensity
    };
  });

  // F. MASS BALANCE INTEGRITY VERIFICATION
  readonly massBalance = computed<SystemMassBalance>(() => {
    const mode = this.extractionMode();
    let inputKgH = 0;
    if (mode === 'HARD_ROCK') {
      const oreTH = this.hardRockMine().targetOreThroughputTonnesDay / 24;
      inputKgH = oreTH * 1000 * (850 / 1e6);
    } else {
      const flowLs = this.geothermalReservoir().designFlowRateLs.value;
      inputKgH = flowLs * 3.6 * this.geothermalReservoir().brineLithiumMgL.value * 0.001;
    }

    const productLiKgH = this.activeLithiumProductionKgH();
    const recovery = mode === 'HARD_ROCK' 
      ? (this.mineralSeparation().recoveryPct / 100) * (this.chemicalPlant().conversionYieldPct / 100)
      : (this.dleProcess().recoveryPct.value / 100) * (this.chemicalPlant().conversionYieldPct / 100);

    const wasteLiKgH = inputKgH * (1 - recovery);
    const lossesLiKgH = inputKgH * 0.001; // 0.1% minor unmeasured loss

    const totalOut = productLiKgH + wasteLiKgH + lossesLiKgH;
    const diff = Math.abs(inputKgH - totalOut);
    const imbalancePct = inputKgH > 0 ? (diff / inputKgH) * 100 : 0;

    return {
      inputLithiumKgH: inputKgH,
      outputProductLithiumKgH: productLiKgH,
      outputWasteLithiumKgH: wasteLiKgH,
      lossesLithiumKgH: lossesLiKgH,
      imbalancePercent: imbalancePct,
      isSatisfied: imbalancePct < 0.01
    };
  });

  // G. ENERGY BALANCE INTEGRITY VERIFICATION
  readonly energyBalance = computed<SystemEnergyBalance>(() => {
    const netEnergy = this.energyNetwork();
    const inputMW = netEnergy.gridImportMW + netEnergy.solarGenerationMW + netEnergy.windGenerationMW + netEnergy.geothermalThermalPowerMW;
    const processMW = netEnergy.totalPowerDemandMW;
    const thermalRecoveryMW = netEnergy.geothermalThermalPowerMW * 0.35;
    const lossesMW = inputMW * 0.02;

    const diff = Math.abs(inputMW - (processMW + lossesMW));
    const imbalancePct = inputMW > 0 ? (diff / inputMW) * 100 : 0;

    return {
      inputEnergyMW: inputMW,
      processConsumptionMW: processMW,
      heatGeneratedMW: processMW * 0.4,
      thermalRecoveryMW: thermalRecoveryMW,
      lossesMW: lossesMW,
      imbalancePercent: imbalancePct,
      isSatisfied: imbalancePct < 0.5
    };
  });

  // H. PROJECT ECONOMICS COMPUTATION
  readonly economics = computed<ProjectEconomics>(() => {
    const mode = this.extractionMode();
    const annualProductTonnes = this.activeProductOutputTonnesDay() * 350; // 350 operating days/yr
    const productPriceUsd = 24500; // $24,500 / t Li2CO3
    const gbpUsd = 1.30;

    const capex = mode === 'HARD_ROCK' ? 185.0 : 145.0; // £185M vs £145M
    const opexPerTon = mode === 'HARD_ROCK' ? 4200 : 3100; // £/t Li2CO3 eq

    const grossRevenueUsd = annualProductTonnes * productPriceUsd;
    const grossRevenueGbpM = grossRevenueUsd / gbpUsd / 1e6;
    const annualOpexGbpM = (annualProductTonnes * opexPerTon) / 1e6;
    const netCashFlowM = grossRevenueGbpM - annualOpexGbpM;

    const marginPct = grossRevenueGbpM > 0 ? (netCashFlowM / grossRevenueGbpM) * 100 : 0;
    const payback = netCashFlowM > 0 ? capex / netCashFlowM : 99;

    // Simplified NPV @ 8% discount over 20 years
    let npv = -capex;
    for (let yr = 1; yr <= 20; yr++) {
      npv += netCashFlowM / Math.pow(1.08, yr);
    }

    const irr = netCashFlowM > 0 ? (netCashFlowM / capex) * 100 + 4.5 : 0;

    return {
      capexGbpMillions: capex,
      opexGbpPerTonProduct: opexPerTon,
      electricityPriceGbpPerMWh: 95.0,
      freshwaterCostGbpPerM3: 1.85,
      reagentCostGbpPerTon: 840,
      productPriceUsdPerTonLi2CO3: productPriceUsd,
      gbpToUsdExchangeRate: gbpUsd,
      annualProductionTonnesLi2CO3Eq: annualProductTonnes,
      grossRevenueGbpMillionsPerYear: grossRevenueGbpM,
      annualOpexGbpMillions: annualOpexGbpM,
      grossMarginPercent: marginPct,
      paybackPeriodYears: payback,
      npv8PctGbpMillions: npv,
      irrPercent: irr
    };
  });

  // I. RESOURCE ESTIMATE COMPUTATION
  readonly resourceEstimate = computed<ResourceEstimate>(() => {
    return {
      cutoffGradePpm: 500,
      measured: { tonnageMt: 14.2, averageGradePpm: 880, containedLithiumTonnes: 12496, containedLi2OTonnes: 26866, recoverableLithiumTonnes: 10246 },
      indicated: { tonnageMt: 28.5, averageGradePpm: 810, containedLithiumTonnes: 23085, containedLi2OTonnes: 49632, recoverableLithiumTonnes: 18468 },
      inferred: { tonnageMt: 42.0, averageGradePpm: 760, containedLithiumTonnes: 31920, containedLi2OTonnes: 68628, recoverableLithiumTonnes: 24259 },
      total: { tonnageMt: 84.7, averageGradePpm: 808, containedLithiumTonnes: 67501, containedLi2OTonnes: 145126, recoverableLithiumTonnes: 52973 },
      confidenceDistribution: {
        p10Tonnes: 74200,
        p50Tonnes: 67500,
        p90Tonnes: 58900
      }
    };
  });

  // J. SENSITIVITY TORNADO ANALYSIS
  readonly sensitivityFactors = computed<SensitivityFactor[]>(() => {
    const baseNpv = this.economics().npv8PctGbpMillions;
    return [
      { parameterName: 'Lithium Product Price', baseValue: 24500, lowValue: 18000, highValue: 32000, unit: '$/t', npvLowGbpM: baseNpv * 0.58, npvHighGbpM: baseNpv * 1.46 },
      { parameterName: 'Geothermal Flow / Ore Grade', baseValue: 100, lowValue: 70, highValue: 130, unit: 'L/s', npvLowGbpM: baseNpv * 0.68, npvHighGbpM: baseNpv * 1.32 },
      { parameterName: 'DLE / Separation Recovery', baseValue: 92, lowValue: 80, highValue: 96, unit: '%', npvLowGbpM: baseNpv * 0.79, npvHighGbpM: baseNpv * 1.15 },
      { parameterName: 'Project CAPEX', baseValue: 145, lowValue: 115, highValue: 185, unit: '£M', npvLowGbpM: baseNpv * 1.18, npvHighGbpM: baseNpv * 0.82 },
      { parameterName: 'Electricity Price', baseValue: 95, lowValue: 70, highValue: 140, unit: '£/MWh', npvLowGbpM: baseNpv * 1.08, npvHighGbpM: baseNpv * 0.89 }
    ];
  });

  // K. SCENARIO COMPARISON MATRIX
  readonly predefinedScenarios = computed<SystemScenario[]>(() => {
    const baseLiKgH = this.activeLithiumProductionKgH();
    const mode = this.extractionMode();
    const product = this.targetProduct();

    return [
      {
        id: 'SCEN-01',
        name: 'BASELINE OPERATION',
        description: 'Standard Cornwall design parameters with nominal throughput.',
        mode, targetProduct: product,
        throughputPct: 100, recoveryPct: 92, lithiumOutputKgH: baseLiKgH,
        energyConsumptionkWhPerKgLi: 4.2, waterConsumptionM3PerKgLi: 0.08, opexGbpPerTon: 3100, carbonKgCO2PerKgLi: 8.4
      },
      {
        id: 'SCEN-02',
        name: 'HIGH THROUGHPUT BOOST',
        description: '+25% flow/throughput rate with optimized high-capacity pumping.',
        mode, targetProduct: product,
        throughputPct: 125, recoveryPct: 89.5, lithiumOutputKgH: baseLiKgH * 1.21,
        energyConsumptionkWhPerKgLi: 4.6, waterConsumptionM3PerKgLi: 0.085, opexGbpPerTon: 2950, carbonKgCO2PerKgLi: 8.8
      },
      {
        id: 'SCEN-03',
        name: 'MAXIMUM RECOVERY & PURITY',
        description: 'Extended residence time in DLE/flotation for 96% recovery and 99.8% battery purity.',
        mode, targetProduct: product,
        throughputPct: 90, recoveryPct: 96.2, lithiumOutputKgH: baseLiKgH * 0.94,
        energyConsumptionkWhPerKgLi: 4.8, waterConsumptionM3PerKgLi: 0.075, opexGbpPerTon: 3350, carbonKgCO2PerKgLi: 8.1
      },
      {
        id: 'SCEN-04',
        name: 'LOW CARBON & WATER CLOSED-LOOP',
        description: '95% water recycling with 100% renewable grid + BESS energy integration.',
        mode, targetProduct: product,
        throughputPct: 100, recoveryPct: 91.5, lithiumOutputKgH: baseLiKgH * 0.99,
        energyConsumptionkWhPerKgLi: 3.9, waterConsumptionM3PerKgLi: 0.025, opexGbpPerTon: 3050, carbonKgCO2PerKgLi: 2.1
      }
    ];
  });

  // L. PARETO FRONTIER POINTS
  readonly paretoPoints = computed<ParetoPoint[]>(() => {
    return [
      { scenarioName: 'Baseline', productionKgH: 72.8, energyKWhPerKg: 4.2, waterM3PerKg: 0.08, opexGbpPerTon: 3100, carbonKgCO2PerKg: 8.4 },
      { scenarioName: 'High Throughput', productionKgH: 88.1, energyKWhPerKg: 4.6, waterM3PerKg: 0.085, opexGbpPerTon: 2950, carbonKgCO2PerKg: 8.8 },
      { scenarioName: 'Max Recovery', productionKgH: 68.4, energyKWhPerKg: 4.8, waterM3PerKg: 0.075, opexGbpPerTon: 3350, carbonKgCO2PerKg: 8.1 },
      { scenarioName: 'Low Carbon', productionKgH: 72.1, energyKWhPerKg: 3.9, waterM3PerKg: 0.025, opexGbpPerTon: 3050, carbonKgCO2PerKg: 2.1 }
    ];
  });

  // =========================================================================
  // ACTIONS AND MUTATIONS
  // =========================================================================

  setExtractionMode(mode: ExtractionMode) {
    this.extractionMode.set(mode);
    this.logTelemetry('INFO', 'SYSTEM', `Switched digital twin architecture to ${mode}.`);
  }

  setTargetProduct(product: ProductType) {
    this.targetProduct.set(product);
    this.logTelemetry('INFO', 'CHEMICAL', `Updated target chemical product to ${product}.`);
  }

  setGeothermalFlowRate(flowLs: number) {
    this.geothermalReservoir.update(res => ({
      ...res,
      designFlowRateLs: { ...res.designFlowRateLs, value: flowLs, type: 'USER_DEFINED' }
    }));
    this.dleProcess.update(dle => ({ ...dle, brineFeedRateLs: flowLs }));
    this.logTelemetry('INFO', 'WELLS', `Geothermal brine production well flow set to ${flowLs} L/s.`);
  }

  setHardRockOreThroughput(tonnesDay: number) {
    this.hardRockMine.update(m => ({ ...m, targetOreThroughputTonnesDay: tonnesDay }));
    this.crusher.update(c => ({ ...c, throughputTonnesHour: tonnesDay / 24 }));
    this.mill.update(m => ({ ...m, throughputTonnesHour: (tonnesDay / 24) * 0.95 }));
    this.logTelemetry('INFO', 'MINE', `Hard-rock mine target ore throughput updated to ${tonnesDay} t/day.`);
  }

  setDleRecovery(recoveryPct: number) {
    this.dleProcess.update(dle => ({
      ...dle,
      recoveryPct: { ...dle.recoveryPct, value: recoveryPct, type: 'USER_DEFINED' }
    }));
    this.logTelemetry('INFO', 'DLE', `Direct Lithium Extraction recovery override set to ${recoveryPct}%.`);
  }

  setChemicalYield(yieldPct: number) {
    this.chemicalPlant.update(c => ({ ...c, conversionYieldPct: yieldPct }));
    this.logTelemetry('INFO', 'CHEMICAL', `Chemical plant yield set to ${yieldPct}%.`);
  }

  setWaterRecycleRatio(ratioPct: number) {
    this.waterRecycleRatio.set(ratioPct);
    this.logTelemetry('INFO', 'WATER', `Water recycling loop efficiency set to ${ratioPct}%.`);
  }

  toggleEquipmentFailure(equipmentKey: string) {
    this.equipmentFailureState.update(curr => {
      const next = { ...curr, [equipmentKey]: !curr[equipmentKey] };
      const failed = next[equipmentKey];
      this.logTelemetry(
        failed ? 'CRITICAL' : 'INFO', 
        'MAINTENANCE', 
        `Equipment asset ${equipmentKey} state changed to ${failed ? 'FAILED / TRIP' : 'OPERATIONAL'}.`
      );
      return next;
    });
  }

  logTelemetry(level: 'INFO' | 'WARN' | 'ERROR' | 'CRITICAL', source: string, message: string) {
    const timeStr = this.clock.formattedTime();
    const simSecs = this.clock.simTimeSeconds();
    const id = `LOG-${Math.floor(Math.random() * 8999 + 1000)}`;
    this.telemetryLogs.update(logs => [
      { id, timestamp: timeStr, simTimeSeconds: simSecs, level, source, message },
      ...logs.slice(0, 49) // keep latest 50
    ]);
  }

  // Helper generators
  private generateSyntheticVoxels(): VoxelBlock[] {
    const voxels: VoxelBlock[] = [];
    const sizeX = 8, sizeY = 8, sizeZ = 6;
    for (let z = 0; z < sizeZ; z++) {
      for (let y = 0; y < sizeY; y++) {
        for (let x = 0; x < sizeX; x++) {
          let rock: VoxelBlock['rock_type'] = 'granite';
          let grade = 450 + Math.random() * 300;
          let temp = 15 + z * 28;

          if (z >= 4) {
            rock = 'geothermal_reservoir';
            grade = 180 + Math.random() * 60; // ppm equivalent
            temp = 140 + z * 10;
          } else if (x >= 3 && x <= 5 && y >= 2 && y <= 5 && z < 4) {
            rock = 'pegmatite';
            grade = 950 + Math.random() * 650;
          } else if (x === 2 && z < 4) {
            rock = 'fault_zone';
            grade = 700;
          }

          voxels.push({
            x, y, z,
            rock_type: rock,
            lithium_grade_ppm: Math.round(grade),
            density_kg_m3: rock === 'pegmatite' ? 2680 : 2650,
            porosity: rock === 'geothermal_reservoir' ? 0.045 : 0.012,
            permeability_mD: rock === 'fault_zone' ? 120 : 15,
            temperature_C: Math.round(temp),
            moisture_pct: rock === 'geothermal_reservoir' ? 100 : 1.2,
            confidence: 0.72 + Math.random() * 0.2
          });
        }
      }
    }
    return voxels;
  }

  private generateSyntheticDrillholes(): Drillhole[] {
    return [
      {
        holeId: 'DRILL-CNL-014',
        xM: 120, yM: 240, zM: 0,
        azimuthDeg: 180, dipDeg: -85,
        totalDepthM: 320,
        intervals: [
          { fromDepthM: 0, toDepthM: 120, rockType: 'granite', gradePpm: 420, temperatureC: 22, fractureDensity: 2 },
          { fromDepthM: 120, toDepthM: 185, rockType: 'pegmatite', gradePpm: 1280, temperatureC: 38, fractureDensity: 6 },
          { fromDepthM: 185, toDepthM: 260, rockType: 'fault_zone', gradePpm: 890, temperatureC: 54, fractureDensity: 9 },
          { fromDepthM: 260, toDepthM: 320, rockType: 'granite', gradePpm: 510, temperatureC: 70, fractureDensity: 3 }
        ]
      },
      {
        holeId: 'DRILL-CNL-018',
        xM: 350, yM: 180, zM: 0,
        azimuthDeg: 210, dipDeg: -90,
        totalDepthM: 450,
        intervals: [
          { fromDepthM: 0, toDepthM: 150, rockType: 'granite', gradePpm: 480, temperatureC: 25, fractureDensity: 3 },
          { fromDepthM: 150, toDepthM: 290, rockType: 'pegmatite', gradePpm: 1420, temperatureC: 52, fractureDensity: 5 },
          { fromDepthM: 290, toDepthM: 450, rockType: 'geothermal_reservoir', gradePpm: 220, temperatureC: 135, fractureDensity: 8 }
        ]
      }
    ];
  }
}
