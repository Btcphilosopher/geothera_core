import { ChangeDetectionStrategy, Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { TopNav } from './components/top-nav/top-nav';
import { TelemetryBar } from './components/telemetry-bar/telemetry-bar';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [RouterOutlet, TopNav, TelemetryBar],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {}
